(() => {
  "use strict";

  // ========== 只改这里 ==========
  const RULES = [
    { text: "要变色的文字", color: "#e60000" },
    { text: "另一个关键词", color: "#0066ff" },
  ];
  // ==============================

  if (!RULES.length) return;
  if (!("highlights" in CSS) || typeof Highlight === "undefined") {
    console.warn("[文字高亮] 当前浏览器不支持 CSS Custom Highlight API");
    return;
  }

  const items = RULES.map((r, i) => ({ ...r, name: `hl-rule-${i}` }));
  const usedNames = new Set(items.map(r => r.name));

  const escapeReg = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const sorted = [...items].sort((a, b) => b.text.length - a.text.length);
  const pattern = new RegExp(sorted.map(r => escapeReg(r.text)).join("|"), "g");
  const byText = new Map(items.map(r => [r.text, r]));

  const SKIP_TAGS = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA", "INPUT", "SELECT"]);

  function shouldSkip(el) {
    if (!el) return true;
    if (SKIP_TAGS.has(el.tagName)) return true;
    if (el.isContentEditable) return true;
    return false;
  }

  function collectRanges(root, out) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        if (shouldSkip(node.parentElement)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      },
    });
    let n;
    while ((n = walker.nextNode())) {
      const text = n.nodeValue;
      pattern.lastIndex = 0;
      let m;
      while ((m = pattern.exec(text))) {
        const rule = byText.get(m[0]);
        if (!rule) continue;
        const range = new Range();
        range.setStart(n, m.index);
        range.setEnd(n, m.index + m[0].length);
        out.push({ range, name: rule.name });
      }
    }
  }

  function injectStyles() {
    if (document.getElementById("__hl_zero_dom_style__")) return;
    const style = document.createElement("style");
    style.id = "__hl_zero_dom_style__";
    style.textContent = items
      .map(r => `::highlight(${r.name}) { color: ${r.color}; }`)
      .join("\n");
    (document.head || document.documentElement).appendChild(style);
  }

  function refresh() {
    const ranges = [];
    collectRanges(document.body || document.documentElement, ranges);

    const groups = new Map();
    for (const { range, name } of ranges) {
      if (!groups.has(name)) groups.set(name, []);
      groups.get(name).push(range);
    }

    for (const name of usedNames) CSS.highlights.delete(name);
    for (const [name, rs] of groups) {
      CSS.highlights.set(name, new Highlight(...rs));
    }
  }

  injectStyles();
  if (document.body) refresh();
  else document.addEventListener("DOMContentLoaded", refresh, { once: true });

  let timer = null;
  const observer = new MutationObserver((muts) => {
    let need = false;
    for (const mut of muts) {
      if (mut.type === "characterData") { need = true; break; }
      for (const node of mut.addedNodes) {
        if (node.id === "__hl_zero_dom_style__") continue;
        need = true;
        break;
      }
      if (need) break;
    }
    if (!need) return;
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => { timer = null; refresh(); }, 300);
  });
  observer.observe(document.documentElement, {
    childList: true, subtree: true, characterData: true,
  });
})();