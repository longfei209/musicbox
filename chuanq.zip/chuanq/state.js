let player = {
    lv:1,exp:0,expMax:100,
    hp:100,hpMax:100,
    atk:8,def:2,
    gold:500,
    bag:[],
    bagMax:12,
    potion:3,
    equip:{
        weapon:null,
        hat:null,
        cloth:null,
        shoe:null,
        belt:null,
        ring1:null,
        ring2:null,
        accessory:null
    },
    taskProgress:{},
    bountyKilled:{}
};

let battleState = {
    active:false,
    monster:null,
    auto:false,
    autoTimer:null,
    skillCd:0,
    skillMaxCd:3
};

let currentAreaState = null;

function addBattleLog(text){
    battleLogDom.innerText += text+"\n";
    battleLogDom.scrollTop = battleLogDom.scrollHeight;
}

function getTotalAttr(){
    let tAtk = player.atk;
    let tDef = player.def;
    let tHpMaxBonus = 0;
    //遍历全部穿戴装备
    for(let slotKey in player.equip){
        let itemName = player.equip[slotKey];
        if(itemName && equipData[itemName]){
            let e = equipData[itemName];
            tAtk += e.atk + e.refineAtk;
            tDef += e.def + e.refineDef;
            tHpMaxBonus += e.refineHp;
        }
    }
    return {atk:tAtk,def:tDef,hpBonus:tHpMaxBonus};
}

function refreshUi(){
    let attr = getTotalAttr();
    document.getElementById("status").innerText =
`Lv:${player.lv}｜经验${player.exp}/${player.expMax}
HP:${Math.round(player.hp)}/${player.hpMax+attr.hpBonus} 攻击:${attr.atk} 防御:${attr.def}
金币:${player.gold}｜红药×${player.potion}
背包(${player.bag.length}/${player.bagMax}):${player.bag.join(",")||"空"}`;
}

function levelUp(){
    while(player.exp >= player.expMax){
        player.exp -= player.expMax;
        player.lv++;
        player.expMax = Math.floor(player.expMax*1.4);
        player.hpMax +=18;
        player.hp = player.hpMax;
        player.atk +=4;
        player.def +=1;
        addBattleLog(`====🎉升级！等级 ${player.lv}！`);
    }
    refreshUi();
}

function sleep(ms){
    return new Promise(res=>setTimeout(res,ms));
}
