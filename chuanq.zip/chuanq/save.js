function saveGame(){
    localStorage.setItem("legendSave", JSON.stringify(player));
}

function loadGame(){
    let s = localStorage.getItem("legendSave");
    if(!s){
        addBattleLog("❌没有找到存档");
        return;
    }
    try{
        player = JSON.parse(s);
        refreshUi();
        addBattleLog("✅读档成功");
    }catch(e){
        addBattleLog("❌读档失败");
    }
}

function resetGame(){
    closeAllModal();
    localStorage.removeItem("legendSave");

    player = {
        lv:1,
        exp:0,
        expMax:100,
        hp:100,
        hpMax:100,
        atk:8,
        def:2,
        gold:500,
        bag:[],
        bagMax:12,
        potion:3,
        equip:{
            weapon:null,
            hat:null,
            cloth:null,
            shoe:null,
            belt:null,
            ring1:null,
            ring2:null,
            accessory:null
        },
        taskProgress:{},
        bountyKilled:{}
    };

    Object.keys(equipData).forEach(k=>{
        equipData[k].refineCount = 0;
        equipData[k].refineAtk = 0;
        equipData[k].refineDef = 0;
        equipData[k].refineHp = 0;
    });

    currentAreaState = null;
    refreshUi();
    addBattleLog("✅游戏已重置");
}
