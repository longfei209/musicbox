//地图弹窗相关-进入区域楼层
function enterArea(areaIdx){
    closeAllModal();
    const area = areaData[areaIdx];
    currentAreaState = {
        areaIndex: areaIdx,
        floorUnlocked:[true,false,false],
        floors:[],
        floorKilledTypes:[[],[],[]] //保存每层击杀过的怪物种类，刷新怪物不清空
    };
    for(let f=0;f<3;f++){
        const floorData = area.floors[f];
        let monsterList = [];
        floorData.monsterSpawnList.forEach(mName=>{
            monsterList.push({
                name:mName,
                alive:true
            })
        })
        currentAreaState.floors.push({
            monsters:monsterList,
            bossAlive:true
        })
    }
    renderFloorModal();
}

//【核心判定】检查本层：每种怪物至少击杀1只，就解锁下一层
function checkFloorUnlock(floorIdx){
    const area = areaData[currentAreaState.areaIndex];
    const floorDef = area.floors[floorIdx];
    const uniqueTypes = [...new Set(floorDef.monsterSpawnList)];
    const killedList = currentAreaState.floorKilledTypes[floorIdx];

    let allTypeKilled = true;
    for(let typeName of uniqueTypes){
        if(!killedList.includes(typeName)){
            allTypeKilled = false;
            break;
        }
    }
    if(allTypeKilled && floorIdx+1 <3 && !currentAreaState.floorUnlocked[floorIdx+1]){
        currentAreaState.floorUnlocked[floorIdx+1] = true;
        addBattleLog(`🔓【第${floorIdx+1}层每种怪物已击杀至少一只，大门印记点亮，解锁第${floorIdx+2}层！】`);
    }
    renderFloorModal();
}

function renderFloorModal(){
    const area = areaData[currentAreaState.areaIndex];
    document.getElementById("floorModal").style.display="block";
    let html = `<h3>${area.name}</h3>`;
    for(let f=0;f<3;f++){
        const floorData = area.floors[f];
        const stateFloor = currentAreaState.floors[f];
        const unlock = currentAreaState.floorUnlocked[f];
        html += `<div style="border:1px solid #555;padding:8px;margin:4px 0;border-radius:4px;">`;
        html += `<div>【第${f+1}层】`;
        if(!unlock){
            html += `<span style="color:red">🔒未解锁，打完上一层每种怪至少1只解锁</span>`;
        }else{
            html += `<span style="color:#4f8">✅已解锁</span>`;
        }
        html += `</div>`;
        if(unlock){
            html += `<div>`;
            stateFloor.monsters.forEach((m,mid)=>{
                const baseM = monstersDict[m.name];
                const rate = floorData.multiplier;
                const showHp = Math.round(baseM.hp * rate);
                const showAtk = Math.round(baseM.atk * rate);
                if(m.alive){
                    html += `<button class="btn" onclick="startFloorBattle(${f},${mid})">${m.name} HP:${showHp} ATK:${showAtk}</button>`;
                }else{
                    html += `<span style="color:#888">☠️${m.name} 已击杀</span>`;
                }
            })
            //BOSS
            if(floorData.boss){
                const bossBase = monstersDict[floorData.boss];
                const bHp = Math.round(bossBase.hp * floorData.multiplier);
                const bAtk = Math.round(bossBase.atk * floorData.multiplier);
                if(stateFloor.bossAlive){
                    html += `<button class="btn btn-red" onclick="startBossBattle(${f})">👹BOSS ${floorData.boss} HP:${bHp} ATK:${bAtk}</button>`;
                }else{
                    html += `<span style="color:#888">☠️BOSS ${floorData.boss} 已击杀</span>`;
                }
            }
            html += `</div>`;
        }
        html += `</div>`;
    }
    document.getElementById("floorTitle").innerText = `${area.name} - 楼层选择`;
    document.getElementById("floorInfo").innerHTML = html;
    document.getElementById("monsterList").innerHTML = "";
}

//开始普通怪战斗
function startFloorBattle(floorIdx, monsterIdx){
    closeAllModal();
    const area = areaData[currentAreaState.areaIndex];
    const floorData = area.floors[floorIdx];
    const stateFloor = currentAreaState.floors[floorIdx];
    const monsterInst = stateFloor.monsters[monsterIdx];
    const baseM = monstersDict[monsterInst.name];
    const rate = floorData.multiplier;
    battleState.active = true;
    battleState.auto = false;
    battleState.monster = {
        name:baseM.name,
        hp:Math.round(baseM.hp*rate),
        currentHp:Math.round(baseM.hp*rate),
        atk:Math.round(baseM.atk*rate),
        def:Math.round(baseM.def*rate),
        exp:Math.round(baseM.exp*rate),
        gMin:Math.round(baseM.gMin*rate),
        gMax:Math.round(baseM.gMax*rate),
        drop:baseM.drop,
        isBoss:false,
        floorIdx,monsterIdx
    };
    battleState.skillCd = 0;
    battleLogDom.innerText = "";
    document.getElementById("battleMonsterName").innerText = battleState.monster.name;
    refreshBattleUI();
    refreshSkillButton();
    document.getElementById("battlePanel").style.display="block";
    document.getElementById("autoText").innerText = "关闭";
    addBattleLog(`⚔️战斗开始！对手：${battleState.monster.name}`);
}

//BOSS战斗
function startBossBattle(floorIdx){
    closeAllModal();
    const area = areaData[currentAreaState.areaIndex];
    const floorData = area.floors[floorIdx];
    const stateFloor = currentAreaState.floors[floorIdx];
    const bossName = floorData.boss;
    const baseM = monstersDict[bossName];
    const rate = floorData.multiplier;
    battleState.active = true;
    battleState.auto = false;
    battleState.monster = {
        name:baseM.name,
        hp:Math.round(baseM.hp*rate),
        currentHp:Math.round(baseM.hp*rate),
        atk:Math.round(baseM.atk*rate),
        def:Math.round(baseM.def*rate),
        exp:Math.round(baseM.exp*rate),
        gMin:Math.round(baseM.gMin*rate),
        gMax:Math.round(baseM.gMax*rate),
        drop:baseM.drop,
        isBoss:true,
        floorIdx
    };
    battleState.skillCd = 0;
    battleLogDom.innerText = "";
    document.getElementById("battleMonsterName").innerText = battleState.monster.name;
    refreshBattleUI();
    refreshSkillButton();
    document.getElementById("battlePanel").style.display="block";
    document.getElementById("autoText").innerText = "关闭";
    addBattleLog(`⚔️BOSS战开始！对手：${battleState.monster.name}`);
}

function refreshBattleUI(){
    document.getElementById("monsterHpText").innerText = `${Math.round(battleState.monster.currentHp)}/${battleState.monster.hp}`;
    let attr = getTotalAttr();
    document.getElementById("playerHpText").innerText = `${Math.round(player.hp)}/${player.hpMax+attr.hpBonus}`;
}
function refreshSkillButton(){
    if(battleState.skillCd>0){
        skillBtn.disabled = true;
        skillBtn.innerText = `烈火剑法 (${battleState.skillCd}回合)`;
    }else{
        skillBtn.disabled = false;
        skillBtn.innerText = "烈火剑法";
    }
}
function reduceSkillCd(){
    if(battleState.skillCd>0){
        battleState.skillCd--;
        refreshSkillButton();
    }
}

async function battleAttack(){
    if(!battleState.active) return;
    let attr = getTotalAttr();
    let isCrit = Math.random()<0.12;
    let baseDmg = Math.max(1, attr.atk - battleState.monster.def + (Math.random()*5-2));
    let dmg = isCrit ? baseDmg*2 : baseDmg;
    battleState.monster.currentHp -= dmg;
    if(isCrit) addBattleLog(`💥暴击！造成${Math.round(dmg)}伤害`);
    else addBattleLog(`攻击，造成${Math.round(dmg)}伤害`);
    refreshBattleUI();
    await checkMonsterDead();
    if(!battleState.active) return;
    reduceSkillCd();
    await monsterTurn();
}

async function battleSkill(){
    if(!battleState.active) return;
    if(battleState.skillCd>0) return;
    let attr = getTotalAttr();
    let baseDmg = Math.max(1, attr.atk - battleState.monster.def + (Math.random()*5-2));
    let dmg = baseDmg * 1.8;
    battleState.monster.currentHp -= dmg;
    addBattleLog(`🔥烈火剑法！造成${Math.round(dmg)}伤害`);
    battleState.skillCd = battleState.skillMaxCd;
    refreshSkillButton();
    refreshBattleUI();
    await checkMonsterDead();
    if(!battleState.active) return;
    reduceSkillCd();
    await monsterTurn();
}

async function battleUsePotion(){
    if(!battleState.active) return;
    if(player.potion<=0){
        addBattleLog("❌没有红药水！");
        return;
    }
    let attr = getTotalAttr();
    if(player.hp >= player.hpMax+attr.hpBonus){
        addBattleLog("血量已满，无需吃药");
        return;
    }
    player.potion -=1;
    player.hp = Math.min(player.hp+60, player.hpMax+attr.hpBonus);
    addBattleLog("✅喝下红药，HP+60");
    refreshBattleUI();
    refreshUi();
    reduceSkillCd();
    await monsterTurn();
}

function battleRun(){
    if(!battleState.active) return;
    let runSuccess = Math.random() < 0.7;
    if(runSuccess){
        addBattleLog("🏃逃跑成功！");
        endBattle(false);
    }else{
        addBattleLog("❌逃跑失败！怪物发起攻击！");
        reduceSkillCd();
        monsterTurn();
    }
}

async function monsterTurn(){
    await sleep(400);
    let m = battleState.monster;
    let attr = getTotalAttr();
    let mCrit = Math.random()<0.08;
    let baseMdmg = Math.max(1, m.atk - attr.def + (Math.random()*4-2));
    let mdmg = mCrit ? baseMdmg*2 : baseMdmg;
    player.hp -= mdmg;
    if(mCrit) addBattleLog(`⚠️怪物暴击！受到${Math.round(mdmg)}伤害`);
    else addBattleLog(`${m.name}反击，受到${Math.round(mdmg)}伤害`);
    refreshBattleUI();
    refreshUi();
    await checkPlayerDead();
}

async function checkMonsterDead(){
    if(battleState.monster.currentHp <=0){
        let m = battleState.monster;
        addBattleLog(`✅击杀【${m.name}】！`);
        let getGold = Math.floor(Math.random()*(m.gMax - m.gMin)+m.gMin);
        player.gold += getGold;
        player.exp += m.exp;
        addBattleLog(`金币+${getGold}，经验+${m.exp}`);

        npcTaskList.forEach(t=>{
            if(t.target === m.name){
                if(!player.taskProgress[t.id]) player.taskProgress[t.id]=0;
                player.taskProgress[t.id]++;
            }
        })
        bountyList.forEach(b=>{
            if(b.name === m.name){
                if(!player.bountyKilled[b.name]) player.bountyKilled[b.name]=0;
                player.bountyKilled[b.name]++;
            }
        })

        levelUp();
        //装备掉落
        for(let [item,rate] of m.drop){
            let r = Math.random()*100;
            if(r <= rate){
                if(player.bag.length >= player.bagMax){
                    addBattleLog(`⚠️【${item}】背包满捡不起`);
                }else{
                    player.bag.push(item);
                    addBattleLog(`✨爆出【${item}】`);
                }
            }
        }
        refreshUi();

        //标记怪物死亡，记录怪物类型到印记，怪物刷新不会清空印记
        if(m.isBoss){
            currentAreaState.floors[m.floorIdx].bossAlive = false;
        }else{
            currentAreaState.floors[m.floorIdx].monsters[m.monsterIdx].alive = false;
            const killType = m.name;
            const arr = currentAreaState.floorKilledTypes[m.floorIdx];
            if(!arr.includes(killType)){
                arr.push(killType);
            }
        }
        checkFloorUnlock(m.floorIdx);

        setTimeout(()=>{
            const floorState = currentAreaState.floors[m.floorIdx];
            floorState.monsters.forEach(mon=>mon.alive=true);
            floorState.bossAlive = true;
            addBattleLog(`🔄本层怪物已全部刷新！`);
            renderFloorModal();
        },800);

        await sleep(600);
        endBattle(true);
    }
}

async function checkPlayerDead(){
    if(player.hp <=0){
        addBattleLog("💀你被击败！");
        player.gold = Math.floor(player.gold*0.9);
        player.hp = player.hpMax;
        addBattleLog("损失10%金币，回城复活");
        refreshUi();
        await sleep(800);
        endBattle(false);
    }
}

function toggleAutoBattle(){
    battleState.auto = !battleState.auto;
    document.getElementById("autoText").innerText = battleState.auto ? "开启" : "关闭";
    if(battleState.auto){
        autoBattleLoop();
    }else{
        clearTimeout(battleState.autoTimer);
    }
}
async function autoBattleLoop(){
    if(!battleState.active || !battleState.auto) return;
    await battleAttack();
    battleState.autoTimer = setTimeout(autoBattleLoop,1200);
}

function endBattle(isWin){
    battleState.active = false;
    battleState.auto = false;
    clearTimeout(battleState.autoTimer);
    document.getElementById("battlePanel").style.display="none";
    renderFloorModal();
}
