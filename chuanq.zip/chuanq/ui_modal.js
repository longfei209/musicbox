//关闭全部弹窗
function closeAllModal(){
    document.getElementById("mapModal").style.display="none";
    document.getElementById("floorModal").style.display="none";
    document.getElementById("shopModal").style.display="none";
    document.getElementById("bagModal").style.display="none";
    document.getElementById("npcTaskModal").style.display="none";
    document.getElementById("bountyModal").style.display="none";
    document.getElementById("refineModal").style.display="none";
    document.getElementById("equipModal").style.display="none";
}

//地图弹窗
function openMapModal(){
    closeAllModal();
    document.getElementById("mapModal").style.display="block";
    let html = "";
    areaData.forEach((area,idx)=>{
        html += `<button class="btn" onclick="enterArea(${idx})">${area.name}</button>`;
    })
    document.getElementById("areaList").innerHTML = html;
}

//装备弹窗
function openEquipModal(){
    closeAllModal();
    document.getElementById("equipModal").style.display="block";
    let html = "";
    equipSlotList.forEach(slot=>{
        let equipName = player.equip[slot.key];
        if(equipName){
            html += `<div class="equipSlot" onclick="takeOffEquip('${slot.key}')">${slot.name}:${equipName}<br/>点击脱下</div>`;
        }else{
            html += `<div class="equipSlot">${slot.name}:空</div>`;
        }
    })
    document.getElementById("equipSlotBox").innerHTML = html;
}
//脱下装备
function takeOffEquip(slotKey){
    let itemName = player.equip[slotKey];
    if(!itemName) return;
    if(player.bag.length >= player.bagMax){
        addBattleLog("❌背包已满，无法脱下装备！");
        return;
    }
    player.bag.push(itemName);
    player.equip[slotKey] = null;
    addBattleLog(`✅脱下【${itemName}】放入背包`);
    openEquipModal();
    refreshUi();
}

//背包弹窗
function openBagModal(){
    closeAllModal();
    document.getElementById("bagModal").style.display="block";
    renderBag();
}
function renderBag(){
    let html="";
    if(player.bag.length===0){
        html="<p>背包为空</p>";
    }else{
        player.bag.forEach((item,idx)=>{
            html += `<div class="grid2">
                <span>${item}</span>
                <div>
                    <button class="itemBtn" onclick="wearItem(${idx})">穿戴</button>
                    <button class="itemBtn" onclick="dropItem(${idx})">丢弃</button>
                </div>
            </div>`
        })
    }
    document.getElementById("bagItemList").innerHTML = html;
}
//穿戴装备，自动匹配槽位
function wearItem(idx){
    const itemName = player.bag[idx];
    if(!equipData[itemName]){
        addBattleLog(`${itemName}不可穿戴！`);
        return;
    }
    let info = equipData[itemName];
    let targetSlot = null;
    for(let s of equipSlotList){
        if(info.type === s.key){
            targetSlot = s.key;
            break;
        }
    }
    if(targetSlot === null){
        addBattleLog("❌找不到对应穿戴槽位！");
        return;
    }
    if(player.equip[targetSlot]){
        if(player.bag.length >= player.bagMax){
            addBattleLog("❌背包满，无法替换装备！");
            return;
        }
        player.bag.push(player.equip[targetSlot]);
    }
    player.equip[targetSlot] = itemName;
    player.bag.splice(idx,1);
    addBattleLog(`✅穿戴【${itemName}】`);
    renderBag();
    refreshUi();
}
function dropItem(idx){
    const dropName = player.bag.splice(idx,1)[0];
    addBattleLog(`丢弃【${dropName}】`);
    renderBag();
    refreshUi();
}

//商店弹窗
function openShopModal(){
    closeAllModal();
    document.getElementById("shopModal").style.display="block";
    let html = `<h3>购买物品</h3>`;
    shopGoods.forEach(item=>{
        if(item.type==="buyEquip"){
            const e = equipData[item.name];
            html += `<button class="btn" onclick="buyEquip('${item.name}')">${item.name}｜${e.buy}金币</button>`;
        }else if(item.type==="potion"){
            html += `<button class="btn" onclick="buyPotion()">红药 30金币</button>`;
        }
    })
    //背包扩容：+4格，花费300金币
    html += `<br><button class="btn btn-green" onclick="expandBag()">背包扩容+4格（300金币）</button>`;
    html += `<br><h3>出售背包装备</h3><button class="btn btn-red" onclick="sellAllEquip()">一键卖出全部装备</button>`;
    document.getElementById("shopList").innerHTML = html;
}
function expandBag(){
    if(player.gold < 300){
        addBattleLog("❌金币不足，扩容需要300金币");
        return;
    }
    player.gold -= 300;
    player.bagMax +=4;
    addBattleLog(`✅背包扩容成功！上限+4格，当前上限：${player.bagMax}`);
    refreshUi();
    openShopModal();
}
function buyEquip(name){
    const e = equipData[name];
    if(player.gold < e.buy){
        addBattleLog("❌金币不足！");
        return;
    }
    if(player.bag.length >= player.bagMax){
        addBattleLog("❌背包已满！");
        return;
    }
    player.gold -= e.buy;
    player.bag.push(name);
    addBattleLog(`✅购买【${name}】成功！`);
    refreshUi();
}
function buyPotion(){
    if(player.gold>=30){
        player.gold -=30;
        player.potion +=1;
        addBattleLog("✅购买红药×1");
    }else{
        addBattleLog("❌金币不足");
    }
    refreshUi();
}
function sellAllEquip(){
    let total=0;
    let newBag=[];
    for(let name of player.bag){
        if(equipData[name]){
            total+=equipData[name].sell;
        }else{
            newBag.push(name);
        }
    }
    player.bag = newBag;
    player.gold += total;
    addBattleLog(`✅卖出装备，获得 ${total} 金币`);
    refreshUi();
}

//任务弹窗
function openNpcTaskModal(){
    closeAllModal();
    document.getElementById("npcTaskModal").style.display="block";
    let html="";
    npcTaskList.forEach(t=>{
        let progress = player.taskProgress[t.id]||0;
        let finish = progress >= t.killNum;
        html += `<div style="margin:4px 0;padding:4px;border:1px solid #555;border-radius:4px;">
        <div>${t.name}：${t.desc}</div>
        <div>进度：${progress}/${t.killNum}｜奖励：${t.rewardGold}金 ${t.rewardExp}经验</div>
        ${finish?`<button class="btn" onclick="claimTaskReward(${t.id})">领取奖励</button>`:"<span>进行中</span>"}
        </div>`;
    })
    document.getElementById("taskList").innerHTML = html;
}
function claimTaskReward(tid){
    const task = npcTaskList.find(x=>x.id===tid);
    player.gold += task.rewardGold;
    player.exp += task.rewardExp;
    player.taskProgress[tid] = 9999;
    addBattleLog(`✅任务【${task.name}】完成，领取奖励！`);
    levelUp();
    refreshUi();
    openNpcTaskModal();
}

//悬赏弹窗
function openBountyModal(){
    closeAllModal();
    document.getElementById("bountyModal").style.display="block";
    let html="";
    bountyList.forEach(b=>{
        let killed = player.bountyKilled[b.name]||0;
        let finish = killed >= b.killNeed;
        html += `<div style="margin:4px 0;padding:4px;border:1px solid #555;border-radius:4px;">
        <div>悬赏：${b.name}</div>
        <div>已击杀：${killed}/${b.killNeed}｜奖励：${b.rewardGold}金 ${b.rewardExp}经验</div>
        ${finish?`<button class="btn" onclick="claimBounty('${b.name}')">领取悬赏奖励</button>`:"<span>猎杀中</span>"}
        </div>`;
    })
    document.getElementById("bountyList").innerHTML = html;
}
function claimBounty(name){
    const b = bountyList.find(x=>x.name===name);
    player.gold += b.rewardGold;
    player.exp += b.rewardExp;
    player.bountyKilled[name] = 9999;
    addBattleLog(`✅悬赏【${name}】完成，领取奖励！`);
    levelUp();
    refreshUi();
    openBountyModal();
}

//洗练弹窗
function openRefineModal(){
    closeAllModal();
    document.getElementById("refineModal").style.display="block";
    let html="<p>洗练消耗：100金币，每件装备最多洗3次，属性不会负数</p>";
    const equipList = [...player.bag];
    for(let k in player.equip){
        if(player.equip[k]) equipList.push(player.equip[k]);
    }
    let uniqueEquip = [...new Set(equipList)];
    uniqueEquip.forEach(item=>{
        if(!equipData[item]) return;
        let e = equipData[item];
        html += `<button class="btn" onclick="refineEquip('${item}')">【${item}】已洗${e.refineCount}/3次｜攻击+${e.refineAtk} 防御+${e.refineDef} 血量+${e.refineHp}</button>`;
    })
    document.getElementById("refineList").innerHTML = html;
}

//洗练核心逻辑
function refineEquip(name){
    if(player.gold <100){
        addBattleLog("❌金币不足，洗练需要100金币");
        return;
    }
    let e = equipData[name];
    if(e.refineCount >=3){
        addBattleLog(`❌【${name}】已达到最大洗练次数（最多3次）`);
        return;
    }
    player.gold -=100;
    //计算全部洗练属性总和，用来算破损概率
    let totalBonus = e.refineAtk + e.refineDef + e.refineHp;
    let breakRate = Math.min(totalBonus * 2.5, 50);
    let roll = Math.random()*100;
    if(roll < breakRate){
        //破损：全部洗练加成清零，次数重置
        e.refineAtk = 0;
        e.refineDef = 0;
        e.refineHp = 0;
        e.refineCount = 0;
        addBattleLog(`💥【${name}】洗练破损！全部洗练加成清零，洗练次数重置！`);
    }else{
        let addText = "";
        //武器：洗攻击
        if(e.type === "weapon"){
            let newVal = Math.floor(Math.random()*5)+1;
            e.refineAtk = newVal;
            addText = `攻击+${newVal}`;
        }
        //防具：衣服/帽子/鞋子/腰带 → 防御
        else if(["cloth","hat","shoe","belt"].includes(e.type)){
            let newVal = Math.floor(Math.random()*4)+1;
            e.refineDef = newVal;
            addText = `防御+${newVal}`;
        }
        //首饰戒指：随机攻击/防御/血量上限，保证≥0
        else if(["ring","accessory"].includes(e.type)){
            let rnd = Math.floor(Math.random()*3);
            let newVal = Math.floor(Math.random()*5)+1;
            if(rnd ===0){
                e.refineAtk = newVal;
                addText = `攻击+${newVal}`;
            }else if(rnd ===1){
                e.refineDef = newVal;
                addText = `防御+${newVal}`;
            }else{
                e.refineHp = newVal;
                addText = `血量上限+${newVal}`;
            }
        }
        e.refineCount +=1;
        addBattleLog(`✨洗练【${name}】成功，本次${addText}，已洗${e.refineCount}/3次`);
    }
    refreshUi();
    openRefineModal();
}
