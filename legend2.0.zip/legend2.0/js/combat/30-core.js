/* ============================================================
 *  combat/30-core.js  —— 战斗核心工具
 *  伤害公式 / 飘字 / 冲锋 / 结算弹窗 / 掉落收集
 * ============================================================ */

function _sleep(ms){ return new Promise(r => setTimeout(r, ms)); }

function showBattleDrop(text){
  const el = $('bDrop');
  if(!el) return;
  el.textContent = text;
  el.classList.add('on');
  clearTimeout(el._t);
  el._t = setTimeout(()=>el.classList.remove('on'), 2400);
}

function _hitMonsterAnim(m, isCrit){
  const card = document.getElementById('mon-' + m.mid);
  if(!card) return;
  card.classList.remove('anim-hit-shake','anim-hit-flash','anim-hit-crit');
  void card.offsetWidth;
  card.classList.add('anim-hit-shake');
  card.classList.add(isCrit ? 'anim-hit-crit' : 'anim-hit-flash');
  setTimeout(()=>{
    card.classList.remove('anim-hit-shake','anim-hit-flash','anim-hit-crit');
  }, 500);
}
function _hitPlayerAnim(){
  const el = $('pBox');
  if(!el) return;
  el.classList.remove('anim-hit-shake');
  void el.offsetWidth;
  el.classList.add('anim-hit-shake');
  setTimeout(()=>el.classList.remove('anim-hit-shake'), 450);
}
function _healPlayerAnim(){
  const el = $('pBox');
  if(!el) return;
  el.classList.remove('anim-heal-glow');
  void el.offsetWidth;
  el.classList.add('anim-heal-glow');
  setTimeout(()=>el.classList.remove('anim-heal-glow'), 700);
}
function _buffPlayerAnim(){
  const el = $('pBox');
  if(!el) return;
  el.classList.remove('anim-buff-glow');
  void el.offsetWidth;
  el.classList.add('anim-buff-glow');
  setTimeout(()=>el.classList.remove('anim-buff-glow'), 800);
}

async function _chargeTo(attackerEl, targetEl, moveMs){
  if(!attackerEl || !targetEl) return;
  const a = attackerEl.getBoundingClientRect();
  const t = targetEl.getBoundingClientRect();
  const aCx = a.left + a.width/2;
  const aCy = a.top  + a.height/2;
  const tCx = t.left + t.width/2;
  const tCy = t.top  + t.height/2;
  const dx = tCx - aCx;
  const dy = tCy - aCy;
  const sign = dx >= 0 ? 1 : -1;
  const stopDist = (a.width/2 + t.width/2 + 4);
  const realDx = dx - sign * stopDist;
  attackerEl.style.zIndex = 200;
  attackerEl.style.transition = `transform ${moveMs}ms cubic-bezier(.4,0,.25,1)`;
  attackerEl.style.transform = `translate(${realDx}px, ${dy}px)`;
  await _sleep(moveMs);
  attackerEl.style.transition = `transform 90ms cubic-bezier(.2,0,.5,1)`;
  attackerEl.style.transform = `translate(${realDx + sign * 8}px, ${dy}px)`;
  await _sleep(90);
}
function _returnFromCharge(attackerEl, backMs){
  if(!attackerEl) return;
  attackerEl.style.transition = `transform ${backMs}ms cubic-bezier(.4,0,.2,1)`;
  attackerEl.style.transform = '';
  setTimeout(() => {
    attackerEl.style.transition = '';
    attackerEl.style.zIndex = '';
  }, backMs + 50);
}

function _popSkillEmoji(targetEl, emoji, fromTop, small){
  if(!targetEl || !emoji) return;
  const r = targetEl.getBoundingClientRect();
  const span = document.createElement('div');
  span.className = 'skill-emoji' + (small ? ' small' : '');
  span.textContent = emoji;
  span.style.left = (r.left + r.width/2) + 'px';
  span.style.top = fromTop ? (r.top - 40) + 'px' : (r.top + r.height/2) + 'px';
  document.body.appendChild(span);
  setTimeout(()=>{ if(span.parentNode) span.parentNode.removeChild(span); }, 950);
}
function _pulseCard(m, cls){
  const card = document.getElementById('mon-' + m.mid);
  if(!card) return;
  card.classList.remove(cls);
  void card.offsetWidth;
  card.classList.add(cls);
  setTimeout(()=>card.classList.remove(cls), 700);
}

/* 实际伤害 = 攻击 × (1 - defenseReduceRate(防御)) */
function calcDamage(attack, defense){
  const rate = defenseReduceRate(defense);
  return Math.max(1, Math.floor(attack * (1 - rate)));
}

function newBattleLoot(){
  return {
    exp: 0,
    petExp: 0,
    gold: 0,
    pages: 0,
    items: [],
    gems: [],
    frags: [],
    killedNames: []
  };
}

function _makeBossGuards(bossDef){
  const guards = [];
  for(let i=0;i<2;i++){
    const g = {
      mid: uid(), protoId: bossDef.id + '_guard_' + i,
      name: '精英·' + bossDef.name + '守卫',
      hp: Math.floor(bossDef.hp * 0.4),
      maxHp: Math.floor(bossDef.hp * 0.4),
      atk: Math.floor(bossDef.atk * 0.4),
      def: Math.floor(bossDef.def * 0.4),
      spd: bossDef.spd,
      exp: Math.floor(bossDef.exp * 0.5),
      gMin: Math.floor(bossDef.gMin * 0.5),
      gMax: Math.floor(bossDef.gMax * 0.5),
      behavior: 'normal',
      elite: true,
      isBossGuard: true,
      affixes: [],
      dead: false, deathTs: 0,
      vamp: 0, pois: 0, summonCount: 0, poison: null, slow: null
    };
    const af = pick(ELITE_AFFIXES);
    af.apply(g);
    g.affixes.push(af.k);
    guards.push(g);
  }
  return guards;
}

function _closeResultModal(){
  const el = $('resultModal');
  if(el) el.classList.add('hidden');
  const body = $('resultModalBody');
  if(body) body.innerHTML = '';
}

function _showBattleResult(loot, onConfirm){
  const lines = [];

  if(loot.killedNames.length > 0){
    lines.push(`<div class="result-kills"><span class="dim">击杀：</span>${loot.killedNames.join('、')}</div>`);
  }

  if(loot.exp > 0)   lines.push(`<div class="result-reward">经验 +${loot.exp}</div>`);
  if(loot.gold > 0)  lines.push(`<div class="result-reward">金币 +${loot.gold}</div>`);
  if(loot.pages > 0) lines.push(`<div class="result-reward">📖 书页 +${loot.pages}</div>`);

  const dropLines = [];
  loot.items.forEach(it=>{
    const q = QUALITY[it.quality];
    dropLines.push(`<div class="result-drop-line ${q.cls}">${it.name} <span class="dim">[${q.name}]</span></div>`);
  });
  loot.gems.forEach(g=>{
    const cfg = GEMS[g.key];
    const qCfg = GEM_QUALITY[g.quality];
    dropLines.push(`<div class="result-drop-line">${cfg.icon} ${cfg.name} <span class="dim">[${qCfg.name}]</span></div>`);
  });
  loot.frags.forEach(f=>{
    const cfg = GEMS[f.key];
    const qCfg = GEM_QUALITY[f.quality];
    dropLines.push(`<div class="result-drop-line">🧩 ${cfg.name}碎片 <span class="dim">[${qCfg.name}] ×${f.count}</span></div>`);
  });
  if(dropLines.length > 0){
    lines.push(`<div class="result-section-title">掉落：</div>`);
    lines.push(...dropLines);
  }

  const body = `
    <div class="modal-title">
      <span>🏆 战斗结束</span>
      <button class="modal-close" onclick="_closeResultModal()">✕</button>
    </div>
    <div class="result-body">${lines.join('')}</div>
    <div class="modal-actions" style="margin-top:10px;">
      <button class="btn primary" id="bResultOk">确定</button>
    </div>
  `;

  $('resultModalBody').innerHTML = body;
  $('resultModal').classList.remove('hidden');
  $('bResultOk').onclick = ()=>{
    _closeResultModal();
    onConfirm && onConfirm();
  };
}