/* ============================================================
 *  combat/34-monster.js  —— 怪物战斗行为
 *  定义 CombatMonster，由 combat/31-actions.js 合并进 CombatActions
 * ============================================================ */

const CombatMonster = {
  async _doMonsterActionAnimated(m, defMul, isAuto){
    const battleRef = Game.battle; if(!battleRef) return;
    const card = document.getElementById('mon-' + m.mid);

    const alivePets = getActivePetObjects().filter(p=>!p.deadInBattle);
    let targetEl = null;
    let targetIsPet = false;
    let targetPet = null;
    if(alivePets.length > 0 && Math.random() < 0.5){
      targetIsPet = true;
      targetPet = pick(alivePets);
      targetEl = document.getElementById('pet-' + targetPet.uid);
    }else{
      targetEl = $('pBox');
    }

    if(!isAuto && card && targetEl){
      await _chargeTo(card, targetEl, 220);
      if(Game.battle !== battleRef) return;
      this._doMonsterAction(m, defMul, { targetIsPet, targetPet });
      _returnFromCharge(card, 180);
      await _sleep(200);
    }else{
      this._doMonsterAction(m, defMul, { targetIsPet, targetPet });
    }
  },

  _doMonsterAction(m, defMul, presetTarget){
    const b = Game.battle; if(!b) return;
    if(m.dead) return;

    if(m.behavior === 'healer'){
      const allies = b.monsters.filter(x=>!x.dead && x !== m);
      if(allies.length > 0){
        const worst = allies.sort((a,b)=>a.hp/a.maxHp - b.hp/b.maxHp)[0];
        const heal = Math.floor(worst.maxHp * 0.15);
        worst.hp = Math.min(worst.maxHp, worst.hp + heal);
        this._floatMon(worst, `+${heal}`, 'heal');
        return;
      }
    }

    if(m.behavior === 'summon' && b.roundCount % 2 === 0){
      if(!m.summonCount) m.summonCount = 0;
      const aliveCount = b.monsters.filter(x=>!x.dead).length;
      if(m.summonCount < 2 && aliveCount < 5){
        const nm = {
          mid: uid(), protoId: m.protoId+'_sum_'+m.summonCount, name:'召唤小怪',
          hp: Math.floor(m.maxHp*0.3), maxHp: Math.floor(m.maxHp*0.3),
          atk: Math.floor(m.atk*0.5), def: Math.floor(m.def*0.5),
          spd: m.spd+2, exp: Math.floor(m.exp*0.2),
          gMin:1, gMax:5, behavior:'normal',
          elite:false, affixes:[], dead:false, deathTs:0, vamp:0, pois:0,
          summonCount: 0, poison: null, slow: null
        };
        b.monsters.push(nm);
        m.summonCount++;
        this.render();
      }
    }

    let atkVal = m.atk;
    if(m.behavior === 'rage' && m.hp/m.maxHp < 0.5) atkVal = Math.floor(atkVal * 1.5);
    const a = calcAttr();
    const defMulFinal = defMul > 1 ? 1.3 : 1;

    const targetIsPet = presetTarget && presetTarget.targetIsPet;
    const targetPet = presetTarget && presetTarget.targetPet;

    if(targetIsPet && targetPet && petAlive(targetPet) && !targetPet.deadInBattle){
      const pst = petStatFor(targetPet);
      let dmg = calcDamage(atkVal, pst.def * defMulFinal * 0.9);
      let isCrit = Math.random() < 0.08;
      if(isCrit) dmg = Math.floor(dmg * 1.25);
      petTakeDamage(targetPet, dmg);
      const petEl = document.getElementById('pet-' + targetPet.uid);
      if(petEl){
        petEl.classList.remove('anim-hit-shake');
        void petEl.offsetWidth;
        petEl.classList.add('anim-hit-shake');
        setTimeout(()=>petEl.classList.remove('anim-hit-shake'), 450);
      }
      this._floatPet(targetPet, `-${dmg}`, isCrit ? 'crit' : 'normal');
      if(!petAlive(targetPet) || targetPet.hp <= 0){
        targetPet.deadInBattle = true;
        targetPet.downUntil = Date.now() + PET_DOWN_MS;
        toast(`${targetPet.name} 倒下，本场不再出手`);
      }
      const ps = petSkillStateFor(targetPet);
      if(ps.reflect){
        const rdmg = Math.max(1, Math.floor(dmg * ps.reflect));
        m.hp -= rdmg;
        this._floatMon(m, `-${rdmg}`, 'reflect');
        if(m.hp <= 0 && !m.dead) this._killMonster(m);
      }
    }else{
      let dodgeRate = 0;
      getActivePetObjects().forEach(p=>{
        if(p.deadInBattle) return;
        const ps = petSkillStateFor(p);
        if(ps.dodge) dodgeRate = Math.max(dodgeRate, ps.dodge);
      });
      if(dodgeRate > 0 && Math.random() < dodgeRate){
        this._floatPlayer('闪避', 'heal');
        return;
      }

      const playerDef = rnd(a.defMin, a.defMax);
      let dmg = calcDamage(atkVal, playerDef * defMulFinal * 0.9);
      let isCrit = Math.random() < 0.08;
      if(isCrit) dmg = Math.floor(dmg * 1.25);

      let guardPets = getActivePetObjects().filter(p=>{
        const ps = petSkillStateFor(p);
        return ps.guard && petAlive(p) && !p.deadInBattle;
      });
      if(guardPets.length > 0){
        const totalGuard = guardPets.reduce((s,p)=>s + petSkillStateFor(p).guard, 0);
        const shared = Math.floor(dmg * Math.min(0.6, totalGuard));
        const per = Math.floor(shared / guardPets.length);
        guardPets.forEach(p=>{
          const wasAlive = petAlive(p) && !p.deadInBattle;
          petTakeDamage(p, per);
          this._floatPet(p, `护-${per}`, 'reflect');
          if(p.hp <= 0){
            p.deadInBattle = true;
            p.downUntil = Date.now() + PET_DOWN_MS;
            /* ★ 修复：护主倒下时也给出 toast，避免宠物"凭空消失" */
            if(wasAlive) toast(`${p.name} 护主倒下，本场不再出手`);
          }
        });
        dmg -= shared;
      }

      Game.player.hp -= dmg;
      if(dmg > 0){
        _hitPlayerAnim();
        this._floatPlayer(`-${dmg}`, isCrit ? 'crit' : 'normal');
      }

      let totalReflect = 0;
      getActivePetObjects().forEach(p=>{
        const ps = petSkillStateFor(p);
        if(ps.reflect) totalReflect += ps.reflect;
      });
      if(totalReflect > 0){
        const rdmg = Math.max(1, Math.floor(dmg * totalReflect));
        m.hp -= rdmg;
        this._floatMon(m, `-${rdmg}`, 'reflect');
        if(m.hp <= 0 && !m.dead) this._killMonster(m);
      }

      if(!m.dead && Math.random() < a.counter){
        const counterDmg = calcDamage(rnd(a.atkMin, a.atkMax), m.def);
        m.hp -= counterDmg;
        _hitMonsterAnim(m, false);
        this._floatMon(m, `[反击]-${counterDmg}`, 'normal');
        if(m.hp <= 0 && !m.dead) this._killMonster(m);
      }
    }

    if(m.vamp) m.hp = Math.min(m.maxHp, m.hp + Math.floor(atkVal * m.vamp * 0.5));
    if(m.pois && !targetIsPet){
      Game.player.hp -= m.pois;
      this._floatPlayer(`-${m.pois}`, 'poison');
    }
  }
};