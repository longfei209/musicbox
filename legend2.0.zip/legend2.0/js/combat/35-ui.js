/* ============================================================
 *  combat/35-ui.js  —— 战斗界面渲染
 *  定义为独立对象 CombatUI，由 render/68-nav.js 合并进 Combat
 * ============================================================ */

const CombatUI = {
  render(){
    const b = Game.battle; if(!b) return;
    const ar = AREA_MAP[Game.ui.areaId];
    const fi = Game.ui.floorIdx;
    $('bLoc').textContent = b.kind === 'boss'
      ? `${ar.name} 第${fi+1}层 · BOSS`
      : `${ar.name} 第${fi+1}层 · ${b.group ? b.group.name : ''}`;

    this._renderLeft(b);
    this._renderMonsters(b);
    this._renderSkillBtns(b);
    this._renderTip(b);
  },

  _monsterHpBarClass(m){
    if(m.poison && m.poison.turns > 0) return 'poisoned';
    const pct = m.hp / m.maxHp;
    if(pct < 0.20) return 'hp-low';
    if(pct < 0.50) return 'hp-mid';
    return '';
  },

  _renderLeft(b){
    /* ★ 修复：删除了这里未使用的 const a = calcAttr(); 该调用遍历全装备开销较大 */
    const mHp = playerMaxHp(), mMp = playerMaxMp();
    const hpP = clamp(Game.player.hp/mHp,0,1)*100;
    const mpP = clamp(Game.player.mp/mMp,0,1)*100;
    const rage = Game.player.rage || 0;
    const zsActive = b.buff.zhanshen > 0;

    let pBox = $('pBox');
    if(!pBox){
      const activePetObjs = Game.activePets
        .map(u => Game.pets.find(p=>p.uid === u))
        .filter(Boolean);
      let petHtml = '';
      activePetObjs.forEach(p=>{ petHtml += this._petBoxHtml(p); });

      $('bLeft').innerHTML = `
        <div class="unit-box p-box ${zsActive?'zs-active':''}" id="pBox">
          <div class="u-emoji">🧙</div>
          <div class="u-lv">Lv.${Game.player.lv}</div>
          <div class="u-bar hp">
            <i style="width:${hpP}%"></i>
            <span class="u-num">${Math.floor(Game.player.hp)}</span>
          </div>
          <div class="u-bar mp">
            <i style="width:${mpP}%"></i>
            <span class="u-num">${Math.floor(Game.player.mp)}</span>
          </div>
        </div>
        <div class="rage-line">怒 ${rage}/${RAGE_MAX}</div>
        <div id="petList" style="display:flex;flex-direction:column;gap:6px;align-items:center;">${petHtml}</div>
      `;
      return;
    }

    const lvEl = pBox.querySelector('.u-lv');
    const wantLv = 'Lv.' + Game.player.lv;
    if(lvEl.textContent !== wantLv) lvEl.textContent = wantLv;

    const hpBar = pBox.querySelector('.u-bar.hp');
    hpBar.querySelector('i').style.width = hpP + '%';
    hpBar.querySelector('.u-num').textContent = Math.floor(Game.player.hp);

    const mpBar = pBox.querySelector('.u-bar.mp');
    mpBar.querySelector('i').style.width = mpP + '%';
    mpBar.querySelector('.u-num').textContent = Math.floor(Game.player.mp);

    if(zsActive) pBox.classList.add('zs-active');
    else pBox.classList.remove('zs-active');

    const rageEl = $('bLeft').querySelector('.rage-line');
    if(rageEl){
      const wantRage = `怒 ${rage}/${RAGE_MAX}`;
      if(rageEl.textContent !== wantRage) rageEl.textContent = wantRage;
    }

    this._renderPets();
  },

  _petBoxHtml(p){
    const maxHp = petStatFor(p).hp;
    const hpPct = clamp(p.hp/maxHp, 0, 1) * 100;
    const isDown = p.deadInBattle || !petAlive(p);
    if(isDown){
      let txt = p.deadInBattle ? '倒下' : (Math.ceil((p.downUntil - Date.now())/1000) + 's');
      return `<div class="unit-box pet-box-single down" id="pet-${p.uid}">
        <div class="u-emoji">${p.avatar}</div>
        <div class="u-lv">${txt}</div>
        <div class="u-bar hp pet-hp"><i style="width:0%"></i></div>
      </div>`;
    }
    return `<div class="unit-box pet-box-single" id="pet-${p.uid}">
      <div class="u-emoji">${p.avatar}</div>
      <div class="u-lv">Lv.${p.lv}</div>
      <div class="u-bar hp pet-hp">
        <i style="width:${hpPct}%"></i>
        <span class="u-num">${Math.floor(p.hp)}</span>
      </div>
    </div>`;
  },

  _renderPets(){
    const petList = $('petList');
    if(!petList) return;
    const activePetObjs = Game.activePets
      .map(u => Game.pets.find(p=>p.uid === u))
      .filter(Boolean);

    const wantIds = new Set(activePetObjs.map(p => 'pet-' + p.uid));
    [...petList.children].forEach(el=>{
      if(!wantIds.has(el.id)) el.remove();
    });

    activePetObjs.forEach(p=>{
      const exist = document.getElementById('pet-' + p.uid);
      if(exist){
        this._updatePetBox(exist, p);
      }else{
        const wrap = document.createElement('div');
        wrap.innerHTML = this._petBoxHtml(p);
        petList.appendChild(wrap.firstElementChild);
      }
    });
  },

  _updatePetBox(el, p){
    const maxHp = petStatFor(p).hp;
    const hpPct = clamp(p.hp/maxHp, 0, 1) * 100;
    const isDown = p.deadInBattle || !petAlive(p);
    const lvEl = el.querySelector('.u-lv');
    const hpBar = el.querySelector('.u-bar.hp');

    if(isDown){
      el.classList.add('down');
      let txt = p.deadInBattle ? '倒下' : (Math.ceil((p.downUntil - Date.now())/1000) + 's');
      if(lvEl.textContent !== txt) lvEl.textContent = txt;
      const i = hpBar.querySelector('i');
      if(i) i.style.width = '0%';
      const num = hpBar.querySelector('.u-num');
      if(num) num.remove();
    }else{
      el.classList.remove('down');
      const wantLv = 'Lv.' + p.lv;
      if(lvEl.textContent !== wantLv) lvEl.textContent = wantLv;
      let i = hpBar.querySelector('i');
      let num = hpBar.querySelector('.u-num');
      if(!num){
        num = document.createElement('span');
        num.className = 'u-num';
        hpBar.appendChild(num);
      }
      i.style.width = hpPct + '%';
      num.textContent = Math.floor(p.hp);
    }
  },

  _renderMonsters(b){
    const grid = $('bGrid');

    const wantIds = new Set(b.monsters.map(m => 'mon-' + m.mid));
    [...grid.children].forEach(el=>{
      if(!wantIds.has(el.id)) el.remove();
    });

    b.monsters.forEach((m, i)=>{
      const exist = document.getElementById('mon-' + m.mid);
      if(exist){
        this._updateMonsterCard(exist, m, i);
      }else{
        grid.appendChild(this._buildMonsterCard(m, i));
      }
    });
  },

  _buildMonsterCard(m, i){
    const card = document.createElement('div');
    card.className = 'unit-box mon-unit clickable';
    if(m.dead) card.classList.add('dead');
    if(m.elite) card.classList.add('elite');
    if(m.isBoss) card.classList.add('boss');
    card.id = 'mon-' + m.mid;

    const hP = clamp(m.hp/m.maxHp, 0, 1) * 100;
    const hpCls = this._monsterHpBarClass(m);
    const tag = m.isBoss ? '👹' : (m.elite ? '★' : '🐾');
    const shortName = m.name.length > 4 ? m.name.slice(0,4) : m.name;
    const poisonTag = (m.poison && m.poison.turns > 0) ? '<span style="color:#c8a;font-size:9px;">☠</span>' : '';

    card.innerHTML = `
      <div class="u-emoji">${tag}</div>
      <div class="u-name">${shortName}${poisonTag}</div>
      <div class="u-bar hp ${hpCls}">
        <i style="width:${hP}%"></i>
        <span class="u-num">${Math.max(0,Math.floor(m.hp))}</span>
      </div>
    `;
    card.onclick = () => this.clickMonster(i);
    return card;
  },

  _updateMonsterCard(card, m, i){
    if(m.dead) card.classList.add('dead');
    else card.classList.remove('dead');

    const hpBar = card.querySelector('.u-bar.hp');
    const hP = clamp(m.hp/m.maxHp, 0, 1) * 100;
    hpBar.querySelector('i').style.width = hP + '%';
    hpBar.querySelector('.u-num').textContent = Math.max(0, Math.floor(m.hp));

    const wantCls = this._monsterHpBarClass(m);
    ['hp-low','hp-mid','poisoned'].forEach(c => hpBar.classList.remove(c));
    if(wantCls) hpBar.classList.add(wantCls);

    const nameEl = card.querySelector('.u-name');
    const shortName = m.name.length > 4 ? m.name.slice(0,4) : m.name;
    const poisonTag = (m.poison && m.poison.turns > 0) ? '<span style="color:#c8a;font-size:9px;">☠</span>' : '';
    const wantHtml = shortName + poisonTag;
    if(nameEl.innerHTML !== wantHtml) nameEl.innerHTML = wantHtml;

    card.onclick = () => this.clickMonster(i);
  },

  _renderSkillBtns(b){
    this._refreshSkillBtn('bSkill1', 'liehuo');
    this._refreshSkillBtn('bSkill2', 'banyue');
    this._refreshSkillBtn('bSkill3', 'zhiyu');
    this._refreshSkillBtn('bSkill4', 'du');
    this._refreshSkillBtn('bSkill5', 'zhanshen');
    $('bRageBtn').disabled = (Game.player.rage || 0) < RAGE_MAX;

    const potBtn = $('bPotionBtn');
    if(potBtn){
      const lbl = potBtn.querySelector('.btn-label');
      if(lbl){
        const want = `红药<span class="cd-tag">${Game.player.potion}</span>`;
        if(lbl.innerHTML !== want) lbl.innerHTML = want;
      }
    }
    const mpPotBtn = $('bPotionMpBtn');
    if(mpPotBtn){
      const lbl = mpPotBtn.querySelector('.btn-label');
      if(lbl){
        const want = `蓝药<span class="cd-tag">${Game.player.potionMp}</span>`;
        if(lbl.innerHTML !== want) lbl.innerHTML = want;
      }
    }

    const autoBtn = $('bAutoBtn');
    if(autoBtn){
      const lbl = autoBtn.querySelector('.btn-label');
      if(lbl){
        const want = b.auto ? '停止' : '自动';
        if(lbl.textContent !== want) lbl.textContent = want;
      }
    }
  },

  _refreshSkillBtn(id, key){
    const sk = SKILLS[key];
    const btn = $(id);
    if(!btn) return;
    const b = Game.battle;
    const shortName = sk.name.slice(0,2);
    const lbl = btn.querySelector('.btn-label');
    if(!lbl) return;

    const cd = (b && b.cds) ? (b.cds[key] || 0) : 0;

    let wantHtml, wantDisabled;
    if(Game.player.lv < sk.unlock){
      wantHtml = shortName;
      wantDisabled = true;
    }else if(cd > 0){
      wantHtml = `${shortName}<span class="cd-tag">${cd}</span>`;
      wantDisabled = true;
    }else{
      wantHtml = shortName;
      wantDisabled = false;
    }

    if(lbl.innerHTML !== wantHtml) lbl.innerHTML = wantHtml;
    if(btn.disabled !== wantDisabled) btn.disabled = wantDisabled;
  },

  _renderTip(b){
    const a = calcAttr();
    const rage = Game.player.rage || 0;
    const zsActive = b.buff.zhanshen > 0;
    const tipEl = $('bTip');
    if(!tipEl) return;

    let want;
    if(zsActive){
      const zsAtkMin = Math.floor(a.atkMin * 1.3);
      const zsAtkMax = Math.floor(a.atkMax * 1.3);
      const zsDefMin = Math.floor(a.defMin * 1.3);
      const zsDefMax = Math.floor(a.defMax * 1.3);
      want = `怒 ${rage}/${RAGE_MAX} · 🛡️战神祝福(${b.buff.zhanshen}) 攻 ${zsAtkMin}-${zsAtkMax} 防 ${zsDefMin}-${zsDefMax}`;
      tipEl.classList.add('zs-tip');
    }else{
      tipEl.classList.remove('zs-tip');
      if(b.pendingSkill) want = `点击怪物释放 ${SKILLS[b.pendingSkill].name}`;
      else if(b.auto) want = '自动战斗中…';
      else want = `点击怪物攻击 · 怒 ${rage}/${RAGE_MAX} · 攻 ${a.atkMin}-${a.atkMax} 防 ${a.defMin}-${a.defMax}`;
    }
    if(tipEl.textContent !== want) tipEl.textContent = want;
  },

  _floatMon(m, text, cls){
    const el = document.getElementById('mon-' + m.mid);
    floatText(el, text, FC[cls] || FC.normal);
  },
  _floatPlayer(text, cls){
    const el = $('pBox') || $('bLeft');
    floatText(el, text, FC[cls] || FC.normal);
  },
  _floatPet(p, text, cls){
    const el = document.getElementById('pet-' + p.uid) || $('bLeft');
    floatText(el, text, FC[cls] || FC.normal);
  }
};