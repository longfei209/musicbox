/* ============================================================
 *  combat/32-auto.js  —— 自动战斗
 *  定义 CombatAuto，由 combat/31-actions.js 合并进 CombatActions
 * ============================================================ */

const AUTO_PRIORITY = [
  { name:'红药', cond:(b,mHp)=>Game.player.potion>0 && Game.player.hp/mHp<AUTO_POTION_THRESHOLD, act:function(){this.potion();} },
  { name:'蓝药', cond:(b,mHp,mMp)=>Game.player.potionMp>0 && Game.player.mp/mMp<0.2, act:function(){this.potionMp();} },
  { name:'怒斩', cond:()=>(Game.player.rage||0)>=RAGE_MAX, act:function(){this.useRage();} },
  { name:'半月', cond:(b)=>Game.player.lv>=3 && !b.cds.banyue && b.monsters.filter(m=>!m.dead).length>=2 && Game.player.mp>=SKILLS.banyue.mp, act:function(){this.useSkill('banyue');} },
  { name:'毒术', cond:(b)=>Game.player.lv>=6 && !b.cds.du && Game.player.mp>=SKILLS.du.mp, act:function(){this._autoUseTargetSkill('du');} },
  { name:'治愈', cond:(b,mHp)=>Game.player.lv>=5 && !b.cds.zhiyu && Game.player.hp/mHp<0.5 && Game.player.mp>=SKILLS.zhiyu.mp, act:function(){this.useSkill('zhiyu');} },
  { name:'战神', cond:(b)=>Game.player.lv>=8 && !b.cds.zhanshen && b.buff.zhanshen===0 && Game.player.mp>=SKILLS.zhanshen.mp, act:function(){this.useSkill('zhanshen');} },
  { name:'烈火', cond:(b)=>Game.player.lv>=1 && !b.cds.liehuo && Game.player.mp>=SKILLS.liehuo.mp, act:function(){this._autoUseTargetSkill('liehuo');} },
  { name:'普攻', cond:()=>true, act:function(){this.attack();} }
];

const CombatAuto = {
  toggleAuto(){
    const b = Game.battle; if(!b) return;
    b.auto = !b.auto;
    this.render();
    if(b.auto) this._autoTick();
  },

  _autoUseTargetSkill(key){
    const b = Game.battle; if(!b) return;
    const alive = b.monsters.filter(m => !m.dead);
    if(alive.length === 0) return;
    let target = null;
    if(b.lastTarget){
      target = b.monsters.find(m => m.mid === b.lastTarget && !m.dead) || null;
    }
    if(!target){
      alive.sort((a, b) => a.hp - b.hp);
      target = alive[0];
    }
    if(target){
      b.lastTarget = target.mid;
      this._resolveRound({ type:'skill', skill: key, target });
    }else{
      this.attack();
    }
  },

  _autoTick(){
    const b = Game.battle; if(!b || !b.auto) return;
    clearTimeout(b._timer);
    b._timer = setTimeout(()=>{
      const cur = Game.battle;
      if(!cur || !cur.auto) return;
      if(cur.resolving){ this._autoTick(); return; }
      const alive = cur.monsters.filter(m => !m.dead);
      if(alive.length === 0) return;

      const mHp = playerMaxHp();
      const mMp = playerMaxMp();

      if(Game.player.hp / mHp < 0.10){
        cur.auto = false;
        this.render();
        Render.top();
        toast('⚠️ 血量过低，自动战斗已停止');
        return;
      }

      for(const rule of AUTO_PRIORITY){
        if(rule.cond(cur, mHp, mMp)){
          rule.act.call(this);
          break;
        }
      }
      if(Game.battle && Game.battle.auto) this._autoTick();
    }, 460);
  },

  stopAuto(){
    const b = Game.battle;
    if(b){ b.auto = false; clearTimeout(b._timer); }
  }
};