/* ============================================================
 *  combat/33-pet.js  —— 宠物战斗行为
 *  定义 CombatPet，由 combat/31-actions.js 合并进 CombatActions
 * ============================================================ */

const CombatPet = {
  async _doPetActionAnimated(p, isAuto){
    if(!petAlive(p) || p.deadInBattle) return;
    const battleRef = Game.battle; if(!battleRef) return;
    const petEl = document.getElementById('pet-' + p.uid);
    const alive = battleRef.monsters.filter(m=>!m.dead);
    const targetM = alive.sort((a,b)=>a.hp-b.hp)[0] || null;
    const targetEl = targetM ? document.getElementById('mon-' + targetM.mid) : null;

    if(!isAuto && petEl && targetEl){
      await _chargeTo(petEl, targetEl, 220);
      if(Game.battle !== battleRef) return;
      this._doPetAction(p);
      _returnFromCharge(petEl, 180);
      await _sleep(200);
    }else{
      this._doPetAction(p);
    }
  },

  _doPetAction(p){
    const b = Game.battle; if(!b || !p) return;
    if(!petAlive(p) || p.deadInBattle) return;
    const pst = petStatFor(p);
    const ps = petSkillStateFor(p);
    const alive = b.monsters.filter(m=>!m.dead);
    if(alive.length === 0) return;

    if(ps.heal && (!p.skillCd.heal || p.skillCd.heal <= 0)){
      const heal = Math.floor(playerMaxHp() * ps.heal);
      Game.player.hp = Math.min(playerMaxHp(), Game.player.hp + heal);
      this._floatPlayer(`+${heal}`, 'heal');
      _healPlayerAnim();
      p.skillCd.heal = PET_SKILL_CD.heal;
    }

    let petAtkBonus = 1;
    if(ps.ragePet && Game.player.hp / playerMaxHp() < 0.3) petAtkBonus *= 1.5;
    if(ps.atkBonus) petAtkBonus *= (1 + ps.atkBonus);

    const target = pick(alive);
    const pierceRate = ps.pierce || 0;
    const effDef = (def) => def * (1 - pierceRate);

    const canGroup = ps.group && (!p.skillCd.group || p.skillCd.group <= 0);

    if(canGroup){
      alive.forEach(t=>{
        let dmg = calcDamage(pst.atk * 0.22 * petAtkBonus, effDef(t.def) * 0.5);
        let isCrit = Math.random() < (0.05 + ps.crit);
        if(isCrit) dmg = Math.floor(dmg * 1.3);
        t.hp -= dmg;
        _hitMonsterAnim(t, isCrit);
        this._floatMon(t, `${p.avatar}-${dmg}`, isCrit ? 'crit' : 'normal');
        this._petLifesteal(p, dmg);
        if(ps.pois){
          const pd = Math.max(1, Math.floor(pst.atk * 0.15));
          t.hp -= pd;
          this._floatMon(t, `${p.avatar}-${pd}`, 'poison');
        }
        if(ps.slow && Math.random() < ps.slow){
          t.slow = { turns: 2, amount: 0.2 };
        }
        if(t.hp <= 0 && !t.dead) this._killMonster(t);
      });
      p.skillCd.group = PET_SKILL_CD.group;
    }else{
      let dmg = calcDamage(pst.atk * petAtkBonus, effDef(target.def));
      let isHeavy = ps.heavy && Math.random() < ps.heavy;
      if(isHeavy) dmg = Math.floor(dmg * 1.8);
      let isCrit = Math.random() < (0.05 + ps.crit);
      if(isCrit) dmg = Math.floor(dmg * 1.3);
      target.hp -= dmg;
      _hitMonsterAnim(target, isCrit || isHeavy);
      const tag = isHeavy ? '重击' : '';
      this._floatMon(target, `${p.avatar}${tag}-${dmg}`, (isCrit || isHeavy) ? 'crit' : 'normal');
      this._petLifesteal(p, dmg);
      if(ps.pois){
        const pd = Math.max(1, Math.floor(pst.atk * 0.15));
        target.hp -= pd;
        this._floatMon(target, `${p.avatar}-${pd}`, 'poison');
      }
      if(ps.slow && Math.random() < ps.slow && !target.dead){
        target.slow = { turns: 2, amount: 0.2 };
        this._floatMon(target, '减速', 'reflect');
      }
      if(target.hp <= 0 && !target.dead) this._killMonster(target);
      if(ps.double && Math.random() < ps.double && !target.dead){
        let dmg2 = calcDamage(pst.atk * petAtkBonus * 0.6, effDef(target.def) * 0.6);
        target.hp -= dmg2;
        _hitMonsterAnim(target, false);
        this._floatMon(target, `${p.avatar}[连咬]-${dmg2}`, 'normal');
        this._petLifesteal(p, dmg2);
        if(target.hp <= 0 && !target.dead) this._killMonster(target);
      }
    }
  },

  _petLifesteal(p, dmg){
    const pst = petStatFor(p);
    const ps = petSkillStateFor(p);
    if(ps.ls > 0){
      const heal = Math.floor(dmg * ps.ls);
      if(heal > 0) p.hp = Math.min(pst.hp, p.hp + heal);
    }
  },

  _tryNirvana(){
    const b = Game.battle;
    if(!b || b.nirvanaUsed) return false;
    const alivePets = getActivePetObjects().filter(p => !p.deadInBattle);
    const nirvanaPet = alivePets.find(p => petSkillStateFor(p).nirvana);
    if(!nirvanaPet) return false;
    b.nirvanaUsed = true;
    Game.player.hp = Math.max(1, Math.floor(playerMaxHp() * 0.10));
    const before = nirvanaPet.hp;
    nirvanaPet.hp = Math.max(1, Math.floor(before / 2));
    this._floatPlayer('涅槃', 'heal');
    this._floatPet(nirvanaPet, `-${before - nirvanaPet.hp}`, 'reflect');
    toast(`🔥 ${nirvanaPet.name} 涅槃！替主人挡下致命伤`);
    _healPlayerAnim();
    Render.top();
    return true;
  },

  _applyFlame(target){
    const b = Game.battle;
    if(!b || !target || target.dead) return;
    const pets = getActivePetObjects().filter(p => !p.deadInBattle);
    pets.forEach(p => {
      if(target.dead) return;
      const ps = petSkillStateFor(p);
      if(!ps.flame) return;
      const pst = petStatFor(p);
      const dmg = calcDamage(pst.atk * 0.4, target.def);
      target.hp -= dmg;
      _hitMonsterAnim(target, false);
      this._floatMon(target, `🔥焚天-${dmg}`, 'crit');
      if(target.hp <= 0 && !target.dead) this._killMonster(target);
    });
  }
};