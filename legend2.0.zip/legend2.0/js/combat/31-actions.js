/* ============================================================
 *  combat/31-actions.js  —— 战斗主体 + 合并入口
 *  加载顺序必须靠后（此时 CombatAuto / CombatPet / CombatMonster 均已定义）
 *  最终产出：CombatActions（由 render/68-nav.js 合并进 Combat）
 * ============================================================ */

const CombatActions = Object.assign(
  {},
  CombatAuto,
  CombatPet,
  CombatMonster,
  {
    /* ================= 开始战斗 ================= */
    startGroup(gi){
      const st = areaState(Game.ui.areaId).floors[Game.ui.floorIdx];
      const group = st.groups[gi];
      if(!group || !group.alive) return toast("该组已清空");
      if(group.members.every(m=>m.dead)) return toast("该组已清空");
      group.members.forEach(m=>{ m.summonCount = 0; m.poison = null; m.slow = null; });
      Game.battle = {
        kind:'group', gi, group,
        monsters: group.members,
        auto:false, pendingSkill:null, roundCount:0,
        buff:{ zhanshen:0 }, cds:{},
        lastTarget: null, resolving: false,
        timestopUsed: false, nirvanaUsed: false, _timestopActive: false,
        loot: newBattleLoot()
      };
      Game.activePets.forEach(u=>{
        const p = Game.pets.find(x=>x.uid === u);
        if(p && petAlive(p)){
          p.hp = petStatFor(p).hp;
          p.skillCd = {};
          p.deadInBattle = false;
        }
      });
      Nav.go('battle');
    },

    startBoss(){
      const ar = AREA_MAP[Game.ui.areaId];
      const fi = Game.ui.floorIdx;
      const st = areaState(Game.ui.areaId).floors[fi];
      if(st.bossDeath) return toast("BOSS 未复活");
      const def = ar.floors[fi].boss;
      const boss = {
        mid: uid(), protoId: def.id, name: def.name,
        hp: def.hp, maxHp: def.hp,
        atk: def.atk, def: def.def, spd: def.spd,
        exp: def.exp, gMin: def.gMin, gMax: def.gMax,
        behavior:'normal', elite:false, affixes:[],
        dead:false, deathTs:0, vamp:0, pois:0, summonCount:0, poison:null, slow:null,
        isBoss:true,
        dropEquip: def.dropEquip || null,
        unlockDragon: def.unlockDragon || false,
        unlockNiumo: def.unlockNiumo || false,
        unlockGhost: def.unlockGhost || false
      };
      const guards = _makeBossGuards(def);
      Game.battle = {
        kind:'boss', monsters:[boss, ...guards], boss, group:null,
        auto:false, pendingSkill:null, roundCount:0,
        buff:{ zhanshen:0 }, cds:{},
        lastTarget: null, resolving: false,
        timestopUsed: false, nirvanaUsed: false, _timestopActive: false,
        loot: newBattleLoot()
      };
      Game.activePets.forEach(u=>{
        const p = Game.pets.find(x=>x.uid === u);
        if(p && petAlive(p)){
          p.hp = petStatFor(p).hp;
          p.skillCd = {};
          p.deadInBattle = false;
        }
      });
      Nav.go('battle');
    },

    /* ================= 玩家操作 ================= */
    attack(){
      const b = Game.battle; if(!b || b.pendingSkill || b.resolving) return;
      const alive = b.monsters.filter(m=>!m.dead);
      if(alive.length === 0) return;
      let target = null;
      if(b.lastTarget) target = b.monsters.find(m => m.mid === b.lastTarget && !m.dead) || null;
      /* ★ 修复：sort 内部改用 x/y，避免遮蔽外层 const b */
      if(!target){ alive.sort((x,y)=>x.hp - y.hp); target = alive[0]; }
      b.lastTarget = target.mid;
      this._resolveRound({ type:'attack', target });
    },

    clickMonster(i){
      const b = Game.battle; if(!b || b.resolving) return;
      const m = b.monsters[i];
      if(!m || m.dead) return;
      if(b.pendingSkill){
        const skKey = b.pendingSkill;
        b.pendingSkill = null;
        b.lastTarget = m.mid;
        this._resolveRound({ type:'skill', skill: skKey, target: m });
      }else{
        b.lastTarget = m.mid;
        this._resolveRound({ type:'attack', target: m });
      }
    },

    useSkill(key){
      const b = Game.battle; if(!b || b.resolving) return;
      const sk = SKILLS[key]; if(!sk) return;
      if(Game.player.lv < sk.unlock) return toast(`需 Lv.${sk.unlock}`);
      if(b.cds && b.cds[key] > 0) return toast("冷却中");
      if(Game.player.mp < sk.mp) return toast("蓝量不足");

      if(key === 'liehuo' || key === 'du'){
        if(!b.lastTarget){ b.pendingSkill = key; this.render(); return; }
        let target = b.monsters.find(m => m.mid === b.lastTarget && !m.dead);
        if(!target){ const alive = b.monsters.filter(m => !m.dead); target = alive[0]; }
        if(!target) return;
        b.lastTarget = target.mid;
        this._resolveRound({ type:'skill', skill: key, target });
        return;
      }
      this._resolveRound({ type:'skill', skill: key, target: null });
    },

    useRage(){
      const b = Game.battle; if(!b || b.resolving) return;
      if((Game.player.rage||0) < RAGE_MAX) return toast("怒气不足");
      const alive = b.monsters.filter(m=>!m.dead);
      if(alive.length === 0) return;
      let target = null;
      if(b.lastTarget) target = b.monsters.find(m => m.mid === b.lastTarget && !m.dead) || null;
      /* ★ 修复：sort 内部改用 x/y */
      if(!target){ alive.sort((x,y)=>x.hp-y.hp); target = alive[0]; }
      b.lastTarget = target.mid;
      this._resolveRound({ type:'rage', target });
    },

    potion(){
      const b = Game.battle; if(!b || b.resolving) return;
      if(Game.player.potion <= 0) return toast("没有红药");
      Game.player.potion--;
      const heal = Math.floor(playerMaxHp() * 0.35);
      Game.player.hp = Math.min(playerMaxHp(), Game.player.hp + heal);
      this._floatPlayer(`+${heal}`, 'heal');
      _healPlayerAnim();
      Render.top();
      this._monsterPhaseOnly();
    },

    potionMp(){
      const b = Game.battle; if(!b || b.resolving) return;
      if(Game.player.potionMp <= 0) return toast("没有蓝药");
      Game.player.potionMp--;
      const heal = Math.floor(playerMaxMp() * 0.30);
      Game.player.mp = Math.min(playerMaxMp(), Game.player.mp + heal);
      this._floatPlayer(`+${heal}MP`, 'heal');
      Render.top();
      this._monsterPhaseOnly();
    },

    /* ================= 回合结算 ================= */
    async _resolveRound(action){
      const b = Game.battle; if(!b || b.resolving) return;
      b.resolving = true;
      const battleRef = b;
      try {
        if(!b.cds) b.cds = {};
        b.roundCount++;

        const pa = calcAttr();
        let atkMul = 1, defMul = 1;
        if(b.buff.zhanshen > 0){
          atkMul = skillBuffMul('zhanshen', 1.3);
          defMul = skillBuffMul('zhanshen', 1.3);
        }

        const units = [];
        units.push({ side:'me', spd: pa.spd });
        const activePetObjs = getActivePetObjects();
        activePetObjs.forEach(p=>{
          if(p.deadInBattle) return;
          const pst = petStatFor(p);
          const ps = petSkillStateFor(p);
          const spdBonus = ps.spdBonus || 0;
          units.push({ side:'pet', spd: Math.floor(pst.spd * (1 + spdBonus)), pet: p });
        });
        b.monsters.forEach(m=>{
          if(m.dead) return;
          let spd = m.spd;
          if(m.slow && m.slow.turns > 0) spd = Math.floor(spd * (1 - m.slow.amount));
          units.push({ side:'mon', spd, m });
        });
        units.sort((a,b)=>b.spd - a.spd);

        if(b.roundCount === 1 && !b.timestopUsed){
          const hasTimestop = activePetObjs.some(p => {
            if(p.deadInBattle) return false;
            return petSkillStateFor(p).timestop;
          });
          if(hasTimestop){
            b.timestopUsed = true;
            b._timestopActive = true;
            toast('⏳ 时停！怪物本回合无法行动');
          }
        }

        const isAuto = b.auto;

        for(const u of units){
          if(Game.battle !== battleRef) return;
          if(u.side === 'mon' && b._timestopActive) continue;
          if(u.side === 'me') await this._doPlayerActionAnimated(action, atkMul, isAuto);
          else if(u.side === 'pet') await this._doPetActionAnimated(u.pet, isAuto);
          else {
            if(u.m.dead) continue;
            await this._doMonsterActionAnimated(u.m, defMul, isAuto);
          }
          if(Game.battle !== battleRef) return;
          if(Game.player.hp <= 0){
            if(!this._tryNirvana()) break;
          }
          if(b.monsters.every(x=>x.dead)) break;
        }
        b._timestopActive = false;

        if(Game.battle !== battleRef) return;
        if(Game.player.hp <= 0){ this._onPlayerDead(); return; }
        if(b.monsters.every(x=>x.dead)){ this._onBattleClear(); return; }

        this._tickPoison();
        if(Game.battle !== battleRef) return;
        if(Game.player.hp <= 0){
          if(!this._tryNirvana()){ this._onPlayerDead(); return; }
        }
        if(b.monsters.every(x=>x.dead)){ this._onBattleClear(); return; }

        activePetObjs.forEach(p=>{
          if(p.deadInBattle) return;
          const ps = petSkillStateFor(p);
          if(ps.regen){
            const heal = Math.floor(playerMaxHp() * ps.regen);
            if(heal > 0 && Game.player.hp < playerMaxHp()){
              Game.player.hp = Math.min(playerMaxHp(), Game.player.hp + heal);
              this._floatPlayer(`+${heal}`, 'heal');
            }
          }
        });

        Game.player.mp = Math.min(playerMaxMp(), Game.player.mp + MP_REGEN_PER_TURN);
        if(b.buff.zhanshen > 0) b.buff.zhanshen--;
        for(const k in b.cds){ if(b.cds[k] > 0) b.cds[k]--; }
        b.monsters.forEach(m=>{
          if(m.slow && m.slow.turns > 0){
            m.slow.turns--;
            if(m.slow.turns <= 0) m.slow = null;
          }
        });
        Game.activePets.forEach(u=>{
          const p = Game.pets.find(x=>x.uid === u);
          if(p && p.skillCd){ for(const k in p.skillCd){ if(p.skillCd[k] > 0) p.skillCd[k]--; } }
        });

        this.render();
        Render.top();
        /* ★ 修复：删除每回合的 Save.auto()，避免战斗中反复写盘 */
      } finally {
        if(Game.battle === battleRef) battleRef.resolving = false;
      }
    },

    async _monsterPhaseOnly(){
      const b = Game.battle; if(!b || b.resolving) return;
      b.resolving = true;
      const battleRef = b;
      try {
        const defMul = b.buff.zhanshen > 0 ? skillBuffMul('zhanshen', 1.3) : 1.0;
        const isAuto = b.auto;
        const order = b.monsters.filter(m=>!m.dead).sort((a,b)=>b.spd - a.spd);
        for(const m of order){
          if(Game.battle !== battleRef) return;
          if(m.dead) continue;
          await this._doMonsterActionAnimated(m, defMul, isAuto);
          if(Game.battle !== battleRef) return;
          if(Game.player.hp <= 0){
            if(!this._tryNirvana()) break;
          }
        }
        if(Game.battle !== battleRef) return;
        if(Game.player.hp <= 0){ this._onPlayerDead(); return; }
        this._tickPoison();
        if(Game.battle !== battleRef) return;
        if(Game.player.hp <= 0){
          if(!this._tryNirvana()){ this._onPlayerDead(); return; }
        }
        if(b.monsters.every(x=>x.dead)){ this._onBattleClear(); return; }
        for(const k in b.cds){ if(b.cds[k] > 0) b.cds[k]--; }
        if(b.buff.zhanshen > 0) b.buff.zhanshen--;
        b.monsters.forEach(m=>{
          if(m.slow && m.slow.turns > 0){
            m.slow.turns--;
            if(m.slow.turns <= 0) m.slow = null;
          }
        });
        Game.activePets.forEach(u=>{
          const p = Game.pets.find(x=>x.uid === u);
          if(p && p.skillCd){ for(const k in p.skillCd){ if(p.skillCd[k] > 0) p.skillCd[k]--; } }
        });
        Game.player.mp = Math.min(playerMaxMp(), Game.player.mp + MP_REGEN_PER_TURN);
        this.render();
        Render.top();
        /* ★ 修复：删除 _monsterPhaseOnly 里的 Save.auto() */
      } finally {
        if(Game.battle === battleRef) battleRef.resolving = false;
      }
    },

    _tickPoison(){
      const b = Game.battle; if(!b) return;
      b.monsters.forEach(m=>{
        if(m.dead || !m.poison || m.poison.turns <= 0) return;
        const dmg = m.poison.dmg;
        m.hp -= dmg;
        this._floatMon(m, `☠-${dmg}`, 'poison');
        m.poison.turns--;
        if(m.poison.turns <= 0) m.poison = null;
        if(m.hp <= 0 && !m.dead) this._killMonster(m);
      });
    },

    async _doPlayerActionAnimated(action, atkMul, isAuto){
      const battleRef = Game.battle; if(!battleRef) return;
      const playerEl = $('pBox');
      let targetM = action.target;
      if(!targetM || targetM.dead){
        const alive = battleRef.monsters.filter(m=>!m.dead);
        targetM = alive[0] || null;
      }
      const targetEl = targetM ? document.getElementById('mon-' + targetM.mid) : null;

      if(!isAuto && playerEl && targetEl){
        await _chargeTo(playerEl, targetEl, 260);
        if(Game.battle !== battleRef) return;
        this._doPlayerAction(action, atkMul);
        _returnFromCharge(playerEl, 220);
        await _sleep(240);
      }else{
        this._doPlayerAction(action, atkMul);
      }
    },

    _doPlayerAction(action, atkMul){
      const b = Game.battle; if(!b) return;
      const a = calcAttr();

      if(action.type === 'attack'){
        const t = action.target;
        if(!t || t.dead) return;
        const baseAtk = rnd(a.atkMin, a.atkMax) * atkMul;
        this._playerHit(t, baseAtk);
        this._applyFlame(t);
        if(Math.random() < a.combo && !t.dead){
          const baseAtk2 = rnd(a.atkMin, a.atkMax) * atkMul * 0.6;
          this._playerHit(t, baseAtk2, '连击');
        }
        Game.player.rage = Math.min(RAGE_MAX, (Game.player.rage||0) + 1);
      }
      else if(action.type === 'skill'){
        const key = action.skill;
        const sk = SKILLS[key];
        if(!sk || Game.player.lv < sk.unlock) return;
        if(b.cds[key] > 0) return;
        if(Game.player.mp < sk.mp) return;
        b.cds[key] = sk.cd;
        Game.player.mp -= sk.mp;

        if(key === 'liehuo'){
          const t = action.target;
          if(!t || t.dead) return;
          const mul = skillDmgMul('liehuo', 1.8);
          const baseAtk = rnd(a.atkMin, a.atkMax) * atkMul * mul;
          this._playerHit(t, baseAtk);
          this._applyFlame(t);
          _popSkillEmoji(document.getElementById('mon-'+t.mid), '🔥', true, true);
          _pulseCard(t, 'anim-fire-pulse');
          if(Math.random() < a.combo && !t.dead){
            const baseAtk2 = rnd(a.atkMin, a.atkMax) * atkMul * mul * 0.6;
            this._playerHit(t, baseAtk2, '连击');
          }
        }
        else if(key === 'banyue'){
          _popSkillEmoji($('bGrid'), '⚔️', false, false);
          const mul = skillDmgMul('banyue', 0.9);
          b.monsters.filter(m=>!m.dead).forEach(t=>{
            const baseAtk = rnd(a.atkMin, a.atkMax) * atkMul * mul;
            this._playerHit(t, baseAtk);
          });
        }
        else if(key === 'zhiyu'){
          const rate = skillHealRate('zhiyu', 0.25);
          const heal = Math.floor(playerMaxHp() * rate);
          Game.player.hp = Math.min(playerMaxHp(), Game.player.hp + heal);
          this._floatPlayer(`+${heal}`, 'heal');
          _popSkillEmoji($('pBox'), '💚', false, false);
          _healPlayerAnim();
          getActivePetObjects().forEach(p=>{
            const pMax = petStatFor(p).hp;
            const pHeal = Math.floor(pMax * rate);
            if(pHeal > 0 && p.hp < pMax){
              p.hp = Math.min(pMax, p.hp + pHeal);
              this._floatPet(p, `+${pHeal}`, 'heal');
              const petEl = document.getElementById('pet-' + p.uid);
              if(petEl){
                petEl.classList.remove('anim-heal-glow');
                void petEl.offsetWidth;
                petEl.classList.add('anim-heal-glow');
                setTimeout(()=>petEl.classList.remove('anim-heal-glow'), 700);
              }
            }
          });
        }
        else if(key === 'du'){
          const t = action.target;
          if(!t || t.dead) return;
          const dmg = skillPoisonDmg();
          t.poison = { turns: 3, dmg: dmg };
          _popSkillEmoji(document.getElementById('mon-'+t.mid), '☠️', true, true);
          this._floatMon(t, `中毒`, 'poison');
          toast(`☠️ ${t.name} 中毒 3 回合（每回合 -${dmg}）`);
        }
        else if(key === 'zhanshen'){
          b.buff.zhanshen = 3;
          _popSkillEmoji($('pBox'), '🛡️', false, false);
          _buffPlayerAnim();
          const bonus = Math.floor((skillBuffMul('zhanshen', 1.3) - 1) * 100);
          toast(`🛡️ 战神祝福！攻防+${bonus}%`);
        }
        Game.player.rage = Math.min(RAGE_MAX, (Game.player.rage||0) + 1);
      }
      else if(action.type === 'rage'){
        const t = action.target;
        if(!t || t.dead) return;
        Game.player.rage = 0;
        const baseAtk = rnd(a.atkMin, a.atkMax) * atkMul * 3.0;
        this._playerHit(t, baseAtk, '怒斩', true);
        this._applyFlame(t);
        _popSkillEmoji(document.getElementById('mon-'+t.mid), '⚡', false, false);
        _pulseCard(t, 'anim-rage-hit');
      }
    },

    _playerHit(target, baseAtk, tag, forceCrit){
      const a = calcAttr();
      let isCrit = false;
      if(forceCrit) isCrit = true;
      else if(Math.random() < a.crit) isCrit = true;

      let dmg = calcDamage(baseAtk, target.def);
      if(isCrit) dmg = Math.floor(dmg * a.critD);
      target.hp -= dmg;

      const tagTxt = tag ? `[${tag}]` : '';
      _hitMonsterAnim(target, isCrit);
      this._floatMon(target, `${tagTxt}-${dmg}`, isCrit ? 'crit' : 'normal');

      this._applyLifesteal(dmg, 'player');
      if(target.hp <= 0 && !target.dead) this._killMonster(target);
    },

    _applyLifesteal(dmg, who){
      if(who === 'player'){
        const a = calcAttr();
        let totalHeal = 0;
        if(a.lsPct > 0) totalHeal += Math.floor(dmg * a.lsPct);
        if(a.lsFlat > 0) totalHeal += a.lsFlat;
        if(totalHeal > 0){
          Game.player.hp = Math.min(playerMaxHp(), Game.player.hp + totalHeal);
          this._floatPlayer(`+${totalHeal}`, 'heal');
        }
      }
    },

    _killMonster(m){
      if(m.dead) return;
      m.dead = true;
      m.hp = 0;
      m.deathTs = Date.now();
      Game.stats.kills++;
      Game.player.mp = Math.min(playerMaxMp(), Game.player.mp + MP_REGEN_PER_KILL);

      const card = document.getElementById('mon-' + m.mid);
      if(card){ card.classList.add('dead'); card.onclick = null; }

      const b = Game.battle;
      const loot = b.loot;
      loot.killedNames.push(m.name);
      loot.exp += m.exp;
      loot.petExp += Math.floor(m.exp * 0.5);
      const gold = rnd(m.gMin, m.gMax);
      loot.gold += gold;

      Quest.onKill(m.protoId);

      let dropChance = m.isBoss ? 0.85 : (m.elite ? 0.55 : 0.18);
      if(Math.random() < dropChance){
        const monType = m.isBoss ? 'boss' : (m.elite ? 'elite' : 'normal');
        const eq = rollDropEquip(Game.ui.areaId, monType);
        if(eq){
          if(Game.bag.length + loot.items.length < Game.player.bagMax){
            loot.items.push({ name: eq.name, quality: eq.quality, eq: eq });
          }
        }
      }

      this._tryDropGemOrFrag(m, loot);

      let pageRate = PAGE_DROP.normalMon;
      if(m.isBoss) pageRate = PAGE_DROP.boss;
      else if(m.elite) pageRate = PAGE_DROP.elite;
      if(Math.random() < pageRate) loot.pages += 1;

      if(m.elite && !m.isBossGuard && Math.random() < 0.08 && Game.pets.length < PET_WAREHOUSE_MAX){
        const tpl = rollPetTemplate();
        const q = rollPetQuality(0.05);
        const pet = makePet(tpl, q);
        Pet.tryAdd(pet);
        showBattleDrop(`🥚 精英掉落宠物蛋！`);
      }
      if(m.isBoss){
        if(Math.random() < 0.25 && Game.pets.length < PET_WAREHOUSE_MAX){
          const tpl = rollPetTemplate();
          const q = rollPetQuality(0.15);
          const pet = makePet(tpl, q);
          Pet.tryAdd(pet);
          showBattleDrop(`🥚 BOSS 掉落宠物蛋！`);
        }
        if(m.unlockDragon){ Game.flags.dragonCity = true; showBattleDrop('🌐 魔龙城已解锁！'); }
        if(m.unlockNiumo){ Game.flags.niumo = true; showBattleDrop('🐂 牛魔洞已解锁！'); }
        if(m.unlockGhost){ Game.flags.ghost = true; showBattleDrop('👻 幽灵船已解锁！'); }
        areaState(Game.ui.areaId).floors[Game.ui.floorIdx].bossDeath = Date.now();
      }
    },

    _tryDropGemOrFrag(m, loot){
      let rate = GEM_DROP_RATE.normalMon;
      if(m.isBoss) rate = GEM_DROP_RATE.boss;
      else if(m.elite) rate = GEM_DROP_RATE.elite;
      if(Math.random() >= rate) return;
      const isGem = Math.random() < GEM_DROP_SPLIT;
      if(isGem){
        const boost = m.isBoss ? 0.15 : (m.elite ? 0.05 : 0);
        const key = randomGemKey();
        const q = rollGemQuality(boost);
        loot.gems.push({ key, quality: q });
      }else{
        const key = randomGemKey();
        const r = Math.random();
        const q = r < 0.02 ? 'legend' : (r < 0.10 ? 'rare' : 'normal');
        const exist = loot.frags.find(f=>f.key===key && f.quality===q);
        if(exist) exist.count++;
        else loot.frags.push({ key, quality: q, count: 1 });
      }
    },

    _onBattleClear(){
      const b = Game.battle; if(!b) return;
      this.stopAuto();
      if(b.kind === 'group' && b.group){
        b.group.alive = false;
        b.group.deathTs = Date.now();
      }

      const loot = b.loot;
      _showBattleResult(loot, ()=>{
        if(loot.exp > 0) addExp(loot.exp);
        if(loot.petExp > 0){
          const petNames = [];
          Game.activePets.forEach(u=>{
            const p = Game.pets.find(x=>x.uid === u);
            if(p){
              petAddExp(p, loot.petExp);
              petNames.push(p.name);
            }
          });
          if(petNames.length > 0){
            toast(`宠物经验 +${loot.petExp}（${petNames.length}只）`);
          }
        }
        if(loot.gold > 0) Game.player.gold += loot.gold;
        if(loot.pages > 0) Game.pages = (Game.pages || 0) + loot.pages;
        /* ★ 修复：统计背包满时未能拾取的装备并提示 */
        let lostItems = 0;
        loot.items.forEach(it=>{
          if(Game.bag.length < Game.player.bagMax) Game.bag.push(it.eq);
          else lostItems++;
        });
        loot.gems.forEach(g=>{
          Game.gems.push({ uid: 'g_'+Math.random().toString(36).slice(2,10), key: g.key, quality: g.quality });
        });
        loot.frags.forEach(f=>{
          const frag = Game.fragments[f.key];
          if(frag) frag[f.quality] = Math.min(FRAG_MAX_STACK, (frag[f.quality]||0) + f.count);
        });
        Quest.onBagChange();
        /* ★ 修复：先 end() 清 battle，再 Save.auto()，避免被战斗保护逻辑跳过 */
        this.end();
        Save.auto();
        if(lostItems > 0) toast(`⚠️ 背包已满，${lostItems} 件装备未能拾取`);
      });
    },

    _onPlayerDead(){
      const p = Game.player;
      const isProtected = p.lv <= 3;
      let lines = ['💀 你死亡了'];
      if(isProtected){
        lines.push('（3 级以下保护，无损失）');
      }else{
        const slots = SLOT_ORDER.filter(s => Game.worn[s]);
        let lostEquipName = null;
        if(slots.length > 0){
          const slot = pick(slots);
          const eq = Game.worn[slot];
          lostEquipName = eq.name;
          Game.worn[slot] = null;
        }
        const need = expNeed(p.lv);
        const expLoss = Math.min(p.exp, Math.floor(need * 0.15));
        p.exp -= expLoss;
        const lossPct = rnd(5, 20);
        const goldLost = Math.floor(p.gold * lossPct / 100);
        p.gold -= goldLost;

        lines.push('');
        if(lostEquipName) lines.push(`掉落装备：${lostEquipName}`);
        else lines.push('掉落装备：（无可掉落）');
        lines.push(`损失经验：${expLoss}`);
        lines.push(`损失金币：${goldLost}（-${lossPct}%）`);
      }

      Game.player.hp = playerMaxHp();
      Game.player.mp = playerMaxMp();
      Game.stats.deaths++;
      this.stopAuto();
      Save.auto();

      this.end();
      setTimeout(()=>{
        confirmBox(lines.join('\n'), ()=>{ Render.top(); Render.home(); });
      }, 200);
    },

    quit(){
      if(Game.battle && Game.battle.monsters.some(m=>!m.dead)){
        confirmBox("战斗未结束，确定退出？", ()=>{
          this.stopAuto();
          this.end();
        });
      }else{
        this.stopAuto();
        this.end();
      }
    },

    end(){
      this.stopAuto();
      Game.battle = null;
      Game.activePets.forEach(u=>{
        const p = Game.pets.find(x=>x.uid === u);
        if(!p) return;
        p.deadInBattle = false;
        p.skillCd = {};
        /* ★ 修复：战斗结束时清空复活倒计时，让宠物满血复活，
         * 避免"战斗结束但宠物还躺 30 秒"的怪异状态。 */
        p.downUntil = 0;
        p.hp = petStatFor(p).hp;
      });
      Nav.home();
      Render.top();
    }
  }
);