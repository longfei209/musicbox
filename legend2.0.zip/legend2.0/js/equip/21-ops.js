/* ============================================================
 *  equip/21-ops.js  —— 装备操作
 *  穿脱 / 出售 / 分解 / 一键最强 / 镶嵌 / 洗练 / 对比
 * ============================================================ */

const Equip = {
  /* ---------------- 穿脱 ---------------- */
  wear(idx){
    const e = Game.bag[idx]; if(!e) return;
    const old = Game.worn[e.slot];
    Game.worn[e.slot] = e;
    Game.bag.splice(idx, 1);
    if(old) Game.bag.push(old);
    Quest.onWear(e.name);
    Save.auto();
    Nav._show('bag', Nav._lastOpts || {}); Render.top();
  },

  unwear(slot){
    const e = Game.worn[slot]; if(!e) return;
    if(Game.bag.length >= Game.player.bagMax) return toast("背包已满");
    Game.bag.push(e); Game.worn[slot] = null;
    Save.auto();
    Nav._show('worn'); Render.top();
  },

  /* ---------------- 出售 / 分解 ---------------- */
  sell(idx){
    const e = Game.bag[idx]; if(!e) return;
    const hasGem = e.sockets && e.sockets.some(x=>x);
    const refined = e.refineTimes > 0;
    const doSell = ()=>{
      const price = getEquipSellPrice(e);
      Game.player.gold += price;
      Game.bag.splice(idx, 1);
      toast("出售 +" + price + " 金币");
      Quest.onBagChange();
      Save.auto();
      Nav._show('bag', Nav._lastOpts || {}); Render.top();
    };
    if(hasGem || refined){
      const parts = [];
      if(hasGem) parts.push('装备上有宝石');
      if(refined) parts.push(`装备已洗练 ${e.refineTimes} 次`);
      confirmBox(parts.join('，') + '，出售会一起丢失，确定吗？', doSell);
    }else{
      doSell();
    }
  },

  decompose(idx){
    const e = Game.bag[idx]; if(!e) return;
    const hasGem = e.sockets && e.sockets.some(x=>x);
    const refined = e.refineTimes > 0;
    const doDecomp = ()=>{
      Game.mat += DECOMP_MAT[e.quality];
      Game.bag.splice(idx, 1);
      toast("分解 +" + DECOMP_MAT[e.quality] + " 材料");
      Quest.onBagChange();
      Save.auto();
      Nav._show('bag', Nav._lastOpts || {}); Render.top();
    };
    if(hasGem || refined){
      const parts = [];
      if(hasGem) parts.push('装备上有宝石');
      if(refined) parts.push(`装备已洗练 ${e.refineTimes} 次`);
      confirmBox(parts.join('，') + '，分解会一起丢失，确定吗？', doDecomp);
    }else{
      doDecomp();
    }
  },

  /* ---------------- 一键最强 ---------------- */
  autoBest(){
    const pool = Game.bag.slice();
    SLOT_ORDER.forEach(s=>{ if(Game.worn[s]) pool.push(Game.worn[s]); });
    SLOT_ORDER.forEach(s=>{
      const cands = pool.filter(e=>e.slot===s);
      if(cands.length === 0){ Game.worn[s] = null; return; }
      cands.sort((a,b)=>getEquipScore(b) - getEquipScore(a));
      Game.worn[s] = cands[0];
    });
    const used = new Set(SLOT_ORDER.map(s=>Game.worn[s]).filter(Boolean).map(e=>e.uid));
    Game.bag = pool.filter(e=>!used.has(e.uid));
    while(Game.bag.length > Game.player.bagMax) Game.bag.pop();
    Save.auto();
    Nav._show('worn'); Render.top();
    toast("已装备最强");
  },

  /* ---------------- 洗练 ---------------- */
  refineRisk(e){
    let risk = 0.12 + (e.refineAtk + e.refineDef + e.refineHp) * 0.004;
    return clamp(risk, 0, 0.9);
  },

  refine(eqOrIdx){
    let e;
    if(typeof eqOrIdx === 'number') e = Game.bag[eqOrIdx];
    else e = eqOrIdx;
    if(!e) return;
    if(e.refineTimes >= 3) return toast("已达洗练上限");
    if(Game.mat < 1) return toast("缺少洗练材料");
    const risk = this.refineRisk(e);
    Game.mat -= 1;
    if(Math.random() < risk){
      e.refineAtk = 0; e.refineDef = 0; e.refineHp = 0;
      toast("💥 洗练破损");
    }else{
      e.refineAtk += rnd(1,6);
      e.refineDef += rnd(1,4);
      if(Math.random() < 0.35) e.refineHp += rnd(2,12);
      e.refineTimes++;
      toast("洗练成功");
    }
    Save.auto();
    Render.top();
    Nav._show('refine', Nav._lastOpts);
  },

  /* ---------------- 对比 ---------------- */
  compareToWorn(eq){
    const old = Game.worn[eq.slot];
    const nB = equipCompareStat(eq);
    const oB = old ? equipCompareStat(old) : { atk:0,def:0,spd:0,hp:0,combo:0,counter:0,lsPct:0,lsFlat:0,crit:0,critd:0 };
    return {
      atk:     { n: nB.atk,     o: oB.atk },
      def:     { n: nB.def,     o: oB.def },
      spd:     { n: nB.spd,     o: oB.spd },
      hp:      { n: nB.hp,      o: oB.hp },
      combo:   { n: nB.combo,   o: oB.combo },
      counter: { n: nB.counter, o: oB.counter },
      lsPct:   { n: nB.lsPct,   o: oB.lsPct },
      lsFlat:  { n: nB.lsFlat,  o: oB.lsFlat },
      crit:    { n: nB.crit,    o: oB.crit },
      critd:   { n: nB.critd||0,o: oB.critd||0 }
    };
  },

  /* ---------------- 镶嵌 ---------------- */
  socketGem(eq, socketIdx, gemId){
    if(!eq || !eq.sockets) return;
    if(socketIdx < 0 || socketIdx >= 3) return;
    if(eq.sockets[socketIdx]) return toast("该孔已有宝石");
    const gIdx = Game.gems.findIndex(g=>g.uid === gemId);
    if(gIdx < 0) return;
    const gem = Game.gems[gIdx];
    eq.sockets[socketIdx] = { uid: gem.uid, key: gem.key, quality: gem.quality };
    Game.gems.splice(gIdx, 1);
    toast("镶嵌成功");
    Save.auto();
    Render.top();
  },

  unsocketGem(eq, socketIdx){
    if(!eq || !eq.sockets) return;
    const g = eq.sockets[socketIdx];
    if(!g) return;
    const cost = GEM_REMOVE_COST[g.quality] || 200;
    if(Game.player.gold < cost) return toast(`金币不足（需 ${cost}）`);
    Game.player.gold -= cost;
    eq.sockets[socketIdx] = null;
    Game.gems.push({ uid: 'g_'+Math.random().toString(36).slice(2,10), key: g.key, quality: g.quality });
    toast(`取下成功 -${cost} 金`);
    Save.auto();
    Render.top();
  },

  /* ---------------- 根据 ref 找装备 ---------------- */
  findEquipByRef(ref){
    if(!ref) return null;
    if(ref.type === 'worn') return Game.worn[ref.slot];
    if(ref.type === 'bag')  return Game.bag[ref.idx];
    return null;
  }
};