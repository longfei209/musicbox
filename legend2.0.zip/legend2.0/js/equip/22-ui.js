/* ============================================================
 *  equip/22-ui.js  —— 装备 UI（详情弹窗 / 选择装备 / 镶嵌页 / 洗练页）
 *  定义为独立对象 EquipUI，由 render/68-nav.js 合并进 Render
 * ============================================================ */

/* 显示工具 */
function _rangeTxt(baseMin, baseMax, refineVal){
  const baseTxt = `${baseMin}-${baseMax}`;
  if(!refineVal) return baseTxt;
  return `${baseTxt}[+${refineVal}]`;
}
function _hpTxt(baseHp, refineHp){
  const baseTxt = `+${baseHp}`;
  if(!refineHp) return baseTxt;
  return `${baseTxt}[+${refineHp}]`;
}
function _socketsTxt(eq){
  if(!eq || !eq.sockets) return '○○○';
  return eq.sockets.map(g => g ? GEMS[g.key].icon : '○').join('');
}

const EquipUI = {
  /* ---------------- 装备详情弹窗 ---------------- */
  showEquipDetail(refType, refId){
    let eq = null;
    if(refType === 'worn') eq = Game.worn[refId];
    else if(refType === 'bag') eq = Game.bag[refId];
    if(!eq) return;

    const q = QUALITY[eq.quality];
    const base = equipBaseRange(eq);
    const gemB = equipGemBonus(eq);
    const afx = equipAffixDesc(eq);
    const socketsTxt = (eq.sockets||[]).map(g=>g?GEMS[g.key].icon:'○').join(' ');

    const atkTxt = _rangeTxt(base.atkMin, base.atkMax, eq.refineAtk);
    const defTxt = _rangeTxt(base.defMin, base.defMax, eq.refineDef);
    const hpTxt  = _hpTxt(base.hp, eq.refineHp);

    let actions = '';
    if(refType === 'bag'){
      actions = `
        <button class="btn" onclick="Equip.wear(${refId});Render.closeEquipDetail()">穿戴</button>
        <button class="btn" onclick="Render.closeEquipDetail();Nav.go('socket',{type:'bag',idx:${refId}})">镶嵌</button>
        <button class="btn" onclick="Render.closeEquipDetail();Nav.go('refine',{type:'bag',idx:${refId}})">洗练</button>
        <button class="btn" onclick="Equip.sell(${refId});Render.closeEquipDetail()">出售</button>
        <button class="btn" onclick="Equip.decompose(${refId});Render.closeEquipDetail()">分解</button>
      `;
    }else{
      actions = `
        <button class="btn" onclick="Render.closeEquipDetail();Nav.go('socket',{type:'worn',slot:'${refId}'})">镶嵌</button>
        <button class="btn" onclick="Render.closeEquipDetail();Nav.go('refine',{type:'worn',slot:'${refId}'})">洗练</button>
        <button class="btn" onclick="Equip.unwear('${refId}');Render.closeEquipDetail()">卸下</button>
      `;
    }

    const html = `
      <div class="modal-title">
        <span class="${q.cls}">${eq.name} <span class="dim">[${q.name}]</span></span>
        <button class="modal-close" onclick="Render.closeEquipDetail()">✕</button>
      </div>
      <div class="modal-row"><span class="lbl">槽位</span><span>${SLOT_NAME[eq.slot]}</span></div>
      <div class="modal-row"><span class="lbl">攻击</span><span>${atkTxt}</span></div>
      <div class="modal-row"><span class="lbl">防御</span><span>${defTxt}</span></div>
      <div class="modal-row"><span class="lbl">速度</span><span>${base.spd}</span></div>
      <div class="modal-row"><span class="lbl">生命</span><span>${hpTxt}</span></div>
      ${(gemB.atk+gemB.def+gemB.hp+gemB.spd+gemB.combo+gemB.counter+gemB.lsPct+gemB.lsFlat+gemB.crit) > 0
        ? `<div class="modal-row"><span class="lbl">宝石加成</span><span>攻+${gemB.atk} 防+${gemB.def} 速+${gemB.spd} HP+${gemB.hp} 连${gemB.combo}% 反${gemB.counter}% 吸${gemB.lsPct}% 固${gemB.lsFlat} 暴${gemB.crit}%</span></div>`
        : ''}
      <div class="modal-row"><span class="lbl">词条</span><span>${afx || '无'}</span></div>
      <div class="modal-row"><span class="lbl">孔位</span><span>${socketsTxt}</span></div>
      <div class="modal-row"><span class="lbl">洗练</span><span>${eq.refineTimes}/3</span></div>
      <div class="modal-actions">${actions}</div>
    `;
    $('equipModalBody').innerHTML = html;
    $('equipModal').classList.remove('hidden');
  },

  closeEquipDetail(){
    $('equipModal').classList.add('hidden');
  },

  /* ---------------- 点击人物页空槽：弹出该槽位可装备列表 ---------------- */
  pickEquipForSlot(slot){
    const slotName = SLOT_NAME[slot];
    const candidates = [];
    Game.bag.forEach((e, idx)=>{
      if(e.slot === slot) candidates.push({ idx, e });
    });

    let rows = '';
    if(candidates.length === 0){
      rows = `<div class="dim" style="text-align:center;padding:18px 0;">背包里没有可装备的「${slotName}」</div>`;
    }else{
      candidates.forEach(({idx, e})=>{
        const q = QUALITY[e.quality];
        const base = equipBaseRange(e);
        const atk = base.atkMax + (e.refineAtk || 0);
        const def = base.defMax + (e.refineDef || 0);
        rows += `<div class="pick-row" onclick="Render._doPickEquip('${slot}',${idx})">
          <span class="${q.cls}">${e.name} <span class="dim">[${q.name}]</span></span>
          <span class="dim">攻${atk} 防${def}</span>
        </div>`;
      });
    }

    const html = `
      <div class="modal-title">
        <span>选择「${slotName}」</span>
        <button class="modal-close" onclick="Render.closeEquipDetail()">✕</button>
      </div>
      ${rows}
      <div class="modal-actions" style="margin-top:10px;">
        <button class="btn ghost" onclick="Render.closeEquipDetail()">取消</button>
      </div>
    `;
    $('equipModalBody').innerHTML = html;
    $('equipModal').classList.remove('hidden');
  },

  /* 从弹窗选中并装备（不走 Nav.go('bag')，直接刷新人物页） */
  _doPickEquip(slot, bagIdx){
    const e = Game.bag[bagIdx];
    if(!e || e.slot !== slot) return;
    const old = Game.worn[slot];
    Game.worn[slot] = e;
    Game.bag.splice(bagIdx, 1);
    if(old) Game.bag.push(old);
    Quest.onWear(e.name);
    Save.auto();
    this.closeEquipDetail();
    Render.wornPage();
    Render.top();
    toast('已装备 ' + e.name);
  },

  /* ---------------- 镶嵌页 ---------------- */
  socketPage(opts){
    opts = opts || {};
    const eq = Equip.findEquipByRef(opts);
    if(!eq){ Nav.back(); return; }
    const q = QUALITY[eq.quality];
    const sockets = eq.sockets || [null, null, null];

    let html = `<div class="card">
      <div class="card-title ${q.cls}">${eq.name} <span class="dim">[${q.name}] ${SLOT_NAME[eq.slot]}</span></div>
      <div class="card-meta">选择孔位 → 点击下方宝石镶嵌</div>
    </div>`;

    html += `<div style="display:flex;gap:6px;margin:8px 0;">`;
    for(let i=0;i<3;i++){
      const g = sockets[i];
      html += `<div class="card" style="flex:1;align-items:center;padding:8px 4px;min-height:70px;">
        <div class="dim" style="font-size:10px;">孔 ${i+1}</div>`;
      if(g){
        const cfg = GEMS[g.key];
        const qCfg = GEM_QUALITY[g.quality];
        html += `<div style="font-size:22px;color:${cfg.color};">${cfg.icon}</div>
          <div style="font-size:10px;">${qCfg.name}</div>
          <button class="btn" style="margin-top:4px;padding:3px;font-size:10px;" onclick="Render._removeGem(${i})">取下</button>`;
      }else{
        html += `<div style="font-size:22px;color:#444;">○</div>
          <div class="dim" style="font-size:10px;">空</div>
          <button class="btn" style="margin-top:4px;padding:3px;font-size:10px;" onclick="Render._selectSocket(${i})" id="socketBtn${i}">选中</button>`;
      }
      html += `</div>`;
    }
    html += `</div>`;

    html += `<div class="dim" style="font-size:11px;margin-top:6px;">你的宝石（点选一颗 → 自动镶到"选中"孔）</div>`;
    if(Game.gems.length === 0){
      html += `<div class="card dim">暂无宝石，去商店购买或打怪掉落</div>`;
    }else{
      const order = ['red','blue','green','purple','orange','black','yellow','white'];
      const sorted = Game.gems.slice().sort((a,b)=>order.indexOf(a.key)-order.indexOf(b.key));
      html += `<div style="display:flex;flex-wrap:wrap;gap:4px;">`;
      sorted.forEach(gem=>{
        const cfg = GEMS[gem.key];
        const qCfg = GEM_QUALITY[gem.quality];
        const statVal = cfg.type==='pct'
          ? gemValue(gem.key,gem.quality)+'%'
          : '+'+gemValue(gem.key,gem.quality);
        html += `<div class="card" style="flex:0 0 calc(33% - 4px);padding:5px;align-items:center;cursor:pointer;" onclick="Render._pickGem('${gem.uid}')">
          <div style="font-size:20px;color:${cfg.color};">${cfg.icon}</div>
          <div style="font-size:9px;">${cfg.name}</div>
          <div style="font-size:9px;color:#888;">${qCfg.name}</div>
          <div style="font-size:11px;font-weight:700;color:#fff;">${cfg.desc} ${statVal}</div>
        </div>`;
      });
      html += `</div>`;
    }

    html += `<div style="margin-top:8px;"><button class="btn" onclick="Nav.back()">返回</button></div>`;

    $('socketBody').innerHTML = html;

    this._socketSelected = (this._socketSelected != null) ? this._socketSelected : -1;
    if(this._socketSelected >= 0){
      const btn = $('socketBtn' + this._socketSelected);
      if(btn){ btn.classList.add('primary'); btn.textContent = '已选'; }
    }
  },

  _selectSocket(i){
    this._socketSelected = i;
    Render.socketPage(Nav._lastOpts);
  },

  _pickGem(gemId){
    const eq = Equip.findEquipByRef(Nav._lastOpts);
    if(!eq) return toast("装备丢失");
    if(this._socketSelected < 0) return toast("请先选一个孔位");
    Equip.socketGem(eq, this._socketSelected, gemId);
    this._socketSelected = -1;
    Render.socketPage(Nav._lastOpts);
  },

  _removeGem(socketIdx){
    const eq = Equip.findEquipByRef(Nav._lastOpts);
    if(!eq) return;
    Equip.unsocketGem(eq, socketIdx);
    Render.socketPage(Nav._lastOpts);
  },

  /* ---------------- 洗练页 ---------------- */
  refinePage(opts){
    opts = opts || {};
    let eq = null;
    if(opts.type === 'worn') eq = Game.worn[opts.slot];
    else if(opts.type === 'bag') eq = Game.bag[opts.idx];
    else if(typeof opts === 'number') eq = Game.bag[opts];

    if(!eq){ Nav.back(); return; }

    const base = equipBaseRange(eq), q = QUALITY[eq.quality];
    const risk = Equip.refineRisk(eq);
    const afx = equipAffixDesc(eq);
    const isWorn = opts.type === 'worn';

    const atkTxt = _rangeTxt(base.atkMin, base.atkMax, eq.refineAtk);
    const defTxt = _rangeTxt(base.defMin, base.defMax, eq.refineDef);
    const hpTxt  = _hpTxt(base.hp, eq.refineHp);

    let html = `<div class="card">
      <div class="card-title ${q.cls}">${eq.name} [${q.name}]${isWorn?' <span class="dim">(装备中)</span>':''}</div>
      <div class="card-meta">区间 攻 ${atkTxt} 防 ${defTxt} HP ${hpTxt}</div>
      <div class="card-meta">速${base.spd} ${afx?'· '+afx:''}</div>
      <div class="card-meta">洗练次数 ${eq.refineTimes}/3 · 持有材料 ${Game.mat}</div>
      <div class="card-meta">本次风险：${(risk*100).toFixed(1)}% 破损</div>
      <div class="card-actions">
        <button class="btn primary" onclick="Render._doRefine()">执行洗练(耗1材料)</button>
      </div>
    </div>`;
    $('refineBody').innerHTML = html;
  },

  _doRefine(){
    const opts = Nav._lastOpts || {};
    let eq = null;
    if(opts.type === 'worn') eq = Game.worn[opts.slot];
    else if(opts.type === 'bag') eq = Game.bag[opts.idx];
    if(!eq) return;
    Equip.refine(eq);
  }
};