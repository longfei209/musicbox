/* ============================================================
 *  equip/20-make.js  —— 装备辅助工具
 *  （生成逻辑在 core/12-attr.js，本文件只放辅助计算）
 * ============================================================ */

/* 出售价格 */
function getEquipSellPrice(eq){
  if(!eq) return 0;
  const base = EQUIP_BASE[eq.name] ? EQUIP_BASE[eq.name].sell : 10;
  return Math.floor(base * (1 + QUALITY[eq.quality].rate * 2) * (eq.affix ? 1.3 : 1));
}

/* 装备评分（自动最强用） */
function getEquipScore(eq){
  if(!eq) return 0;
  const r = equipFullRange(eq);
  return r.atkMax * 1.5 + r.defMax * 1.2 + r.spd * 2 + r.hp * 0.3
       + r.combo * 8 + r.counter * 8 + r.lsPct * 8 + r.lsFlat * 2;
}

/* 单个套装在 worn 里已装备的件数 */
function getSetCount(worn, setName){
  const set = SETS[setName];
  if(!set) return 0;
  let cnt = 0;
  set.members.forEach(nm=>{
    for(const s in worn){
      if(worn[s] && worn[s].name === nm){ cnt++; break; }
    }
  });
  return cnt;
}

/* 所有套装加成汇总（返回区间结构） */
function getSetBonusTotal(worn){
  const bonus = { atkMin:0, atkMax:0, defMin:0, defMax:0, hp:0, spd:0 };
  for(const sk in SETS){
    const set = SETS[sk];
    const cnt = getSetCount(worn, sk);
    if(cnt>=3 && set.bonus3){
      bonus.atkMin += set.bonus3.atk||0; bonus.atkMax += set.bonus3.atk||0;
      bonus.defMin += set.bonus3.def||0; bonus.defMax += set.bonus3.def||0;
    }
    if(cnt>=4 && set.bonus4){
      bonus.atkMin += set.bonus4.atk||0; bonus.atkMax += set.bonus4.atk||0;
      bonus.defMin += set.bonus4.def||0; bonus.defMax += set.bonus4.def||0;
      bonus.hp += set.bonus4.hp||0; bonus.spd += set.bonus4.spd||0;
    }
    if(cnt>=6 && set.bonus6){
      bonus.atkMin += set.bonus6.atk||0; bonus.atkMax += set.bonus6.atk||0;
      bonus.defMin += set.bonus6.def||0; bonus.defMax += set.bonus6.def||0;
      bonus.hp += set.bonus6.hp||0; bonus.spd += set.bonus6.spd||0;
    }
    if(cnt>=2 && set.bonus2){
      bonus.atkMin += set.bonus2.atk||0; bonus.atkMax += set.bonus2.atk||0;
      bonus.defMin += set.bonus2.def||0; bonus.defMax += set.bonus2.def||0;
      bonus.spd += set.bonus2.spd||0;
    }
  }
  return bonus;
}