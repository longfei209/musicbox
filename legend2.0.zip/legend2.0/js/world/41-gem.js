/* ============================================================
 *  world/41-gem.js  —— 宝石 / 碎片系统
 *  掉落 / 合成 / 分解 / 升级碎片 / 传说宝石合成
 * ============================================================ */

function dropGem(boost){
  const key = randomGemKey();
  const q = rollGemQuality(boost);
  return makeGem(key, q);
}

function dropFragment(){
  const key = randomGemKey();
  const r = Math.random();
  const q = r < 0.02 ? 'legend' : (r < 0.10 ? 'rare' : 'normal');
  const frag = Game.fragments[key];
  if(!frag) return null;
  frag[q] = Math.min(FRAG_MAX_STACK, (frag[q] || 0) + 1);
  return { key, quality: q };
}

/* 3 普通碎片 → 1 普通宝石（10% 出稀有） */
function craftGem(key){
  const frag = Game.fragments[key];
  if(!frag || (frag.normal || 0) < FRAG_PER_GEM) return null;
  frag.normal -= FRAG_PER_GEM;
  const up = Math.random() < FRAG_UPGRADE_RARE;
  const quality = up ? 'rare' : 'normal';
  const gem = makeGem(key, quality);
  Game.gems.push(gem);
  return gem;
}

/* 3 低品质 → 1 高品质碎片 */
function upgradeFragment(key, fromQ, toQ){
  const frag = Game.fragments[key];
  if(!frag) return false;
  if((frag[fromQ] || 0) < FRAG_TIER_UP) return false;
  frag[fromQ] -= FRAG_TIER_UP;
  frag[toQ] = Math.min(FRAG_MAX_STACK, (frag[toQ] || 0) + 1);
  return true;
}

/* 传说碎片 ×3 → 传说宝石 */
function craftLegendGem(key){
  const frag = Game.fragments[key];
  if(!frag || (frag.legend || 0) < 3) return null;
  frag.legend -= 3;
  const gem = makeGem(key, 'legend');
  Game.gems.push(gem);
  return gem;
}

/* 1 宝石 → 2 对应品质碎片 */
function decomposeGem(gemUid){
  const idx = Game.gems.findIndex(g => g.uid === gemUid);
  if(idx < 0) return null;
  const gem = Game.gems[idx];
  Game.gems.splice(idx, 1);
  const frag = Game.fragments[gem.key];
  if(frag){
    frag[gem.quality] = Math.min(FRAG_MAX_STACK, (frag[gem.quality] || 0) + 2);
  }
  return gem;
}

function decomposeGemsByKeyQuality(key, quality, count){
  const matches = Game.gems.filter(g => g.key === key && g.quality === quality);
  const actual = Math.min(count, matches.length);
  if(actual <= 0) return 0;
  let removed = 0;
  for(let i = Game.gems.length - 1; i >= 0 && removed < actual; i--){
    const g = Game.gems[i];
    if(g.key === key && g.quality === quality){
      Game.gems.splice(i, 1);
      removed++;
    }
  }
  const frag = Game.fragments[key];
  if(frag){
    frag[quality] = Math.min(FRAG_MAX_STACK, (frag[quality] || 0) + actual * 2);
  }
  return actual;
}

function getFragmentTotal(){
  let total = 0;
  Object.keys(Game.fragments).forEach(k=>{
    const f = Game.fragments[k];
    total += (f.normal || 0) + (f.rare || 0) + (f.legend || 0);
  });
  return total;
}

const GEM_COLOR_ORDER = ['red','blue','green','purple','orange','black','yellow','white'];
const GEM_QUALITY_SORT = ['legend','rare','normal'];

function sortGemList(list){
  return list.sort((a,b)=>{
    const ai = GEM_COLOR_ORDER.indexOf(a.key);
    const bi = GEM_COLOR_ORDER.indexOf(b.key);
    if(ai !== bi) return ai - bi;
    return GEM_QUALITY_SORT.indexOf(a.quality) - GEM_QUALITY_SORT.indexOf(b.quality);
  });
}

function getGemGroups(){
  const groups = {};
  Game.gems.forEach(g=>{
    const k = g.key + '_' + g.quality;
    if(!groups[k]) groups[k] = { key: g.key, quality: g.quality, count: 0 };
    groups[k].count++;
  });
  return sortGemList(Object.values(groups));
}

function getFragmentGroups(){
  const groups = [];
  GEM_COLOR_ORDER.forEach(k=>{
    const f = Game.fragments[k];
    if(!f) return;
    GEM_QUALITY_SORT.forEach(q=>{
      if(f[q] > 0) groups.push({ key:k, quality:q, count:f[q] });
    });
  });
  return groups;
}