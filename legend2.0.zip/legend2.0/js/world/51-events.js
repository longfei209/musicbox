/* ============================================================
 *  world/51-events.js  —— 随机事件
 *  进层 15% 概率触发：宝箱 / 商人 / 陷阱
 * ============================================================ */

const Events = {
  maybeTrigger(){
    if(Math.random() > 0.15) return;

    const t = pick(['chest','trader','trap']);
    const p = Game.player;

    if(t === 'chest'){
      confirmBox("🎁 发现一只宝箱怪！是否打开？", ()=>{
        const ar = AREA_MAP[Game.ui.areaId];
        const fi = Game.ui.floorIdx;
        const tier = ar.dropTier ? ar.dropTier.normal : 1;
        const pool = EQUIP_BY_TIER[tier] || EQUIP_BY_TIER[1] || [];
        if(pool.length === 0){
          toast("宝箱是空的…");
          return;
        }
        const name = pick(pool);
        const eq = makeEquip(name, rollQuality(0.12));
        if(Game.bag.length < p.bagMax){
          Game.bag.push(eq);
          Quest.onBagChange();
          toast(`宝箱获得 ${eq.name} [${QUALITY[eq.quality].name}]`);
        }else{
          toast("背包已满，宝箱丢失");
        }
        Save.auto();
        Render.top();
      });
    }
    else if(t === 'trader'){
      confirmBox("🧙 遇到流浪商人：花 100 金币换 2 个洗练材料？", ()=>{
        if(p.gold < 100) return toast("金币不足");
        p.gold -= 100;
        Game.mat += 2;
        toast("交易成功 +2 材料");
        Save.auto();
        Render.top();
      });
    }
    else if(t === 'trap'){
      const dmg = Math.floor(playerMaxHp() * 0.15);
      p.hp = Math.max(1, p.hp - dmg);
      toast(`⚠️ 触发陷阱！损失 ${dmg} HP`);
      Save.auto();
      Render.top();
    }
  }
};