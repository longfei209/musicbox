/* ============================================================
 *  world/50-quest.js  —— 任务系统
 *  刷新 10 分钟 / 任务多样化
 * ============================================================ */

const Quest = {
  refreshPool(force){
    const now = Date.now();
    if(!force && now - Game.quest.refreshTs < QUEST_POOL_CD) return;
    Game.quest.refreshTs = now;
    Game.quest.avail = [];
    const n = rnd(4, 6);
    for(let i=0; i<n; i++) Game.quest.avail.push(this.gen());
  },

  cdLeft(){
    return Math.max(0, Math.ceil((Game.quest.refreshTs + QUEST_POOL_CD - Date.now()) / 1000));
  },

  gen(){
    const types = ['killMonster','collectItem','reachFloor','wearEquip'];
    const t = pick(types);

    /* ★ 修复：只从「已解锁」区域生成任务，避免刷出锁区任务永远无法完成 */
    const availAreas = AREAS.filter(ar => ar.unlock || (Game.flags && Game.flags[ar.id]));
    const ar = availAreas.length > 0 ? pick(availAreas) : AREAS[0];
    const fi = rnd(0, 2);
    const def = ar.floors[fi];
    const mon = pick(def.pool);
    const eqNames = Object.keys(EQUIP_BASE);
    const eqName = pick(eqNames);

    const tier = def.pool[0].exp > 500 ? 3 : (def.pool[0].exp > 200 ? 2 : 1);
    const goldBase = [200, 400, 700][tier-1] || 200;
    const expBase  = [300, 600, 1000][tier-1] || 300;

    const q = {
      qid: uid(),
      type: t,
      targetId: mon.id,
      targetName: mon.name,
      areaId: ar.id,
      floorIdx: fi,
      equipName: eqName,
      needCount: 1,
      progress: 0,
      finished: false,
      goldReward: goldBase + rnd(0, 300),
      expReward: expBase + rnd(0, 500)
    };

    if(t === 'killMonster'){
      q.needCount = rnd(3, 8);
      q.goldReward = Math.floor(q.goldReward * 1.2);
      q.expReward = Math.floor(q.expReward * 1.2);
    }
    else if(t === 'collectItem'){
      q.needCount = rnd(1, 3);
      q.goldReward = Math.floor(q.goldReward * 1.4);
      q.expReward = Math.floor(q.expReward * 1.4);
    }
    else if(t === 'reachFloor'){
      q.floorIdx = rnd(1, 2);
      q.needCount = 1;
      q.goldReward = Math.floor(q.goldReward * 1.5);
      q.expReward = Math.floor(q.expReward * 1.5);
    }
    else if(t === 'wearEquip'){
      q.needCount = 1;
      q.goldReward = Math.floor(q.goldReward * 1.1);
      q.expReward = Math.floor(q.expReward * 1.1);
    }
    return q;
  },

  desc(q){
    switch(q.type){
      case 'killMonster':
        return `击杀 ${q.needCount} 只「${q.targetName}」 (${q.progress}/${q.needCount})`;
      case 'collectItem':
        return `收集 ${q.needCount} 件「${q.equipName}」 (${q.progress}/${q.needCount})`;
      case 'reachFloor':
        return `到达【${AREA_MAP[q.areaId].name}】第 ${q.floorIdx+1} 层 ${q.finished?'✔':''}`;
      case 'wearEquip':
        return `穿戴「${q.equipName}」 ${q.finished?'✔':''}`;
    }
    return '';
  },

  accept(i){
    if(Game.quest.doing.length >= 3) return toast("最多同时接 3 个任务");
    const q = Game.quest.avail.splice(i, 1)[0];
    if(!q) return;
    Game.quest.doing.push(q);
    if(q.type === 'reachFloor'
      && Game.ui.areaId === q.areaId
      && Game.ui.floorIdx === q.floorIdx){
      q.finished = true;
    }
    if(q.type === 'collectItem') this.recheckCollect(q);
    if(q.type === 'wearEquip'){
      for(const s in Game.worn){
        if(Game.worn[s] && Game.worn[s].name === q.equipName){
          q.finished = true;
          break;
        }
      }
    }
    Save.auto();
    Render.questPage(Nav._lastOpts && Nav._lastOpts.page);
  },

  abandon(i){
    confirmBox("确定放弃该任务？", ()=>{
      Game.quest.doing.splice(i, 1);
      Save.auto();
      Render.questPage(Nav._lastOpts && Nav._lastOpts.page);
    });
  },

  claim(i){
    const q = Game.quest.doing[i];
    if(!q || !q.finished) return;
    Game.player.gold += q.goldReward;
    addExp(q.expReward);
    Game.quest.doing.splice(i, 1);
    toast(`任务完成 +${q.goldReward} 金币 +${q.expReward} 经验`);
    Save.auto();
    Render.questPage(Nav._lastOpts && Nav._lastOpts.page);
    Render.top();
  },

  onKill(protoId){
    let changed = false;
    Game.quest.doing.forEach(q=>{
      if(q.type === 'killMonster' && q.targetId === protoId && !q.finished){
        q.progress++;
        if(q.progress >= q.needCount) q.finished = true;
        changed = true;
      }
    });
    if(changed) Save.auto();
  },

  onReachFloor(areaId, fi){
    let changed = false;
    Game.quest.doing.forEach(q=>{
      if(q.type === 'reachFloor'
        && q.areaId === areaId
        && q.floorIdx === fi
        && !q.finished){
        q.finished = true;
        changed = true;
      }
    });
    if(changed) Save.auto();
  },

  onWear(eqName){
    let changed = false;
    Game.quest.doing.forEach(q=>{
      if(q.type === 'wearEquip' && q.equipName === eqName && !q.finished){
        q.finished = true;
        changed = true;
      }
    });
    if(changed) Save.auto();
  },

  onBagChange(){
    let changed = false;
    Game.quest.doing.forEach(q=>{
      if(q.type === 'collectItem'){
        const before = q.progress;
        this.recheckCollect(q);
        if(q.progress !== before) changed = true;
      }
    });
    if(changed) Save.auto();
  },

  recheckCollect(q){
    let n = 0;
    Game.bag.forEach(e=>{ if(e.name === q.equipName) n++; });
    for(const s in Game.worn){
      if(Game.worn[s] && Game.worn[s].name === q.equipName) n++;
    }
    q.progress = Math.min(n, q.needCount);
    if(q.progress >= q.needCount) q.finished = true;
  }
};