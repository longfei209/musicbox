/* ============================================================
 *  core/13-save.js  —— 存档 / 读档 / 重置
 *  存档版本 v11
 * ============================================================ */

const Save = {
  KEY_AUTO: 'legend_bw_v11_auto',
  KEY_M1:   'legend_bw_v11_m1',
  KEY_M2:   'legend_bw_v11_m2',

  _autoTimer: null,
  _autoPending: false,
  AUTO_THROTTLE: 500,

  pack(){
    return {
      v:11,
      ts: Date.now(),
      player: Game.player, bag: Game.bag, worn: Game.worn,
      mat: Game.mat, pages: Game.pages, skillLv: Game.skillLv,
      areaState: Game.areaState, flags: Game.flags,
      quest: Game.quest, pets: Game.pets, activePets: Game.activePets,
      gems: Game.gems, fragments: Game.fragments,
      stats: Game.stats, ui: Game.ui
    };
  },

  _writeTo(key, silent){
    try{
      localStorage.setItem(key, JSON.stringify(this.pack()));
      if(!silent) toast("已存档");
      return true;
    }catch(e){ toast("存档失败"); return false; }
  },

  auto(){
    /* ★ 修复：战斗中（怪物未清空）跳过自动存档，避免每回合写盘 */
    if(Game.battle && Game.battle.monsters && Game.battle.monsters.some(m => !m.dead)){
      return;
    }
    this._autoPending = true;
    if(this._autoTimer) return;
    this._autoTimer = setTimeout(()=>{
      this._autoTimer = null;
      if(this._autoPending){
        this._autoPending = false;
        this._writeTo(this.KEY_AUTO, true);
      }
    }, this.AUTO_THROTTLE);
  },

  flush(){
    if(this._autoTimer){
      clearTimeout(this._autoTimer);
      this._autoTimer = null;
    }
    if(this._autoPending){
      this._autoPending = false;
      this._writeTo(this.KEY_AUTO, true);
    }
  },

  manual(slot){
    this.flush();
    const key = slot === 1 ? this.KEY_M1 : this.KEY_M2;
    return this._writeTo(key, false);
  },

  getSummary(key){
    const s = localStorage.getItem(key);
    if(!s) return null;
    try{
      const d = JSON.parse(s);
      return {
        lv: (d.player && d.player.lv) || 1,
        gold: (d.player && d.player.gold) || 0,
        ts: d.ts || 0,
        v: d.v
      };
    }catch(e){ return null; }
  },

  load(slot){
    let key;
    if(slot === 'auto') key = this.KEY_AUTO;
    else if(slot === 1) key = this.KEY_M1;
    else if(slot === 2) key = this.KEY_M2;
    else return toast("无效槽位");

    this.flush();

    const s = localStorage.getItem(key);
    if(!s) return toast("该槽位无存档");

    try{
      const d = JSON.parse(s);
      if(d.v !== 11) return toast("存档版本不符");
      Object.assign(Game, {
        player: d.player, bag: d.bag, worn: d.worn,
        mat: d.mat || 0,
        pages: d.pages || 0,
        skillLv: d.skillLv || {},
        areaState: d.areaState,
        flags: d.flags || { dragonCity:false, niumo:false, ghost:false },
        quest: d.quest, pets: d.pets || [], activePets: d.activePets || [],
        gems: d.gems || [], fragments: d.fragments || {},
        stats: d.stats, ui: d.ui || { areaId:null, floorIdx:null },
        battle: null
      });
      if(Game.player.mp == null){ Game.player.mp = 50; Game.player.maxMp = 50; }
      if(Game.player.potionMp == null) Game.player.potionMp = 0;
      if(Game.player.baseAtkMin == null){
        Game.player.baseAtkMin = Game.player.baseAtk || 10;
        Game.player.baseAtkMax = Game.player.baseAtk ? Math.round(Game.player.baseAtk * 1.5) : 15;
        delete Game.player.baseAtk;
      }
      if(Game.player.baseDefMin == null){
        Game.player.baseDefMin = Game.player.baseDef || 5;
        Game.player.baseDefMax = Game.player.baseDef ? Math.round(Game.player.baseDef * 1.6) : 8;
        delete Game.player.baseDef;
      }
      if(!Game.flags.niumo) Game.flags.niumo = false;
      if(!Game.flags.ghost) Game.flags.ghost = false;
      Object.keys(SKILLS).forEach(k=>{
        if(!Game.skillLv[k]) Game.skillLv[k] = 1;
      });

      if(!('bracelet' in Game.worn)) Game.worn.bracelet = null;

      this._fixEquipData();
      this._fixPetData();

      Object.keys(GEMS).forEach(k=>{
        if(!Game.fragments[k]) Game.fragments[k] = { normal:0, rare:0, legend:0 };
      });

      /* ★ 修复：读档后 clamp HP/MP，防止卖装备后数值溢出上限 */
      const mHp = playerMaxHp();
      const mMp = playerMaxMp();
      if(Game.player.hp > mHp) Game.player.hp = mHp;
      if(Game.player.mp > mMp) Game.player.mp = mMp;
      if(Game.player.hp <= 0) Game.player.hp = Math.max(1, Math.floor(mHp * 0.3));
      if(Game.player.mp < 0)  Game.player.mp = 0;
      if(Game.player.gold < 0) Game.player.gold = 0;
      if(Game.player.potion < 0) Game.player.potion = 0;
      if(Game.player.potionMp < 0) Game.player.potionMp = 0;

      /* ★ 修复：清空恢复计时器 */
      Game._recoverTs = 0;
      Game._wasFull = false;

      Nav.home(); Render.top(); Render.home();
      toast("读档完成");
    }catch(e){ console.error(e); toast("读档失败"); }
  },

  _fixEquipData(){
    const convert = (e)=>{
      if(!e) return;
      if(e.atkMin === undefined){
        const base = EQUIP_BASE[e.name] || { atk: 0, def: 0 };
        const atk0 = e.baseAtk || base.atk || 0;
        const def0 = e.baseDef || base.def || 0;
        e.atkMin = Math.round(atk0);
        e.atkMax = Math.round(atk0 * 2.2);
        e.defMin = Math.round(def0);
        e.defMax = Math.round(def0 * 2.0);
        e.spd = e.baseSpd || base.spd || 0;
        e.hp  = e.baseHp  || base.hp  || 0;
        e.tier = base.tier || 1;
        delete e.baseAtk; delete e.baseDef; delete e.baseSpd; delete e.baseHp;
      }
      if(!e.sockets) e.sockets = [null, null, null];
      while(e.sockets.length < 3) e.sockets.push(null);
    };
    Game.bag.forEach(convert);
    for(const s in Game.worn) convert(Game.worn[s]);
  },

  _fixPetData(){
    const QUALITY_MAP = {
      'normal': 'common',
      'good':   'uncommon',
      'fine':   'rare',
      'epic':   'epic'
    };
    const validSkillIds = new Set(Object.keys(PET_SKILLS));

    Game.pets.forEach(p=>{
      if(!p) return;
      if(!PET_QUALITY[p.quality]){
        p.quality = QUALITY_MAP[p.quality] || 'common';
      }
      if(Array.isArray(p.skills)){
        p.skills = p.skills.filter(k => validSkillIds.has(k));
      }else{
        p.skills = [];
      }
      const wantCount = (PET_QUALITY[p.quality] || PET_QUALITY.common).skillCount;
      /* ★ 修复：只补足技能数量，绝不重抽已存在的技能（避免毁号） */
      if(p.skills.length < wantCount){
        const rolled = rollPetSkills(p.quality);
        for(const sk of rolled){
          if(p.skills.length >= wantCount) break;
          if(!p.skills.includes(sk)) p.skills.push(sk);
        }
        const pool = [...PET_SKILL_POOL.base, ...PET_SKILL_POOL.adv];
        let guard = 0;
        while(p.skills.length < wantCount && guard++ < 50){
          const sk = pick(pool);
          if(!p.skills.includes(sk)) p.skills.push(sk);
        }
      }
      /* 不截断超出数量的技能，宁可多不可丢 */

      if(p.hp == null) p.hp = petStatFor(p).hp;
      if(p.downUntil == null) p.downUntil = 0;
      if(p.skillCd == null) p.skillCd = {};
      if(p.deadInBattle == null) p.deadInBattle = false;
      if(!PET_TEMPLATES[p.tpl]){
        p.tpl = Object.keys(PET_TEMPLATES)[0];
        p.name = PET_TEMPLATES[p.tpl].name;
        p.avatar = PET_TEMPLATES[p.tpl].avatar;
      }
    });
  },

  reset(){
    confirmBox("确定全部重置？（所有存档槽都会清空）", ()=>{
      this.flush();
      localStorage.removeItem(this.KEY_AUTO);
      localStorage.removeItem(this.KEY_M1);
      localStorage.removeItem(this.KEY_M2);
      ['legend_bw_v10_auto','legend_bw_v10_m1','legend_bw_v10_m2','legend_bw_v10',
       'legend_bw_v9','legend_bw_v8','legend_bw_v6'].forEach(k=>localStorage.removeItem(k));
      initGame();
      Nav.home(); Render.top(); Render.home();
      toast("已重置");
    });
  }
};

/* 旧版本存档自动清空 */
(function clearOldSave(){
  const oldKeys = [
    'legend_bw_v10_auto','legend_bw_v10_m1','legend_bw_v10_m2','legend_bw_v10',
    'legend_bw_v9','legend_bw_v8','legend_bw_v6'
  ];
  let hadOld = false;
  oldKeys.forEach(k=>{ if(localStorage.getItem(k)){ localStorage.removeItem(k); hadOld = true; } });
  if(hadOld) console.log("[Legend] 旧存档已清空（v11 不兼容）");
})();

/* 页面隐藏 / 关闭时立即写入 */
window.addEventListener('beforeunload', ()=> Save.flush());
document.addEventListener('visibilitychange', ()=>{
  if(document.visibilityState === 'hidden') Save.flush();
});