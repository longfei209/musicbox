/* ============================================================
 *  core/11-state.js  —— Game 状态 / 初始化 / 区域状态 / spawn / 技能等级
 * ============================================================ */

const Game = {
  player:null, bag:[], worn:null,
  mat:0, pages:0,
  skillLv:{},
  areaState:{}, flags:{ dragonCity:false, niumo:false, ghost:false },
  quest:{ doing:[], avail:[], refreshTs:0 },
  ui:{ areaId:null, floorIdx:null },
  battle:null,
  pets:[], activePets:[],
  gems:[], fragments:{},
  stats:{ kills:0, deaths:0 },
  /* ★ 修复：恢复计时相关状态挂到 Game 上，读档/重置时能一并清空 */
  _recoverTs: 0,
  _wasFull: false
};

function initGame(){
  Game.player = {
    lv:1, exp:0, hp:100, maxHp:100, mp:50, maxMp:50,
    baseAtkMin:10, baseAtkMax:15,
    baseDefMin:5,  baseDefMax:8,
    baseSpd:10,
    gold:100, potion:5, potionMp:3, bagMax:30, rage:0
  };
  Game.bag = [];
  Game.worn = { weapon:null, helmet:null, cloth:null, shoe:null, belt:null, bracelet:null, ring:null, neck:null };
  Game.mat = 0;
  Game.pages = 0;
  Game.skillLv = {};
  Object.keys(SKILLS).forEach(k=>{ Game.skillLv[k] = 1; });
  Game.areaState = {};
  Game.flags = { dragonCity:false, niumo:false, ghost:false };
  Game.quest = { doing:[], avail:[], refreshTs: Date.now() - QUEST_POOL_CD - 1000 };
  Game.ui = { areaId:null, floorIdx:null };
  Game.battle = null;
  Game.pets = [];
  Game.activePets = [];
  Game.gems = [];
  Game.fragments = {};
  Object.keys(GEMS).forEach(k=>{
    Game.fragments[k] = { normal:0, rare:0, legend:0 };
  });
  Game.stats = { kills:0, deaths:0 };
  /* ★ 修复：重置恢复计时器 */
  Game._recoverTs = 0;
  Game._wasFull = false;
  Quest.refreshPool(true);
}

/* ---------------- 技能等级 ---------------- */
function getSkillLv(key){
  return (Game.skillLv && Game.skillLv[key]) || 1;
}
function skillDmgMul(key, base){
  const lv = getSkillLv(key);
  return base * (1 + 0.15 * (lv - 1));
}
function skillHealRate(key, base){
  const lv = getSkillLv(key);
  return base * (1 + 0.05 * (lv - 1));
}
function skillBuffMul(key, base){
  const lv = getSkillLv(key);
  return base + 0.02 * (lv - 1);
}
function skillPoisonDmg(){
  const lv = getSkillLv('du');
  return POISON_DMG[lv] || 20;
}

/* ---------------- 常用 ---------------- */
function rollPlayerAtk(){ const a = calcAttr(); return rnd(a.atkMin, a.atkMax); }
function rollPlayerDef(){ const a = calcAttr(); return rnd(a.defMin, a.defMax); }
function playerMaxHp(){ return Game.player.maxHp + calcAttr().addHp; }
function playerMaxMp(){ return Game.player.maxMp; }

/* ---------------- 经验 / 升级 ---------------- */
function addExp(v){
  const p = Game.player;
  const oldLv = p.lv;
  p.exp += v;
  let leveled = false;
  while(p.exp >= expNeed(p.lv)){
    p.exp -= expNeed(p.lv);
    p.lv++;
    p.baseAtkMin += 3;
    p.baseAtkMax += 4;
    p.baseDefMin += 1;
    p.baseDefMax += 2;
    p.maxHp  += 15;
    p.baseSpd += 1;
    p.maxMp  += 8;
    leveled = true;
  }
  if(leveled){
    p.hp = playerMaxHp(); p.mp = playerMaxMp();
    toast("升级！Lv." + p.lv);
    if(oldLv < 10 && p.lv >= 10) toast("🆕 可携带宠物 2 只");
    if(oldLv < 20 && p.lv >= 20) toast("🆕 可携带宠物 3 只");
    if(oldLv < 30 && p.lv >= 30) toast("🆕 可携带宠物 4 只");
    Save.auto();
  }
  Render.top();
}

/* ---------------- 区域状态 ---------------- */
function areaState(id){
  if(!Game.areaState[id]){
    const def = AREA_MAP[id];
    Game.areaState[id] = {
      floors: def.floors.map(()=>({ groups:[], bossDeath:0, spawned:false }))
    };
  }
  return Game.areaState[id];
}

function spawnGroup(areaId, fi){
  const ar = AREA_MAP[areaId];
  const pool = ar.floors[fi].pool;
  const count = rnd(1,4);
  const members = [];
  let groupName = '';
  for(let i=0;i<count;i++){
    const proto = pick(pool);
    const isElite = Math.random() < ELITE_CHANCE;
    const m = {
      mid: uid(), protoId: proto.id, name: proto.name,
      hp: proto.hp, maxHp: proto.hp,
      atk: proto.atk, def: proto.def, spd: proto.spd,
      exp: proto.exp, gMin: proto.gMin, gMax: proto.gMax,
      behavior: proto.behavior,
      elite: isElite, affixes: [],
      dead: false, deathTs: 0, vamp: 0, pois: 0,
      summonCount: 0, poison: null, slow: null
    };
    if(i === 0) groupName = proto.name;
    if(isElite){
      m.name = "精英·" + m.name;
      m.hp = Math.floor(m.hp*1.6); m.maxHp = m.hp;
      m.atk = Math.floor(m.atk*1.3);
      m.def = Math.floor(m.def*1.3);
      m.exp = Math.floor(m.exp*1.8);
      m.gMin = Math.floor(m.gMin*2); m.gMax = Math.floor(m.gMax*2);
      const n = rnd(1,2);
      const chosen = [...ELITE_AFFIXES].sort(()=>Math.random()-0.5).slice(0, n);
      chosen.forEach(af=>{ af.apply(m); m.affixes.push(af.k); });
    }
    members.push(m);
  }
  return { gid: uid(), name: groupName, members, alive:true, deathTs:0 };
}

function spawnFloor(areaId, fi){
  const st = areaState(areaId).floors[fi];
  st.groups = [];
  const n = rnd(4, 8);
  for(let g=0; g<n; g++) st.groups.push(spawnGroup(areaId, fi));
  st.spawned = true;
}

function tickRespawn(areaId, fi){
  const st = areaState(areaId).floors[fi];
  const now = Date.now();
  let changed = false;
  st.groups.forEach((g, gi)=>{
    if(!g.alive && g.deathTs && now - g.deathTs >= RESPAWN_MON){
      const ng = spawnGroup(areaId, fi);
      st.groups[gi] = ng;
      changed = true;
    }
  });
  if(st.bossDeath && now - st.bossDeath >= RESPAWN_BOSS) st.bossDeath = 0;
  return changed;
}

function rollDropEquip(areaId, monType){
  const ar = AREA_MAP[areaId];
  if(!ar || !ar.dropTier) return null;
  const dt = ar.dropTier;
  let tier;
  if(monType === 'boss') tier = dt.boss;
  else if(monType === 'elite'){
    const arr = dt.elite;
    tier = Array.isArray(arr) ? pick(arr) : arr;
  } else {
    tier = dt.normal;
  }
  const pool = EQUIP_BY_TIER[tier] || [];
  if(pool.length === 0) return null;
  const name = pick(pool);
  const boost = monType === 'boss' ? 0.15 : (monType === 'elite' ? 0.08 : 0);
  return makeEquip(name, rollQuality(boost));
}