/* ============================================================
 *  core/12-attr.js  —— 装备生成 / 装备区间 / 玩家属性计算
 * ============================================================ */

/* ---------------- 品质 roll ---------------- */
function rollQuality(boost){
  const r = Math.random();
  const epicC = 0.03 + (boost||0);
  const fineC = 0.15 + (boost||0);
  const goodC = 0.40 + (boost||0)*1.5;
  if(r < epicC) return 'epic';
  if(r < fineC) return 'fine';
  if(r < goodC) return 'good';
  return 'normal';
}

/* ---------------- 装备生成 ---------------- */
function makeEquip(name, quality){
  const base = EQUIP_BASE[name];
  if(!base) return null;
  const q = quality || rollQuality();
  const qc = QUALITY[q];
  const qMin = 1 + qc.rate;
  const atkMin = Math.round(base.atk * qMin);
  const defMin = Math.round(base.def * qMin);
  const atkMax = Math.round(atkMin * 2.2);
  const defMax = Math.round(defMin * 2.0);
  const eq = {
    uid: uid(), name, slot: base.slot, tier: base.tier,
    atkMin, atkMax, defMin, defMax,
    spd: base.spd || 0,
    hp:  base.hp  || 0,
    quality: q,
    refineAtk:0, refineDef:0, refineHp:0, refineTimes:0,
    affix:null, affixVal:0,
    sockets: [null, null, null]
  };
  const chance = AFFIX_CHANCE[q] || 0;
  if(Math.random() < chance){
    const a = pick(AFFIXES);
    const v = a.roll();
    eq.affix = a.k;
    eq.affixVal = v;
  }
  return eq;
}

/* ---------------- 装备区间 ---------------- */
function equipBaseRange(eq){
  if(!eq) return { atkMin:0, atkMax:0, defMin:0, defMax:0, spd:0, hp:0 };
  let atkMin = eq.atkMin, atkMax = eq.atkMax;
  let defMin = eq.defMin, defMax = eq.defMax;
  let spd = eq.spd || 0;
  let hp  = eq.hp  || 0;
  if(eq.affix){
    const v = eq.affixVal || 0;
    switch(eq.affix){
      case 'atk':    atkMax += v; break;
      case 'def':    defMax += v; break;
      case 'spd':    spd += v; break;
      case 'hp':     hp += v; break;
    }
  }
  return { atkMin, atkMax, defMin, defMax, spd, hp };
}

function equipWithRefineRange(eq){
  const b = equipBaseRange(eq);
  if(!eq) return b;
  return {
    atkMin: b.atkMin,
    atkMax: b.atkMax + (eq.refineAtk || 0),
    defMin: b.defMin,
    defMax: b.defMax + (eq.refineDef || 0),
    spd: b.spd,
    hp: b.hp + (eq.refineHp || 0)
  };
}

function equipGemBonus(eq){
  const bonus = { atk:0, def:0, hp:0, spd:0,
                  combo:0, counter:0, lsPct:0, lsFlat:0, crit:0 };
  if(!eq || !eq.sockets) return bonus;
  eq.sockets.forEach(gem=>{
    if(!gem) return;
    const cfg = getGemCfg(gem.key, gem.quality);
    if(!cfg) return;
    bonus[cfg.stat] = (bonus[cfg.stat] || 0) + cfg.value;
  });
  return bonus;
}

function equipFullRange(eq){
  const b = equipWithRefineRange(eq);
  const g = equipGemBonus(eq);
  return {
    atkMin: b.atkMin,
    atkMax: b.atkMax + g.atk,
    defMin: b.defMin,
    defMax: b.defMax + g.def,
    spd: b.spd + g.spd,
    hp:  b.hp + g.hp,
    combo: g.combo,
    counter: g.counter,
    lsPct: g.lsPct,
    lsFlat: g.lsFlat,
    crit: g.crit
  };
}

function equipFullBonus(eq){
  const r = equipFullRange(eq);
  return {
    atk: r.atkMax, def: r.defMax, spd: r.spd, hp: r.hp,
    combo: r.combo, counter: r.counter,
    lsPct: r.lsPct, lsFlat: r.lsFlat, crit: r.crit, critd: 0
  };
}

function equipCompareStat(eq){
  if(!eq) return { atk:0, def:0, spd:0, hp:0, combo:0, counter:0, lsPct:0, lsFlat:0, crit:0, critd:0 };
  const r = equipBaseRange(eq);
  let combo = 0, counter = 0, lsPct = 0, lsFlat = 0, crit = 0, critd = 0;
  if(eq.affix){
    const v = eq.affixVal || 0;
    switch(eq.affix){
      case 'crit':   crit += v; break;
      case 'critd':  critd += v; break;
      case 'combo':  combo += v; break;
      case 'counter':counter += v; break;
      case 'lsPct':  lsPct += v; break;
      case 'lsFlat': lsFlat += v; break;
    }
  }
  return { atk: r.atkMax, def: r.defMax, spd: r.spd, hp: r.hp, combo, counter, lsPct, lsFlat, crit, critd };
}

function equipAffixDesc(eq){
  if(!eq || !eq.affix) return '';
  const a = AFFIXES.find(x=>x.k===eq.affix);
  return a ? a.desc(eq.affixVal) : '';
}

/* ---------------- 玩家属性 ---------------- */
function calcAttr(){
  let atkMin = Game.player.baseAtkMin, atkMax = Game.player.baseAtkMax;
  let defMin = Game.player.baseDefMin, defMax = Game.player.baseDefMax;
  let spd = Game.player.baseSpd, addHp = 0;
  let combo = 0, counter = 0, lsPct = 0, lsFlat = 0;
  let crit = 0.12, critD = 1.3;
  for(const s in Game.worn){
    const e = Game.worn[s]; if(!e) continue;
    const r = equipFullRange(e);
    atkMin += r.atkMin; atkMax += r.atkMax;
    defMin += r.defMin; defMax += r.defMax;
    spd += r.spd; addHp += r.hp;
    combo += r.combo; counter += r.counter;
    lsPct += r.lsPct; lsFlat += r.lsFlat;
    crit += r.crit / 100;
    if(e.affix){
      const v = e.affixVal || 0;
      switch(e.affix){
        case 'crit':   crit += v/100; break;
        case 'critd':  critD += v/100; break;
        case 'combo':  combo += v; break;
        case 'counter':counter += v; break;
        case 'lsPct':  lsPct += v; break;
        case 'lsFlat': lsFlat += v; break;
      }
    }
  }
  /* 套装加成 */
  const sb = getSetBonusTotal(Game.worn);
  atkMin += sb.atkMin; atkMax += sb.atkMax;
  defMin += sb.defMin; defMax += sb.defMax;
  addHp += sb.hp; spd += sb.spd;

  /* 宠物被动 */
  const activePetObjs = getActivePetObjects();
  activePetObjs.forEach(p=>{
    const pst = petStatFor(p);
    atkMin += pst.pAtk||0; atkMax += pst.pAtk||0;
    defMin += pst.pDef||0; defMax += pst.pDef||0;
    spd += pst.pSpd||0;
    const st = petSkillStateFor(p);
    if(st.pSpdBonus) spd = Math.floor(spd * (1 + st.pSpdBonus));
    if(st.pDefBonus){
      defMin = Math.floor(defMin * (1 + st.pDefBonus));
      defMax = Math.floor(defMax * (1 + st.pDefBonus));
    }
  });
  return {
    atkMin, atkMax, defMin, defMax,
    spd, addHp,
    combo: combo/100,
    counter: counter/100,
    lsPct: lsPct/100,
    lsFlat,
    crit, critD
  };
}