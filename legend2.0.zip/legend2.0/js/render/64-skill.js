/* ============================================================
 *  render/64-skill.js  —— 技能升级页
 * ============================================================ */

const RenderSkill = {
  skillPage(){
    const order = ['liehuo','banyue','zhiyu','du','zhanshen'];
    let html = `<div class="dim" style="font-size:12px;padding:0 0 8px;">
      📖 书页：<b style="color:#fff;">${Game.pages||0}</b> （商店 300 金/张）
    </div>`;

    order.forEach(k=>{
      const sk = SKILLS[k];
      const lv = getSkillLv(k);
      const maxed = lv >= sk.maxLv;
      const nextLv = lv + 1;
      const cost = maxed ? 0 : SKILL_UPGRADE_COST[nextLv];
      const canUp = !maxed && (Game.pages||0) >= cost;

      html += `<div class="card">
        <div class="card-title">${sk.name} <span class="dim">Lv.${lv}/${sk.maxLv}</span></div>
        <div class="card-meta">${sk.desc} · ${this._effectDesc(k)}</div>
        <div class="card-meta">解锁 Lv.${sk.unlock} · 蓝耗 ${sk.mp} · CD ${sk.cd} 回合</div>
        ${maxed
          ? `<div class="card-meta" style="color:#9d9;">已满级</div>`
          : `<div class="card-meta">升级到 Lv.${nextLv} 需 📖 ${cost}</div>
             <div class="card-actions">
               <button class="btn ${canUp?'primary':''}" onclick="Render._doSkillUp('${k}')" ${canUp?'':'disabled'}>升级</button>
             </div>`}
      </div>`;
    });

    $('skillBody').innerHTML = html;
  },

  _effectDesc(key){
    switch(key){
      case 'liehuo': return `伤害 ×${skillDmgMul('liehuo', 1.8).toFixed(2)}`;
      case 'banyue': return `群体 ×${skillDmgMul('banyue', 0.9).toFixed(2)}`;
      case 'zhiyu':  return `回血 ${(skillHealRate('zhiyu', 0.25)*100).toFixed(1)}%`;
      case 'du':     return `每回合 -${skillPoisonDmg()} HP，持续 3 回合`;
      case 'zhanshen': return `攻防 +${Math.round((skillBuffMul('zhanshen', 1.3)-1)*100)}%，3 回合`;
    }
    return '';
  },

  _doSkillUp(key){
    const sk = SKILLS[key];
    const lv = getSkillLv(key);
    if(lv >= sk.maxLv) return toast("已满级");
    const cost = SKILL_UPGRADE_COST[lv + 1];
    if((Game.pages||0) < cost) return toast(`书页不足（需 ${cost}）`);
    Game.pages -= cost;
    Game.skillLv[key] = lv + 1;
    toast(`${sk.name} 升级到 Lv.${lv+1}！`);
    Save.auto();
    Render.skillPage();
    Render.top();
  }
};