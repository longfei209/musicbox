/* ============================================================
 *  render/61-bag.js  —— 背包页（装备 / 宝石 / 合成 三个 tab）
 * ============================================================ */

const RenderBag = {
  bagPage(opts){
    opts = opts || {};
    const tab = opts.tab || 'equip';
    const page = opts.page || 1;

    let headerHtml = `<div class="dim" style="font-size:11px;padding:0 0 6px;">
      金 ${fmt(Game.player.gold)} · 📖 ${Game.pages||0} 页 · 红 ${Game.player.potion} · 蓝 ${Game.player.potionMp} · 材 ${Game.mat}
    </div>`;
    headerHtml += `<div style="display:flex;gap:5px;margin-bottom:6px;">
      <button class="btn ${tab==='equip'?'primary':''}" onclick="Nav._show('bag',{tab:'equip',page:1})">装备</button>
      <button class="btn ${tab==='gem'?'primary':''}" onclick="Nav._show('bag',{tab:'gem',page:1})">宝石</button>
      <button class="btn ${tab==='craft'?'primary':''}" onclick="Nav._show('bag',{tab:'craft',page:1})">合成</button>
    </div>`;

    if(tab === 'equip'){
      const sellableCount = this._countSellableWhite();
      headerHtml += `<div style="display:flex;gap:5px;margin-bottom:6px;">
        <button class="btn ghost" style="font-size:11px;padding:6px 4px;"
          onclick="Render._sellAllWhite()" ${sellableCount>0?'':'disabled'}>
          🗑 一键出售白装（${sellableCount}）
        </button>
      </div>`;
    }

    let result;
    if(tab === 'equip') result = this._bagEquipTab(page);
    else if(tab === 'gem') result = this._bagGemTab(page);
    else result = this._bagCraftTab(page);

    $('bagList').innerHTML = headerHtml + result.list;
    $('bagPager').innerHTML = result.pager || '';
  },

  _countSellableWhite(){
    let n = 0;
    Game.bag.forEach(e => { if(this._isSellableWhite(e)) n++; });
    return n;
  },

  _isSellableWhite(e){
    if(!e) return false;
    if(e.quality !== 'normal') return false;
    if(e.sockets && e.sockets.some(g => g)) return false;
    if(e.refineTimes > 0) return false;
    return true;
  },

  _sellAllWhite(){
    const list = Game.bag.filter(e => this._isSellableWhite(e));
    if(list.length === 0) return toast("没有可出售的白装");

    let total = 0;
    list.forEach(e => { total += getEquipSellPrice(e); });

    confirmBox(
      `确定出售全部白装？\n共 ${list.length} 件，预计 +${total} 金币\n\n（有宝石或已洗练的装备会自动跳过）`,
      ()=>{
        let removed = 0, gained = 0;
        for(let i = Game.bag.length - 1; i >= 0; i--){
          const e = Game.bag[i];
          if(this._isSellableWhite(e)){
            gained += getEquipSellPrice(e);
            Game.bag.splice(i, 1);
            removed++;
          }
        }
        Game.player.gold += gained;
        Quest.onBagChange();
        Save.auto();
        Render.top();
        toast(`售出 ${removed} 件，+${gained} 金币`);
        Nav._show('bag', { tab: 'equip', page: 1 });
      }
    );
  },

  _bagEquipTab(page){
    const list = Game.bag;
    const total = Math.max(1, Math.ceil(list.length / PAGE_SIZE.bag));
    page = clamp(page, 1, total);
    const start = (page-1) * PAGE_SIZE.bag;
    const slice = list.slice(start, start + PAGE_SIZE.bag);
    let html = `<div class="dim" style="font-size:11px;padding:0 0 4px;">背包 ${list.length}/${Game.player.bagMax}</div>`;
    if(list.length === 0){
      html += `<div class="card dim">空空如也</div>`;
    }else{
      slice.forEach((e, i)=>{
        const idx = start + i;
        const q = QUALITY[e.quality];
        const base = equipBaseRange(e);
        const atkTxt = _rangeTxt(base.atkMin, base.atkMax, e.refineAtk);
        const defTxt = _rangeTxt(base.defMin, base.defMax, e.refineDef);
        const hpTxt  = _hpTxt(base.hp, e.refineHp);
        const cmp = Equip.compareToWorn(e);

        const cmpLine = (label, nVal, oVal, isPct) => {
          if(nVal === 0 && oVal === 0) return '';
          const diff = nVal - oVal;
          if(diff === 0) return '';
          const up = diff > 0;
          const cls = up ? 'cmp-up' : 'cmp-down';
          const arrow = up ? '↑' : '↓';
          const text = isPct ? signedPct(diff) : signed(diff);
          return `<span style="margin-right:6px;">${label} ${text} ${arrow}</span>`;
        };
        const cmpHtml = [
          cmpLine('攻', cmp.atk.n, cmp.atk.o),
          cmpLine('防', cmp.def.n, cmp.def.o),
          cmpLine('速', cmp.spd.n, cmp.spd.o),
          cmpLine('HP', cmp.hp.n, cmp.hp.o),
          cmpLine('连', cmp.combo.n, cmp.combo.o, true),
          cmpLine('反', cmp.counter.n, cmp.counter.o, true),
          cmpLine('吸', cmp.lsPct.n, cmp.lsPct.o, true),
          cmpLine('固', cmp.lsFlat.n, cmp.lsFlat.o),
          cmpLine('暴', cmp.crit.n, cmp.crit.o, true)
        ].filter(x=>x).join('');

        html += `<div class="card clickable" onclick="Render.showEquipDetail('bag',${idx})">
          <div class="card-title ${q.cls}">${e.name} <span class="dim">[${q.name}]</span></div>
          <div class="card-meta">攻 ${atkTxt} 防 ${defTxt} 速 ${base.spd} HP ${hpTxt} · 洗练 ${e.refineTimes}/3 · ${_socketsTxt(e)}</div>
          <div class="card-meta" style="font-size:11px;">${cmpHtml || '<span class="dim">无对比</span>'}</div>
          <div class="card-actions bag-actions">
            <button class="btn" onclick="event.stopPropagation();Equip.wear(${idx})">穿戴</button>
            <button class="btn" onclick="event.stopPropagation();Nav.go('socket',{type:'bag',idx:${idx}})">镶嵌</button>
            <button class="btn" onclick="event.stopPropagation();Nav.go('refine',{type:'bag',idx:${idx}})">洗练</button>
            <button class="btn" onclick="event.stopPropagation();Equip.sell(${idx})">出售</button>
            <button class="btn" onclick="event.stopPropagation();Equip.decompose(${idx})">分解</button>
          </div>
        </div>`;
      });
    }
    let pagerHtml = '';
    if(total > 1){
      pagerHtml = `<div class="pager">
        <button ${page<=1?'disabled':''} onclick="Nav._show('bag',{tab:'equip',page:${page-1}})">◀</button>
        <span>${page} / ${total}</span>
        <button ${page>=total?'disabled':''} onclick="Nav._show('bag',{tab:'equip',page:${page+1}})">▶</button>
      </div>`;
    }
    return { list: html, pager: pagerHtml };
  },

  _bagGemTab(page){
    page = page || 1;
    const gemList = getGemGroups();
    const PAGE = PAGE_SIZE.bagGem;
    const total = Math.max(1, Math.ceil(gemList.length / PAGE));
    page = clamp(page, 1, total);
    const start = (page-1) * PAGE;
    const slice = gemList.slice(start, start + PAGE);

    let html = `<div class="dim" style="font-size:11px;padding:0 0 4px;">宝石 ${Game.gems.length} 颗</div>`;
    if(gemList.length === 0){
      html += `<div class="card dim">暂无宝石（怪物掉落或商店购买）</div>`;
    }else{
      slice.forEach(it=>{
        const cfg = GEMS[it.key];
        const qCfg = GEM_QUALITY[it.quality];
        const statVal = cfg.type==='pct'
          ? gemValue(it.key,it.quality)+'%'
          : '+'+gemValue(it.key,it.quality);
        html += `<div class="card" style="padding:6px 8px;">
          <div class="card-title" style="font-size:13px;margin-bottom:4px;">
            <span style="color:${cfg.color};font-size:16px;">${cfg.icon}</span>
            ${cfg.name}
            <span style="float:right;color:#9d9;">×${it.count}</span>
          </div>
          <div style="font-size:11px;color:#aaa;margin-bottom:2px;">${qCfg.name}</div>
          <div style="font-size:16px;font-weight:700;color:#fff;margin-bottom:4px;">${cfg.desc} ${statVal}</div>
          <div class="card-actions">
            <button class="btn" onclick="Render._openGemDecompose('${it.key}','${it.quality}')">分解</button>
          </div>
        </div>`;
      });
    }
    let pagerHtml = '';
    if(total > 1){
      pagerHtml = `<div class="pager">
        <button ${page<=1?'disabled':''} onclick="Nav._show('bag',{tab:'gem',page:${page-1}})">◀</button>
        <span>${page} / ${total}</span>
        <button ${page>=total?'disabled':''} onclick="Nav._show('bag',{tab:'gem',page:${page+1}})">▶</button>
      </div>`;
    }
    return { list: html, pager: pagerHtml };
  },

  _bagCraftTab(page){
    page = page || 1;
    const fragGroups = getFragmentGroups();
    const PAGE = PAGE_SIZE.bagGem;
    const total = Math.max(1, Math.ceil(fragGroups.length / PAGE));
    page = clamp(page, 1, total);
    const start = (page-1) * PAGE;
    const slice = fragGroups.slice(start, start + PAGE);

    const totalFrags = getFragmentTotal();
    let html = `<div class="dim" style="font-size:11px;padding:0 0 4px;">碎片 ${totalFrags} 个</div>`;
    if(fragGroups.length === 0){
      html += `<div class="card dim">暂无碎片（宝石分解或怪物掉落获得）</div>`;
    }else{
      slice.forEach(f=>{
        const cfg = GEMS[f.key];
        const qCfg = GEM_QUALITY[f.quality];
        html += `<div class="card" style="padding:6px 8px;">
          <div class="card-title" style="font-size:13px;">
            <span style="color:${cfg.color};font-size:15px;">🧩</span>
            ${cfg.name}碎片
            <span class="dim">[${qCfg.name}]</span>
            <span style="float:right;color:#9d9;">×${f.count}</span>
          </div>
          <div class="card-actions" style="margin-top:6px;">
            ${f.quality==='normal' && f.count>=3 ? `<button class="btn" onclick="Render._craftGem('${f.key}')">合成</button>` : ''}
            ${f.quality==='normal' && f.count>=6 ? `<button class="btn" onclick="Render._craftAllGem('${f.key}')">合成全部</button>` : ''}
            ${f.quality==='normal' && f.count>=3 ? `<button class="btn ghost" onclick="Render._upgradeFrag('${f.key}','normal','rare')">升级稀有</button>` : ''}
            ${f.quality==='rare' && f.count>=3 ? `<button class="btn ghost" onclick="Render._upgradeFrag('${f.key}','rare','legend')">升级传说</button>` : ''}
            ${f.quality==='legend' && f.count>=3 ? `<button class="btn primary" onclick="Render._craftLegendGem('${f.key}')">合成传说宝石</button>` : ''}
          </div>
        </div>`;
      });
    }
    let pagerHtml = '';
    if(total > 1){
      pagerHtml = `<div class="pager">
        <button ${page<=1?'disabled':''} onclick="Nav._show('bag',{tab:'craft',page:${page-1}})">◀</button>
        <span>${page} / ${total}</span>
        <button ${page>=total?'disabled':''} onclick="Nav._show('bag',{tab:'craft',page:${page+1}})">▶</button>
      </div>`;
    }
    return { list: html, pager: pagerHtml };
  },

  _craftGem(key){
    const g = craftGem(key);
    if(!g) return toast("碎片不足");
    toast(`合成成功：${GEMS[g.key].name}（${GEM_QUALITY[g.quality].name}）`);
    Save.auto();
    Nav._show('bag',{tab:'craft',page:1});
    Render.top();
  },
  _craftAllGem(key){
    let count = 0;
    while(craftGem(key)) count++;
    if(count === 0) return toast("碎片不足");
    toast(`合成了 ${count} 颗${GEMS[key].name}`);
    Save.auto();
    Nav._show('bag',{tab:'craft',page:1});
    Render.top();
  },
  _upgradeFrag(key, fromQ, toQ){
    const ok = upgradeFragment(key, fromQ, toQ);
    if(!ok) return toast("碎片不足");
    toast(`升级成功：${GEMS[key].name}碎片（${GEM_QUALITY[toQ].name}）`);
    Save.auto();
    Nav._show('bag',{tab:'craft',page:1});
  },
  _craftLegendGem(key){
    const g = craftLegendGem(key);
    if(!g) return toast("传说碎片不足（需 3 个）");
    toast(`合成成功：${GEMS[g.key].name}（传说）`);
    Save.auto();
    Nav._show('bag',{tab:'craft',page:1});
    Render.top();
  },

  _openGemDecompose(key, quality){
    const total = Game.gems.filter(g => g.key === key && g.quality === quality).length;
    if(total === 0) return toast("没有宝石");
    const cfg = GEMS[key];
    const qCfg = GEM_QUALITY[quality];

    let btns = '';
    if(total >= 1) btns += `<button class="btn" onclick="Render._doDecomposeGem('${key}','${quality}',1)">分解 1 颗</button>`;
    if(total >= 3) btns += `<button class="btn" onclick="Render._doDecomposeGem('${key}','${quality}',3)">分解 3 颗</button>`;
    if(total > 1)  btns += `<button class="btn danger" onclick="Render._doDecomposeGem('${key}','${quality}',${total})">全部 ×${total}</button>`;

    const html = `
      <div class="modal-title">
        <span><span style="color:${cfg.color};font-size:16px;">${cfg.icon}</span> ${cfg.name} <span class="dim">[${qCfg.name}]</span></span>
        <button class="modal-close" onclick="Render.closeEquipDetail()">✕</button>
      </div>
      <div class="modal-row"><span class="lbl">拥有</span><span>×${total}</span></div>
      <div class="modal-actions" style="margin-top:10px;">${btns}</div>
      <div class="modal-actions" style="margin-top:6px;">
        <button class="btn ghost" onclick="Render.closeEquipDetail()">取消</button>
      </div>
    `;
    $('equipModalBody').innerHTML = html;
    $('equipModal').classList.remove('hidden');
  },

  _doDecomposeGem(key, quality, count){
    const actual = decomposeGemsByKeyQuality(key, quality, count);
    if(actual <= 0) return toast("分解失败");
    const qCfg = GEM_QUALITY[quality];
    toast(`分解 ${GEMS[key].name} ×${actual} → ${actual*2} 个${qCfg.name}碎片`);
    Save.auto();
    Render.closeEquipDetail();
    const page = (Nav._lastOpts && Nav._lastOpts.page) || 1;
    Nav._show('bag',{tab:'gem',page});
    Render.top();
  }
};