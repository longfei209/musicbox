/* ============================================================
 *  render/68-nav.js  —— 导航层 + 渲染合并 + 定时器
 * ============================================================ */

/* ---------------- 恢复参数 ---------------- */
/* ★ 修复：原 RECOVER_INTERVAL=2500 与 tick 周期 1500 不整除，
 *   实际回血节奏在 3.0s / 4.5s 之间抖动。改为 3000（整除 1500）。 */
const RECOVER_INTERVAL = 3000;
const RECOVER_HP_PER_TICK = 0.05;
const RECOVER_MP_PER_TICK = 0.075;
const RECOVER_PET_HP_PER_TICK = 0.08;

/* ---------------- 非战斗自动恢复 ---------------- */
function tickRecover(){
  if(Game.battle) return false;
  const now = Date.now();
  /* ★ 修复：计时器状态挂到 Game 上，读档/重置时由 initGame 归零 */
  if(now - (Game._recoverTs || 0) < RECOVER_INTERVAL) return false;
  Game._recoverTs = now;

  const mHp = playerMaxHp();
  const mMp = playerMaxMp();
  let changed = false;

  if(Game.player.hp < mHp){
    const heal = Math.max(1, Math.floor(mHp * RECOVER_HP_PER_TICK));
    Game.player.hp = Math.min(mHp, Game.player.hp + heal);
    changed = true;
  }
  if(Game.player.mp < mMp){
    const heal = Math.max(1, Math.floor(mMp * RECOVER_MP_PER_TICK));
    Game.player.mp = Math.min(mMp, Game.player.mp + heal);
    changed = true;
  }

  Game.pets.forEach(p=>{
    if(!p) return;
    if(p.deadInBattle) return;
    if(p.downUntil && p.downUntil > Date.now()) return;
    const pMax = petStatFor(p).hp;
    if(p.hp < pMax){
      const heal = Math.max(1, Math.floor(pMax * RECOVER_PET_HP_PER_TICK));
      p.hp = Math.min(pMax, p.hp + heal);
      changed = true;
    }
  });

  const playerFull = Game.player.hp >= mHp && Game.player.mp >= mMp;
  const petsFull = Game.pets.every(p => {
    if(!p) return true;
    if(p.downUntil && p.downUntil > Date.now()) return true;
    return p.hp >= petStatFor(p).hp;
  });
  const nowFull = playerFull && petsFull;
  /* ★ 修复：只在"从不满到满"的瞬间写一次存档，避免每 tick 都写 */
  if(changed && nowFull && !Game._wasFull){
    Save.auto();
  }
  Game._wasFull = nowFull;
  return changed;
}

/* ---------------- 合并工具 ---------------- */
function _mergeWithCheck(name, ...mods){
  const result = {};
  const seen = {};
  const labels = mods.map((m, i) => {
    if(!m) return `#${i}(null)`;
    if(m._moduleName) return m._moduleName;
    return `#${i}`;
  });
  mods.forEach((obj, idx) => {
    if(!obj) return;
    Object.keys(obj).forEach(k => {
      if(k in seen){
        console.warn(
          `[Legend] ${name} 合并冲突：方法 "${k}" 在 ${labels[seen[k]]} 和 ${labels[idx]} 中重复，` +
          `后者将覆盖前者。`
        );
      }
      seen[k] = idx;
      result[k] = obj[k];
    });
  });
  return result;
}

RenderHome._moduleName  = 'RenderHome';
RenderBag._moduleName   = 'RenderBag';
RenderWorn._moduleName  = 'RenderWorn';
RenderPet._moduleName   = 'RenderPet';
RenderSkill._moduleName = 'RenderSkill';
RenderShop._moduleName  = 'RenderShop';
RenderQuest._moduleName = 'RenderQuest';
RenderSave._moduleName  = 'RenderSave';
EquipUI._moduleName     = 'EquipUI';

CombatUI._moduleName      = 'CombatUI';
CombatActions._moduleName = 'CombatActions';

/* ---------------- 导航 ---------------- */
const Nav = {
  stack: ['home'],
  _lastOpts: {},

  go(pageName, opts){
    if(this.stack[this.stack.length-1] === pageName){
      this._show(pageName, opts);
      return;
    }
    this.stack.push(pageName);
    this._show(pageName, opts);
  },

  back(){
    if(this.stack.length <= 1) return this.home();
    this.stack.pop();
    const prev = this.stack[this.stack.length-1];
    this._show(prev);
  },

  home(){
    this.stack = ['home'];
    this._show('home');
  },

  _show(pageName, opts){
    this._lastOpts = opts || {};
    document.querySelectorAll('.page').forEach(el=>el.classList.add('hidden'));
    const pageEl = $('page-'+pageName);
    if(pageEl) pageEl.classList.remove('hidden');

    switch(pageName){
      case 'home':   Render.home(); break;
      case 'area':   Render.areaPage(); break;
      case 'floor':  Render.floorPage(); break;
      case 'worn':   Render.wornPage(); break;
      case 'bag':    Render.bagPage(opts); break;
      case 'refine': Render.refinePage(opts); break;
      case 'shop':   Render.shopPage(opts); break;
      case 'quest':  Render.questPage(opts && opts.page || 1); break;
      case 'pet':    Render.petPage(); break;
      case 'socket': Render.socketPage(opts); break;
      case 'skill':  Render.skillPage(); break;
      case 'save':   Render.savePage(); break;
      case 'load':   Render.loadPage(); break;
      case 'battle': Combat.render(); break;
    }
  }
};

/* ---------------- 合并 Render ---------------- */
const Render = _mergeWithCheck('Render',
  RenderHome,
  RenderBag,
  RenderWorn,
  RenderPet,
  RenderSkill,
  RenderShop,
  RenderQuest,
  RenderSave,
  EquipUI
);

/* ---------------- 合并 Combat ---------------- */
const Combat = _mergeWithCheck('Combat',
  CombatUI,
  CombatActions
);

/* ---------------- 定时器 ---------------- */
setInterval(()=>{
  tickRecover();

  if(!$('page-home').classList.contains('hidden')) Render.top();
  if(Game.battle) Combat.render();

  if(typeof tickPetRespawn === 'function' && tickPetRespawn()){
    if(!$('page-pet').classList.contains('hidden')) Render.petPage();
    if(Game.battle) Combat.render();
    Render.top();
  }
}, 1500);