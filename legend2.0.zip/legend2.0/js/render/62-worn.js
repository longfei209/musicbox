/* ============================================================
 *  render/62-worn.js  —— 人物页
 *  顶部操作条 + 中间小人 + 左右各 4 格装备栏
 * ============================================================ */

const RenderWorn = {
  wornPage(){
    /* ★ 修复：给 Equip.autoBest() 加 UI 入口（原本此方法无任何调用方） */
    let html = `<div style="display:flex;gap:5px;margin-bottom:6px;">
      <button class="btn sm ghost" style="margin:0;" onclick="Equip.autoBest()">⚡ 一键最强</button>
    </div>`;

    html += `<div class="worn-layout">
      <div class="worn-col worn-col-left">
        ${this._slotHtml('weapon')}
        ${this._slotHtml('helmet')}
        ${this._slotHtml('cloth')}
        ${this._slotHtml('shoe')}
      </div>
      <div class="worn-center">
        ${this._centerHtml()}
      </div>
      <div class="worn-col worn-col-right">
        ${this._slotHtml('belt')}
        ${this._slotHtml('bracelet')}
        ${this._slotHtml('ring')}
        ${this._slotHtml('neck')}
      </div>
    </div>`;
    $('wornBody').innerHTML = html;
  },

  _centerHtml(){
    const a = calcAttr();
    const mHp = playerMaxHp(), mMp = playerMaxMp();
    return `
      <div class="worn-avatar">🧙</div>
      <div class="worn-lv">Lv.${Game.player.lv}</div>
      <div class="worn-stat">HP ${Math.floor(Game.player.hp)}/${mHp}</div>
      <div class="worn-stat">MP ${Math.floor(Game.player.mp)}/${mMp}</div>
      <div class="worn-stat">攻 ${a.atkMin}-${a.atkMax}</div>
      <div class="worn-stat">防 ${a.defMin}-${a.defMax}</div>
      <div class="worn-stat">速 ${a.spd}</div>
      <div class="worn-stat">暴 ${(a.crit*100).toFixed(0)}%</div>
    `;
  },

  _slotHtml(slot){
    const e = Game.worn[slot];
    const slotName = SLOT_NAME[slot];
    if(e){
      const q = QUALITY[e.quality];
      const base = equipBaseRange(e);
      const atk = base.atkMax + (e.refineAtk || 0);
      const def = base.defMax + (e.refineDef || 0);
      const sockets = _socketsTxt(e);
      return `<div class="worn-slot filled" onclick="Render.showEquipDetail('worn','${slot}')">
        <div class="worn-slot-label">${slotName}</div>
        <div class="worn-slot-name ${q.cls}">${e.name}</div>
        <div class="worn-slot-quality ${q.cls}">[${q.name}]</div>
        <div class="worn-slot-stat">攻${atk} 防${def}</div>
        <div class="worn-slot-sockets">${sockets}</div>
      </div>`;
    }else{
      return `<div class="worn-slot empty" onclick="Render.pickEquipForSlot('${slot}')">
        <div class="worn-slot-label">${slotName}</div>
        <div class="worn-slot-empty-icon">＋</div>
      </div>`;
    }
  }
};