/* ============================================================
 *  render/66-quest.js  —— 任务面板
 * ============================================================ */

const RenderQuest = {
  questPage(page){
    page = page || 1;
    Quest.refreshPool(false);

    const items = [];

    Game.quest.doing.forEach((q, i)=>{
      const desc = Quest.desc(q);
      let actions = '';
      if(q.finished){
        actions += `<button class="btn primary" onclick="Quest.claim(${i})">领取</button>`;
      }
      actions += `<button class="btn ghost" onclick="Quest.abandon(${i})">放弃</button>`;
      items.push({
        label:`[进行] ${desc}`,
        sub:`奖励 ${q.goldReward}金 · ${q.expReward}经验`,
        actions
      });
    });

    Game.quest.avail.forEach((q, i)=>{
      items.push({
        label:`[可接] ${Quest.desc(q)}`,
        sub:`奖励 ${q.goldReward}金 · ${q.expReward}经验`,
        actions:`<button class="btn" onclick="Quest.accept(${i})">接取</button>`
      });
    });

    const cdLeft = Quest.cdLeft();
    const cdMin = Math.floor(cdLeft / 60);
    const cdSec = cdLeft % 60;
    const cdTxt = cdMin > 0 ? `${cdMin}分${cdSec}s` : `${cdSec}s`;

    const total = Math.max(1, Math.ceil(items.length / PAGE_SIZE.quest));
    page = clamp(page, 1, total);
    const start = (page-1) * PAGE_SIZE.quest;
    const slice = items.slice(start, start + PAGE_SIZE.quest);

    let html = `<div class="dim" style="font-size:11px;padding:0 0 4px;">
      进行中 ${Game.quest.doing.length}/3 · 刷新 ${cdTxt}
    </div>`;
    if(slice.length === 0){
      html += `<div class="card dim">暂无任务</div>`;
    }
    slice.forEach(it=>{
      html += `<div class="card">
        <div class="card-title">${it.label}</div>
        <div class="card-meta">${it.sub}</div>
        <div class="card-actions">${it.actions}</div>
      </div>`;
    });
    $('questList').innerHTML = html;
    $('questPager').innerHTML = total > 1
      ? `<button ${page<=1?'disabled':''} onclick="Nav._show('quest',{page:${page-1}})">◀</button><span>${page} / ${total}</span><button ${page>=total?'disabled':''} onclick="Nav._show('quest',{page:${page+1}})">▶</button>`
      : '';
  }
};