/* ============================================================
 *  render/65-shop.js  —— 商店页面（道具 / 宝石 / 书页）
 *  ★ 修复：分页器统一渲染到 #shopPager，与背包/任务页结构一致
 * ============================================================ */

const RenderShop = {
  shopPage(opts){
    opts = opts || {};
    const tab = opts.tab || 'item';
    const page = opts.page || 1;

    let html = `<div class="dim" style="font-size:12px;padding:0 0 6px;">
      💰 金币：<b style="color:#d8b;">${fmt(Game.player.gold)}</b> · 📖 书页：<b style="color:#fff;">${Game.pages||0}</b>
    </div>`;

    html += `<div style="display:flex;gap:6px;margin-bottom:6px;">
      <button class="btn ${tab==='item'?'primary':''}" onclick="Nav._show('shop',{tab:'item',page:1})">道具</button>
      <button class="btn ${tab==='gem'?'primary':''}" onclick="Nav._show('shop',{tab:'gem',page:1})">宝石</button>
      <button class="btn ${tab==='page'?'primary':''}" onclick="Nav._show('shop',{tab:'page',page:1})">书页</button>
    </div>`;

    let result;
    if(tab === 'item') result = this._shopItemTab(page);
    else if(tab === 'gem') result = this._shopGemTab(page);
    else result = this._shopPageTab(page);

    $('shopList').innerHTML = html + result.list;
    $('shopPager').innerHTML = result.pager || '';
  },

  _pagerHtml(page, total, tab){
    if(total <= 1) return '';
    return `<button ${page<=1?'disabled':''} onclick="Nav._show('shop',{tab:'${tab}',page:${page-1}})">◀</button>
      <span>${page} / ${total}</span>
      <button ${page>=total?'disabled':''} onclick="Nav._show('shop',{tab:'${tab}',page:${page+1}})">▶</button>`;
  },

  _shopItemTab(page){
    const items = [];
    items.push({label:`红药 ×1`, sub:`${POTION_PRICE}金 · 回35%HP`, action:`Shop.buyPotion(1)`});
    items.push({label:`红药 ×10`, sub:`${POTION_PRICE*10}金`, action:`Shop.buyPotion(10)`});
    items.push({label:`蓝药 ×1`, sub:`${POTION_MP_PRICE}金 · 回30%MP`, action:`Shop.buyPotionMp(1)`});
    items.push({label:`蓝药 ×10`, sub:`${POTION_MP_PRICE*10}金`, action:`Shop.buyPotionMp(10)`});
    items.push({label:`宠物蛋`, sub:`500金 · 随机普通/优秀`, action:`Shop.buyPetEgg()`});
    SHOP_LIST.forEach(name=>{
      const b = EQUIP_BASE[name];
      if(!b) return;
      items.push({
        label: name,
        sub: `[${SLOT_NAME[b.slot]}] 基础攻${b.atk} 防${b.def} · ${b.buy}金`,
        action: `Shop.buyEquip('${name}')`
      });
    });

    const total = Math.ceil(items.length / PAGE_SIZE.shop);
    page = clamp(page, 1, total);
    const start = (page-1) * PAGE_SIZE.shop;
    const slice = items.slice(start, start + PAGE_SIZE.shop);
    let html = '';
    slice.forEach(it=>{
      html += `<div class="card card-h">
        <div class="card-h-main">
          <div class="card-title">${it.label}</div>
          <div class="card-meta">${it.sub}</div>
        </div>
        <div class="card-h-btn">
          <button class="btn" onclick="${it.action}">购买</button>
        </div>
      </div>`;
    });
    return { list: html, pager: this._pagerHtml(page, total, 'item') };
  },

  _shopGemTab(page){
    page = page || 1;
    const items = [];
    items.push({
      label: '💎 宝石商店',
      sub: '购买宝石后，去「人物」或「背包」点装备卡片 → 镶嵌',
      action: null
    });
    GEM_COLOR_ORDER.forEach(k=>{
      const g = GEMS[k];
      items.push({
        label: `${g.icon} ${g.name} [普通]`,
        sub: `${g.desc} +${g.val[0]}${g.type==='pct'?'%':''} · ${GEM_SHOP_PRICE}金`,
        action: `Shop.buyGem('${k}')`
      });
    });

    const total = Math.ceil(items.length / PAGE_SIZE.shop);
    page = clamp(page, 1, total);
    const start = (page-1) * PAGE_SIZE.shop;
    const slice = items.slice(start, start + PAGE_SIZE.shop);
    let html = '';
    slice.forEach(it=>{
      if(!it.action){
        html += `<div class="card" style="padding:6px 8px;">
          <div class="card-title" style="font-size:12px;">${it.label}</div>
          <div class="card-meta">${it.sub}</div>
        </div>`;
      }else{
        html += `<div class="card card-h" style="padding:6px 8px;">
          <div class="card-h-main">
            <div class="card-title" style="font-size:12px;">${it.label}</div>
            <div class="card-meta">${it.sub}</div>
          </div>
          <div class="card-h-btn">
            <button class="btn" onclick="${it.action}">购买</button>
          </div>
        </div>`;
      }
    });
    return { list: html, pager: this._pagerHtml(page, total, 'gem') };
  },

  _shopPageTab(page){
    const items = [
      {label:`📖 书页 ×1`,  sub:`${PAGE_PRICE}金 · 用于技能升级`,                   action:`Shop.buyPage(1)`,   btn:'购买'},
      {label:`📖 书页 ×5`,  sub:`${PAGE_PRICE*5}金`,                                action:`Shop.buyPage(5)`,   btn:'购买'},
      {label:`📖 书页 ×10`, sub:`${PAGE_PRICE*10}金`,                               action:`Shop.buyPage(10)`,  btn:'购买'},
      {label:`💰 出售书页`, sub:`每张 ${PAGE_SELL} 金 · 当前拥有 ${Game.pages||0} 页`, action:`Shop.sellPage(1)`,  btn:'出售'}
    ];
    let html = '';
    items.forEach(it=>{
      html += `<div class="card card-h" style="padding:6px 8px;">
        <div class="card-h-main">
          <div class="card-title" style="font-size:12px;">${it.label}</div>
          <div class="card-meta">${it.sub}</div>
        </div>
        <div class="card-h-btn">
          <button class="btn" onclick="${it.action}">${it.btn}</button>
        </div>
      </div>`;
    });
    return { list: html, pager: '' };
  }
};