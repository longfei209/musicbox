/* ============================================================
 *  config/02-pet-data.js  —— 宠物模板 / 品质 / 技能 / 抽池
 * ============================================================ */

/* ---------------- 12 只宠物 ---------------- */
const PET_TEMPLATES = {
  wolf:   {name:'影狼', avatar:'🐺', base:{atk:10,def:3, hp:50, spd:10}},
  bear:   {name:'山熊', avatar:'🐻', base:{atk:5, def:10,hp:100,spd:5}},
  eagle:  {name:'迅鹰', avatar:'🦅', base:{atk:8, def:4, hp:45, spd:18}},
  snake:  {name:'毒蛇', avatar:'🐍', base:{atk:9, def:3, hp:40, spd:14}},
  turtle: {name:'玄龟', avatar:'🐢', base:{atk:4, def:14,hp:130,spd:3}},
  fox:    {name:'灵狐', avatar:'🦊', base:{atk:11,def:3, hp:38, spd:16}},
  tiger:  {name:'猛虎', avatar:'🐯', base:{atk:12,def:6, hp:80, spd:8}},
  scorp:  {name:'毒蝎', avatar:'🦂', base:{atk:9, def:7, hp:55, spd:10}},
  lion:   {name:'金狮', avatar:'🦁', base:{atk:11,def:8, hp:85, spd:10}},
  wraith: {name:'怨灵', avatar:'👻', base:{atk:10,def:5, hp:60, spd:13}},
  dragon: {name:'幼龙', avatar:'🐉', base:{atk:14,def:10,hp:110,spd:12}},
  phoenix:{name:'火凤', avatar:'🐦', base:{atk:8, def:6, hp:70, spd:15}}
};

/* 抽蛋池：常见 55% / 稀有 35% / 传说 10% */
const PET_POOLS = {
  common: ['wolf','bear','eagle','snake','turtle','fox'],
  rare:   ['tiger','scorp','lion','wraith'],
  legend: ['dragon','phoenix']
};

function rollPetTemplate(){
  const r = Math.random();
  let pool;
  if(r < 0.55) pool = PET_POOLS.common;
  else if(r < 0.90) pool = PET_POOLS.rare;
  else pool = PET_POOLS.legend;
  return pick(pool);
}

/* ---------------- 宠物品质（独立 5 层） ---------------- */
const PET_QUALITY = {
  common:  { k:'common',  name:'普通', mult:1.00, skillCount:0, cls:'q-normal' },
  uncommon:{ k:'uncommon',name:'优秀', mult:1.25, skillCount:0, cls:'q-good' },
  rare:    { k:'rare',    name:'精良', mult:1.60, skillCount:1, cls:'q-fine' },
  epic:    { k:'epic',    name:'史诗', mult:2.00, skillCount:2, cls:'q-epic' },
  legend:  { k:'legend',  name:'传说', mult:2.50, skillCount:3, cls:'q-legend' }
};
const PET_QUALITY_ORDER = ['common','uncommon','rare','epic','legend'];

/* 抽宠物品质：boost 0~1（商店蛋 0 / 精英蛋 0.05 / BOSS 蛋 0.15） */
function rollPetQuality(boost){
  const b = boost || 0;
  const r = Math.random();
  const legendC = 0.02 + b * 0.5;
  const epicC   = legendC + 0.06 + b * 0.3;
  const rareC   = epicC   + 0.14 + b * 0.1;
  const uncC    = rareC   + 0.33;
  if(r < legendC) return 'legend';
  if(r < epicC)   return 'epic';
  if(r < rareC)   return 'rare';
  if(r < uncC)    return 'uncommon';
  return 'common';
}

/* ---------------- 宠物技能（20 个，分 3 档） ---------------- */
const PET_SKILLS = {
  /* 基础池（3 阶可抽） */
  crit:   {name:'锐爪', tier:'base', desc:'暴击+12%',                  apply:st=>{st.crit += 0.12;}},
  ls:     {name:'嗜血', tier:'base', desc:'吸血12%',                   apply:st=>{st.ls += 0.12;}},
  iron:   {name:'铁壁', tier:'base', desc:'宠防+40% 主防+8%',          apply:st=>{st.defBonus=0.40; st.pDefBonus=0.08;}},
  swift:  {name:'迅捷', tier:'base', desc:'宠速+20% 主速+8%',          apply:st=>{st.spdBonus=0.20; st.pSpdBonus=0.08;}},
  heavy:  {name:'重击', tier:'base', desc:'15%概率1.8倍伤害',          apply:st=>{st.heavy=0.15;}},
  double: {name:'连咬', tier:'base', desc:'15%概率追加60%伤害',        apply:st=>{st.double=0.15;}},
  ragePet:{name:'怒火', tier:'base', desc:'主低血宠攻+50%',            apply:st=>{st.ragePet=true;}},

  /* 进阶池（4 阶可抽） */
  group:  {name:'撕咬', tier:'adv', desc:'每2回合群攻×0.22',           apply:st=>{st.group=true;}},
  heal:   {name:'守护', tier:'adv', desc:'每3回合回主人10%HP',         apply:st=>{st.heal=0.10;}},
  reflect:{name:'反伤', tier:'adv', desc:'主人受击反12%伤害',          apply:st=>{st.reflect=0.12;}},
  guard:  {name:'护主', tier:'adv', desc:'主人受击宠承担20%',          apply:st=>{st.guard=0.20;}},
  pois:   {name:'剧毒', tier:'adv', desc:'攻击附带剧毒',               apply:st=>{st.pois=true;}},
  pierce: {name:'破防', tier:'adv', desc:'无视目标30%防御',            apply:st=>{st.pierce=0.30;}},
  dodge:  {name:'闪避', tier:'adv', desc:'12%概率让主人躲避伤害',      apply:st=>{st.dodge=0.12;}},
  regen:  {name:'回春', tier:'adv', desc:'每回合回主人2%HP',           apply:st=>{st.regen=0.02;}},
  slow:   {name:'减速', tier:'adv', desc:'30%概率降目标20%速',         apply:st=>{st.slow=0.30;}},
  rage:   {name:'狂暴', tier:'adv', desc:'宠攻+20%',                   apply:st=>{st.atkBonus=0.20;}},

  /* 传说池（5 阶才可抽） */
  nirvana:  {name:'涅槃', tier:'legend', desc:'主人首次致死，宠替死并损50%HP', apply:st=>{st.nirvana=true;}},
  timestop: {name:'时停', tier:'legend', desc:'每场首次出手，怪物本回合无法行动', apply:st=>{st.timestop=true;}},
  flame:    {name:'焚天', tier:'legend', desc:'主人单体攻击时，宠物追加40%伤害', apply:st=>{st.flame=true;}}
};

const PET_SKILL_POOL = {
  base:   ['crit','ls','iron','swift','heavy','double','ragePet'],
  adv:    ['group','heal','reflect','guard','pois','pierce','dodge','regen','slow','rage'],
  legend: ['nirvana','timestop','flame']
};

const PET_SKILL_CD = { heal: 3, group: 2 };

/* 按品质抽技能（1-2 无 / 3 一个基础 / 4 两个基础+进阶 / 5 三个必含传说） */
function rollPetSkills(quality){
  const q = quality || 'common';
  if(q === 'common' || q === 'uncommon') return [];

  if(q === 'rare'){
    return [pick(PET_SKILL_POOL.base)];
  }

  const pickN = (pool, n) => {
    const copy = pool.slice();
    const out = [];
    for(let i=0; i<n && copy.length>0; i++){
      const idx = Math.floor(Math.random() * copy.length);
      out.push(copy[idx]);
      copy.splice(idx, 1);
    }
    return out;
  };

  if(q === 'epic'){
    const pool = [...PET_SKILL_POOL.base, ...PET_SKILL_POOL.adv];
    return pickN(pool, 2);
  }

  if(q === 'legend'){
    const legendSkill = pick(PET_SKILL_POOL.legend);
    const rest = pickN([...PET_SKILL_POOL.base, ...PET_SKILL_POOL.adv], 2);
    return [legendSkill, ...rest];
  }

  return [];
}