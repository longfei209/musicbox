/* ============================================================
 *  config/01-equip-data.js  —— 装备基础表 / 套装 / 商店列表
 * ============================================================ */

/* ---------------- 装备基础表 ---------------- */
const EQUIP_BASE = {
  "木剑":     {slot:"weapon", tier:1, atk:3,  def:0,  spd:0, hp:0, buy:200,  sell:80},
  "铁剑":     {slot:"weapon", tier:2, atk:4,  def:1,  spd:0, hp:0, buy:600,  sell:240},
  "精钢剑":   {slot:"weapon", tier:3, atk:7,  def:2,  spd:0, hp:0, buy:1800, sell:700},
  "屠龙":     {slot:"weapon", tier:4, atk:11, def:3,  spd:0, hp:0, buy:4500, sell:1800},
  "魔龙斩":   {slot:"weapon", tier:5, atk:15, def:4,  spd:2, hp:0, buy:9000, sell:3600},
  "布帽":     {slot:"helmet", tier:1, atk:0,  def:1,  spd:1, hp:0,  buy:120,  sell:48},
  "皮帽":     {slot:"helmet", tier:2, atk:0,  def:2,  spd:1, hp:10, buy:400,  sell:160},
  "铁盔":     {slot:"helmet", tier:3, atk:1,  def:4,  spd:1, hp:25, buy:1200, sell:480},
  "战神头盔": {slot:"helmet", tier:4, atk:2,  def:6,  spd:1, hp:45, buy:2800, sell:1100},
  "龙鳞头盔": {slot:"helmet", tier:5, atk:3,  def:8,  spd:1, hp:70, buy:6000, sell:2400},
  "布衣":     {slot:"cloth", tier:1, atk:0,  def:2,  spd:0, hp:10, buy:180,  sell:72},
  "皮甲":     {slot:"cloth", tier:2, atk:0,  def:3,  spd:0, hp:20, buy:500,  sell:200},
  "锁子甲":   {slot:"cloth", tier:3, atk:2,  def:5,  spd:0, hp:40, buy:1600, sell:640},
  "战神铠甲": {slot:"cloth", tier:4, atk:3,  def:8,  spd:0, hp:70, buy:3500, sell:1400},
  "龙鳞铠甲": {slot:"cloth", tier:5, atk:4,  def:11, spd:0, hp:110,buy:7500, sell:3000},
  "草鞋":     {slot:"shoe", tier:1, atk:0,  def:1,  spd:1, hp:0,  buy:80,   sell:32},
  "布鞋":     {slot:"shoe", tier:2, atk:0,  def:1,  spd:2, hp:0,  buy:200,  sell:80},
  "皮靴":     {slot:"shoe", tier:3, atk:0,  def:2,  spd:3, hp:5,  buy:800,  sell:320},
  "战神战靴": {slot:"shoe", tier:4, atk:1,  def:4,  spd:4, hp:10, buy:2000, sell:800},
  "龙鳞战靴": {slot:"shoe", tier:5, atk:2,  def:5,  spd:5, hp:20, buy:5000, sell:2000},
  "麻绳":     {slot:"belt", tier:1, atk:0,  def:1,  spd:0, hp:0,  buy:70,   sell:28},
  "兽皮腰带": {slot:"belt", tier:2, atk:0,  def:1,  spd:1, hp:10, buy:200,  sell:80},
  "铁腰带":   {slot:"belt", tier:3, atk:1,  def:3,  spd:1, hp:25, buy:900,  sell:360},
  "战神腰带": {slot:"belt", tier:4, atk:2,  def:4,  spd:3, hp:45, buy:2200, sell:880},
  "龙鳞腰带": {slot:"belt", tier:5, atk:3,  def:6,  spd:3, hp:75, buy:5500, sell:2200},
  "木镯":     {slot:"bracelet", tier:1, atk:0, def:1, spd:0, hp:0,  buy:100,  sell:40},
  "铜镯":     {slot:"bracelet", tier:2, atk:1, def:1, spd:1, hp:5,  buy:350,  sell:140},
  "银镯":     {slot:"bracelet", tier:3, atk:2, def:3, spd:1, hp:15, buy:1000, sell:400},
  "战神手镯": {slot:"bracelet", tier:4, atk:3, def:5, spd:2, hp:30, buy:2500, sell:1000},
  "龙鳞手镯": {slot:"bracelet", tier:5, atk:4, def:7, spd:2, hp:50, buy:5500, sell:2200},
  "木戒":     {slot:"ring", tier:1, atk:1,  def:0,  spd:1, hp:0,  buy:90,   sell:36},
  "青铜戒指": {slot:"ring", tier:2, atk:2,  def:1,  spd:2, hp:0,  buy:300,  sell:120},
  "银戒":     {slot:"ring", tier:3, atk:3,  def:2,  spd:2, hp:0,  buy:1100, sell:440},
  "力量戒指": {slot:"ring", tier:4, atk:4,  def:3,  spd:3, hp:0,  buy:2600, sell:1040},
  "龙鳞戒指": {slot:"ring", tier:5, atk:6,  def:4,  spd:3, hp:20, buy:6000, sell:2400},
  "草链":     {slot:"neck", tier:1, atk:1,  def:0,  spd:0, hp:0,  buy:80,   sell:32},
  "木项链":   {slot:"neck", tier:2, atk:1,  def:1,  spd:1, hp:0,  buy:250,  sell:100},
  "银链":     {slot:"neck", tier:3, atk:2,  def:2,  spd:1, hp:15, buy:1000, sell:400},
  "魔龙项链": {slot:"neck", tier:4, atk:4,  def:3,  spd:4, hp:30, buy:3000, sell:1200},
  "龙鳞项链": {slot:"neck", tier:5, atk:6,  def:4,  spd:4, hp:50, buy:6500, sell:2600}
};

/* 按 tier 分组 */
const EQUIP_BY_TIER = { 1:[], 2:[], 3:[], 4:[], 5:[] };
Object.keys(EQUIP_BASE).forEach(name=>{
  const t = EQUIP_BASE[name].tier;
  if(EQUIP_BY_TIER[t]) EQUIP_BY_TIER[t].push(name);
});

/* 商店基础列表 */
const SHOP_LIST = ["木剑","铁剑","布帽","皮帽","布衣","皮甲","草鞋","布鞋","麻绳","兽皮腰带","木镯","铜镯","木戒","青铜戒指","草链","木项链"];

/* ---------------- 套装 ---------------- */
const SETS = {
  "战神": { name:"战神套", members:["战神头盔","战神铠甲","战神战靴","战神腰带","战神手镯"], bonus3:{atk:15,def:10}, bonus4:{atk:30,def:25,hp:80,spd:5} },
  "魔龙": { name:"魔龙套", members:["魔龙斩","魔龙项链"], bonus2:{atk:20,def:15,spd:5} },
  "龙鳞": { name:"龙鳞套", members:["龙鳞头盔","龙鳞铠甲","龙鳞战靴","龙鳞腰带","龙鳞手镯","龙鳞戒指","龙鳞项链"], bonus3:{atk:30,def:20}, bonus6:{atk:60,def:45,hp:200,spd:8} }
};