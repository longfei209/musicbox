/* ============================================================
 *  config/03-gem-data.js  —— 宝石定义 / 品质 / 掉落参数
 * ============================================================ */

const GEM_QUALITY = {
  normal:{ k:'normal', name:'普通', cls:'q-normal', color:'#aaa' },
  rare:  { k:'rare',   name:'稀有', cls:'q-fine',   color:'#89d' },
  legend:{ k:'legend', name:'传说', cls:'q-epic',   color:'#ffd700' }
};

const GEMS = {
  red:    { k:'red',    name:'红宝石', color:'#c85a5a', icon:'🔴', stat:'atk',    val:[3,6,12],   type:'num', desc:'攻击' },
  blue:   { k:'blue',   name:'蓝宝石', color:'#5a7ac8', icon:'🔵', stat:'def',    val:[2,5,10],   type:'num', desc:'防御' },
  green:  { k:'green',  name:'绿宝石', color:'#5ac87a', icon:'🟢', stat:'hp',     val:[15,30,60], type:'num', desc:'生命' },
  purple: { k:'purple', name:'紫宝石', color:'#a05ac8', icon:'🟣', stat:'combo',  val:[1,2,4],    type:'pct', desc:'连击率' },
  orange: { k:'orange', name:'橙宝石', color:'#d89a4a', icon:'🟠', stat:'counter',val:[1,2,4],    type:'pct', desc:'反击率' },
  black:  { k:'black',  name:'黑宝石', color:'#555',    icon:'⚫', stat:'lsPct',  val:[1,2,4],    type:'pct', desc:'吸血率' },
  yellow: { k:'yellow', name:'黄宝石', color:'#d8d84a', icon:'🟡', stat:'lsFlat', val:[2,5,10],   type:'num', desc:'固定吸血' },
  white:  { k:'white',  name:'白宝石', color:'#e8e8e8', icon:'⚪', stat:'crit',   val:[1,2,4],    type:'pct', desc:'暴击率' }
};

const GEM_QUALITY_ORDER = ['normal','rare','legend'];
const GEM_SHOP_PRICE = 200;
const GEM_REMOVE_COST = { normal:200, rare:500, legend:1000 };
const FRAG_PER_GEM = 3;
const FRAG_UPGRADE_RARE = 0.10;
const FRAG_TIER_UP = 3;
const FRAG_MAX_STACK = 999;
const GEM_DROP_RATE = { normalMon: 0.05, elite: 0.10, boss: 0.20 };
const GEM_DROP_SPLIT = 0.50;
const EQUIP_SOCKETS = 3;