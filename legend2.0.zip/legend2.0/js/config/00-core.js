/* ============================================================
 *  config/00-core.js  —— 核心常量 / 品质 / 槽位 / 词条 / 技能 / 全局常量
 * ============================================================ */

/* ---------------- 品质（装备用 4 层） ---------------- */
const QUALITY = {
  normal:{ k:'normal', name:'普通', cls:'q-normal', rate:0,    bMin:1.0, bMax:1.0, mult:1.0 },
  good:  { k:'good',   name:'优秀', cls:'q-good',   rate:0.15, bMin:1.0, bMax:1.5, mult:1.3 },
  fine:  { k:'fine',   name:'精良', cls:'q-fine',   rate:0.30, bMin:1.2, bMax:2.2, mult:1.7 },
  epic:  { k:'epic',   name:'史诗', cls:'q-epic',   rate:0.55, bMin:1.5, bMax:3.5, mult:2.2 }
};
const DECOMP_MAT = { normal:1, good:2, fine:4, epic:8 };

/* ---------------- 槽位 ---------------- */
const SLOT_NAME = { weapon:"武器", helmet:"头盔", cloth:"衣服", shoe:"鞋子", belt:"腰带", bracelet:"手镯", ring:"戒指", neck:"项链" };
const SLOT_ORDER = ['weapon','helmet','cloth','shoe','belt','bracelet','ring','neck'];

/* ---------------- 词条池 ---------------- */
const AFFIXES = [
  {k:'atk',   name:'锋利', unit:'',   roll:()=>rnd(2,6),    desc:v=>`+${v}攻击`},
  {k:'def',   name:'坚固', unit:'',   roll:()=>rnd(1,4),    desc:v=>`+${v}防御`},
  {k:'spd',   name:'疾风', unit:'',   roll:()=>rnd(2,6),    desc:v=>`+${v}速度`},
  {k:'hp',    name:'坚韧', unit:'',   roll:()=>rnd(10,40),  desc:v=>`+${v}HP`},
  {k:'crit',  name:'精准', unit:'%',  roll:()=>rnd(3,10),   desc:v=>`+${v}%暴击`},
  {k:'critd', name:'致命', unit:'%',  roll:()=>rnd(15,50),  desc:v=>`+${v}%暴伤`},
  {k:'combo', name:'连击', unit:'%',  roll:()=>rnd(1,3),    desc:v=>`+${v}%连击`},
  {k:'counter',name:'反击',unit:'%',  roll:()=>rnd(1,3),    desc:v=>`+${v}%反击`},
  {k:'lsPct', name:'吸血', unit:'%',  roll:()=>rnd(1,3),    desc:v=>`+${v}%吸血`},
  {k:'lsFlat',name:'嗜血', unit:'',   roll:()=>rnd(1,4),    desc:v=>`+${v}固吸血`}
];
const AFFIX_CHANCE = { normal:0, good:0.05, fine:0.15, epic:0.40 };

/* ---------------- 主角技能 ---------------- */
const SKILLS = {
  liehuo:   {name:'烈火剑法', cd:5, unlock:1, mp:15, maxLv:5, desc:'单体'},
  banyue:   {name:'半月弯刀', cd:6, unlock:3, mp:28, maxLv:5, desc:'全体'},
  zhiyu:    {name:'治愈术',   cd:6, unlock:5, mp:22, maxLv:5, desc:'回25%HP+宠'},
  du:       {name:'毒术',     cd:4, unlock:6, mp:18, maxLv:5, desc:'中毒3回合'},
  zhanshen: {name:'战神祝福', cd:8, unlock:8, mp:35, maxLv:5, desc:'3回合攻防+30%'}
};
/* ★ 修复：原数组 [0,5,10,20,40] 长度不够，升到 Lv.5 时下标 5 = undefined。
 * 现补齐到 6 项，index = 目标等级，index[targetLv] 是升级花费。
 *   Lv.1→2 花 5 / Lv.2→3 花 10 / Lv.3→4 花 20 / Lv.4→5 花 40 */
const SKILL_UPGRADE_COST = [0, 0, 5, 10, 20, 40];
const POISON_DMG = [0, 20, 30, 40, 50, 60];

/* ---------------- 书页 ---------------- */
const PAGE_PRICE = 300;
const PAGE_SELL = 150;
const PAGE_DROP = { normalMon: 0.03, elite: 0.15, boss: 0.50 };

/* ---------------- 全局常量 ---------------- */
const RESPAWN_MON = 60*1000;
const RESPAWN_BOSS = 180*1000;
const QUEST_POOL_CD = 10*60*1000;
const POTION_PRICE = 50;
const POTION_MP_PRICE = 40;
const AUTO_POTION_THRESHOLD = 0.30;
const RAGE_MAX = 10;
const ELITE_CHANCE = 0.15;
const PAGE_SIZE = { shop:5, bag:4, quest:4, gems:20, bagGem:4 };
const PET_WAREHOUSE_MAX = 10;
const PET_DOWN_MS = 30*1000;
const MP_REGEN_PER_TURN = 2;
const MP_REGEN_PER_KILL = 5;

/* 升级经验公式：lv² × 40 + lv × 100 */
function expNeed(lv){
  return lv * lv * 40 + lv * 100;
}

/* 防御减伤（分段，上限 75%） */
function defenseReduceRate(def){
  if(def <= 0) return 0;
  if(def <= 10)  return def * 0.020;
  if(def <= 50)  return 0.20 + (def - 10) * 0.005;
  if(def <= 150) return 0.40 + (def - 50) * 0.0015;
  if(def <= 300) return 0.55 + (def - 150) * 0.001;
  if(def <= 500) return 0.70 + (def - 300) * 0.00025;
  return 0.75;
}