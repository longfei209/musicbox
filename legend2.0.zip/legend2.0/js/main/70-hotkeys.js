/* ============================================================
 *  main/70-hotkeys.js  —— 全局快捷键
 *  战斗：1攻击 Q烈火 W半月 E治愈 T毒术 R战神 空格怒斩
 *        Z红药 X蓝药 F自动 G逃跑
 *  ESC：优先关弹窗 → 退出战斗 → 返回上一页
 * ============================================================ */

document.addEventListener('keydown', e => {

  /* ================= ESC 统一退出逻辑 ================= */
  if(e.key === 'Escape'){
    e.preventDefault();

    const cfm = $('confirm');
    if(cfm && !cfm.classList.contains('hidden')){
      const no = $('cfmNo');
      if(no) no.click();
      return;
    }

    const res = $('resultModal');
    if(res && !res.classList.contains('hidden')){
      const ok = $('bResultOk');
      if(ok) ok.click();
      else {
        const close = res.querySelector('.modal-close');
        if(close) close.click();
      }
      return;
    }

    const eq = $('equipModal');
    if(eq && !eq.classList.contains('hidden')){
      const close = eq.querySelector('.modal-close');
      if(close) close.click();
      else if(typeof Render !== 'undefined' && Render.closeEquipDetail) Render.closeEquipDetail();
      return;
    }

    const battlePage = $('page-battle');
    if(battlePage && !battlePage.classList.contains('hidden')){
      if(typeof Combat !== 'undefined' && Combat.quit) Combat.quit();
      return;
    }

    if(Nav.stack.length > 1){
      Nav.back();
    }
    return;
  }

  /* ================= 以下快捷键只在战斗中生效 ================= */
  if(!Game.battle) return;
  if($('page-battle').classList.contains('hidden')) return;
  if(e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;

  const k = e.key;
  const kl = k.toLowerCase();

  if(kl === 'f'){ e.preventDefault(); Combat.toggleAuto(); return; }
  if(k === ' ' || k === 'Spacebar'){ e.preventDefault(); Combat.useRage(); return; }
  /* ★ 修复：补上逃跑按钮的快捷键 G */
  if(kl === 'g'){ e.preventDefault(); Combat.flee(); return; }

  if(k === '1'){ e.preventDefault(); Combat.attack(); }
  else if(kl === 'q'){ e.preventDefault(); Combat.useSkill('liehuo'); }
  else if(kl === 'w'){ e.preventDefault(); Combat.useSkill('banyue'); }
  else if(kl === 'e'){ e.preventDefault(); Combat.useSkill('zhiyu'); }
  else if(kl === 't'){ e.preventDefault(); Combat.useSkill('du'); }
  else if(kl === 'r'){ e.preventDefault(); Combat.useSkill('zhanshen'); }
  else if(kl === 'z'){ e.preventDefault(); Combat.potion(); }
  else if(kl === 'x'){ e.preventDefault(); Combat.potionMp(); }
});