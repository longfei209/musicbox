/* ============================================================
 *  60-render-home.js  —— 顶栏 / 主页 / 地图 / 楼层
 *  新增：顶栏「⚡ 恢复中」提示
 * ============================================================ */

const RenderHome = {
  /* ---------------- 顶栏 ---------------- */
  top(){
    const p = Game.player;
    const mHp = playerMaxHp(), mMp = playerMaxMp();
    $('tLv').textContent = p.lv;
    $('tHpBar').style.width = clamp(p.hp/mHp,0,1)*100 + '%';
    $('tHpTxt').textContent = Math.floor(p.hp) + '/' + mHp;
    $('tMpBar').style.width = clamp(p.mp/mMp,0,1)*100 + '%';
    $('tMpTxt').textContent = Math.floor(p.mp) + '/' + mMp;
    const need = expNeed(p.lv);
    $('tExpBar').style.width = clamp(p.exp/need,0,1)*100 + '%';
    $('tExpTxt').textContent = p.exp + '/' + need;

    /* 恢复中提示 */
    this._renderRecoverTip();
  },

  _renderRecoverTip(){
    const lvEl = $('tLv');
    if(!lvEl) return;
    const row = lvEl.parentNode.parentNode;   /* .hud-row */
    if(!row) return;

    let tip = $('tRecover');
    if(!tip){
      tip = document.createElement('span');
      tip.id = 'tRecover';
      tip.className = 'recover-tip';
      row.appendChild(tip);
    }

    const mHp = playerMaxHp(), mMp = playerMaxMp();
    const recovering = !Game.battle && (Game.player.hp < mHp || Game.player.mp < mMp);
    if(recovering){
      tip.textContent = '⚡ 恢复中';
      tip.style.display = '';
    }else{
      tip.style.display = 'none';
    }
  },

  /* ---------------- 主页 ---------------- */
  home(){
    const box = $('homeMain');
    if(Game.ui.areaId == null || Game.ui.floorIdx == null){
      box.innerHTML = `<div class="dim" style="text-align:center;padding:20px;font-size:12px;">点击「地图」选择区域开始冒险</div>`;
      return;
    }
    const ar = AREA_MAP[Game.ui.areaId];
    const fi = Game.ui.floorIdx;
    tickRespawn(ar.id, fi);
    const st = areaState(ar.id).floors[fi];
    if(!st.spawned) spawnFloor(ar.id, fi);
    const def = ar.floors[fi];

    const cleared = st.groups.filter(g=>!g.alive).length;
    const total = st.groups.length;
    const bossDead = !!st.bossDeath;
    const hasNextFloor = fi + 1 < ar.floors.length;

    let html = `<div class="floor-header">
      <span>📍 ${ar.name} · 第${fi+1}层</span>
      <span>已清 ${cleared}/${total} 组</span>
    </div>`;

    /* 怪物组按钮 */
    const aliveGroups = st.groups.map((g,gi)=>({g,gi})).filter(x=>x.g.alive);
    if(aliveGroups.length > 0){
      html += `<div class="groups-row" style="flex-wrap:wrap;" id="groupsRow">`;
      aliveGroups.forEach(({g, gi})=>{
        const nm = g.name && g.name.length > 4 ? g.name.slice(0,4) : (g.name || '怪物');
        html += `<button class="btn group-btn" style="flex:0 0 calc(33.33% - 4px);" onclick="Combat.startGroup(${gi})" data-gi="${gi}">${nm}</button>`;
      });
      html += `</div>`;
    } else {
      html += `<div class="dim" style="text-align:center;font-size:12px;padding:8px;">全部清空，等待复活中…</div>`;
    }

    /* BOSS 卡 */
    const boss = def.boss;
    html += `<div class="boss-block ${bossDead?'dead':''}">
      <div class="boss-name">👹 ${boss.name} ${bossDead?'<span class="dim" style="font-size:11px;">[已击杀]</span>':''}</div>
      <div class="boss-meta">HP${fmt(boss.hp)} 攻${boss.atk} 防${boss.def} 速${boss.spd} 经${boss.exp}</div>
      ${bossDead
        ? '<div class="dim" style="font-size:11px;">等待复活（复活后需重新击杀才能解锁下一层）</div>'
        : '<button class="btn primary" onclick="Combat.startBoss()">挑战 BOSS</button>'}
    </div>`;

    /* 打完 BOSS 且不是最后一层 → "下一层"大按钮 */
    if(bossDead && hasNextFloor){
      html += `<button class="btn primary" style="padding:14px;font-size:15px;margin-top:6px;" onclick="Render._enterFloor(${fi+1})">
        ⬇ 进入第 ${fi+2} 层
      </button>`;
    }

    box.innerHTML = html;
  },

  /* ---------------- 地图选择页 ---------------- */
  areaPage(){
    let html = '';
    AREAS.forEach(ar=>{
      const locked = !ar.unlock && !(Game.flags && Game.flags[ar.id]);
      if(locked) return;
      html += `<button class="btn primary" style="padding:14px;" onclick="Render._pickArea('${ar.id}')">${ar.name}</button>`;
    });
    $('areaBody').innerHTML = html;
  },

  _pickArea(id){
    Game.ui.areaId = id;
    Game.ui.floorIdx = 0;
    const st = areaState(id);
    if(!st.floors[0].spawned) spawnFloor(id, 0);
    Nav.go('floor');
  },

  /* ---------------- 楼层选择页 ---------------- */
  floorPage(){
    if(!Game.ui.areaId) return Nav.back();
    const ar = AREA_MAP[Game.ui.areaId];
    const ast = areaState(ar.id);
    $('floorTitle').textContent = ar.name;
    let html = '';
    ar.floors.forEach((f, i)=>{
      let locked = false, lockMsg = '';
      if(i > 0){
        const prev = ast.floors[i-1];
        if(!prev.bossDeath){
          locked = true;
          lockMsg = `需击杀第${i}层 BOSS`;
        }
      }
      const s = ast.floors[i];
      const bossKilled = !!s.bossDeath;
      html += `<button class="btn ${locked?'':'primary'}" style="padding:14px;" ${locked?'disabled':''} onclick="Render._enterFloor(${i})">
        第${i+1}层 ${bossKilled?'✔':'✘'} <span class="dim" style="font-size:11px;">${locked?'🔒 '+lockMsg:'可进入'}</span>
      </button>`;
    });
    $('floorBody').innerHTML = html;
  },

  _enterFloor(i){
    const ast = areaState(Game.ui.areaId);
    if(i > 0 && !ast.floors[i-1].bossDeath){
      toast(`请先击杀第${i}层 BOSS`);
      return;
    }
    if(!ast.floors[i].spawned) spawnFloor(Game.ui.areaId, i);
    Game.ui.floorIdx = i;
    Quest.onReachFloor(Game.ui.areaId, i);
    Nav.home();
    Save.auto();
    Events.maybeTrigger();
  }
};