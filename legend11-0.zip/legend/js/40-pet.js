/* ============================================================
 *  40-pet.js  —— 宠物系统
 *  规则：
 *    - 宠物战斗中倒下 → 本场永久不再出手（即使倒计时结束）
 *    - 战斗结束 → 立即满血复活，下场战斗可重新上阵
 *    - 战斗外 → 倒计时结束正常复活
 * ============================================================ */

/* ---------------- 上阵上限（按等级） ---------------- */
function petSlotLimit(){
  const lv = Game.player ? Game.player.lv : 1;
  if(lv >= 30) return 4;
  if(lv >= 20) return 3;
  if(lv >= 10) return 2;
  return 1;
}

/* ---------------- 生成宠物 ---------------- */
function makePet(tplKey, quality){
  const t = PET_TEMPLATES[tplKey];
  if(!t) return null;
  const q = quality || 'common';
  const skills = rollPetSkills(q);
  const p = {
    uid: 'p_' + Math.random().toString(36).slice(2,10),
    tpl: tplKey,
    name: t.name,
    avatar: t.avatar,
    quality: q,
    lv: 1,
    exp: 0,
    baseAtk: t.base.atk,
    baseDef: t.base.def,
    baseHp: t.base.hp,
    baseSpd: t.base.spd,
    skills: skills,
    hp: 0,
    downUntil: 0,
    deadInBattle: false,
    skillCd: {}
  };
  p.hp = petStatFor(p).hp;
  return p;
}

/* ---------------- 宠物属性计算 ---------------- */
function petStatFor(p){
  if(!p) return { atk:0, def:0, hp:0, spd:0, pAtk:0, pDef:0, pSpd:0 };
  const q = PET_QUALITY[p.quality] || PET_QUALITY.common;
  const g = 1 + (p.lv - 1) * 0.18;
  const atk = Math.floor(p.baseAtk * q.mult * g);
  const def = Math.floor(p.baseDef * q.mult * g);
  const hp  = Math.floor(p.baseHp  * q.mult * g);
  const spd = Math.floor(p.baseSpd * q.mult * (1 + (p.lv - 1) * 0.08));
  return {
    atk, def, hp, spd,
    pAtk: Math.floor(atk * 0.15),
    pDef: Math.floor(def * 0.15),
    pSpd: Math.floor(spd * 0.15)
  };
}

/* ---------------- 宠物技能状态汇总 ---------------- */
function petSkillStateFor(p){
  const st = {
    crit: 0, ls: 0,
    spdBonus: 0, defBonus: 0, pSpdBonus: 0, pDefBonus: 0,
    heavy: 0, double: 0, ragePet: false,
    group: false, heal: 0, reflect: 0, guard: 0,
    pois: false, pierce: 0, dodge: 0, regen: 0, slow: 0, atkBonus: 0,
    nirvana: false, timestop: false, flame: false
  };
  if(!p || !p.skills || p.skills.length === 0) return st;
  p.skills.forEach(key=>{
    const sk = PET_SKILLS[key];
    if(sk && sk.apply) sk.apply(st);
  });
  return st;
}

/* ---------------- 存活 / 受伤 / 复活 ---------------- */
function petAlive(p){
  if(!p) return false;
  if(p.deadInBattle) return false;
  if(p.downUntil && p.downUntil > Date.now()) return false;
  return true;
}

function petTakeDamage(p, dmg){
  if(!petAlive(p)) return;
  p.hp -= dmg;
  if(p.hp <= 0){
    p.hp = 0;
    if(!Game.battle){
      /* 战斗外死亡：走倒计时 */
      p.downUntil = Date.now() + PET_DOWN_MS;
    }
    /* 战斗内死亡：只标记 deadInBattle，downUntil 由战斗逻辑设置 */
  }
}

/* ---------------- 立即复活（清所有死亡状态） ---------------- */
function revivePetImmediately(p){
  if(!p) return;
  p.downUntil = 0;
  p.deadInBattle = false;
  p.hp = petStatFor(p).hp;
  p.skillCd = {};
}

/* ---------------- 定时复活（每 1.5s 由 68-nav.js 调用） ----------------
 * 战斗进行中：不复活（宠物本场倒下就永久不再出手）
 * 战斗外：倒计时结束正常复活
 * -------------------------------------------------------------- */
function tickPetRespawn(){
  /* 战斗中直接跳过 —— 宠物本场不再复活 */
  if(Game.battle) return false;

  const now = Date.now();
  let changed = false;
  Game.pets.forEach(p=>{
    if(p.downUntil && now >= p.downUntil){
      revivePetImmediately(p);
      changed = true;
    }
  });
  return changed;
}

/* ---------------- 经验 / 升级 ---------------- */
function petAddExp(p, v){
  if(!p) return;
  p.exp += v;
  while(p.exp >= p.lv * 150){
    p.exp -= p.lv * 150;
    p.lv++;
    p.hp = petStatFor(p).hp;
    toast(`${p.name} 升级 Lv.${p.lv}`);
  }
}

/* ---------------- 上阵宠物 ---------------- */
function getActivePetObjects(){
  return Game.activePets
    .map(u => Game.pets.find(p => p.uid === u))
    .filter(p => p && petAlive(p));
}

/* ---------------- 宠物操作 ---------------- */
const Pet = {
  toggle(uid){
    const idx = Game.activePets.indexOf(uid);
    if(idx >= 0){
      Game.activePets.splice(idx, 1);
      toast("已下阵");
    }else{
      if(Game.activePets.length >= petSlotLimit()) return toast("上阵已满");
      const p = Game.pets.find(x=>x.uid === uid);
      if(p && !petAlive(p)){
        const left = Math.ceil((p.downUntil - Date.now())/1000);
        return toast(`复活中（${left}s）`);
      }
      Game.activePets.push(uid);
      toast("已上阵");
    }
    Save.auto();
    Render.petPage(); Render.top();
  },

  release(uid){
    confirmBox("确定放生该宠物？", ()=>{
      const idx = Game.activePets.indexOf(uid);
      if(idx >= 0) Game.activePets.splice(idx, 1);
      Game.pets = Game.pets.filter(p => p.uid !== uid);
      Save.auto();
      Render.petPage(); Render.top();
    });
  },

  tryAdd(pet){
    if(Game.pets.length >= PET_WAREHOUSE_MAX){
      toast("宠物仓库已满");
      return false;
    }
    Game.pets.push(pet);
    const qName = (PET_QUALITY[pet.quality] || PET_QUALITY.common).name;
    if(Game.activePets.length < petSlotLimit()){
      Game.activePets.push(pet.uid);
      toast(`获得 ${pet.name} [${qName}] · 已上阵`);
    }else{
      toast(`获得 ${pet.name} [${qName}] · 已存仓库`);
    }
    return true;
  }
};