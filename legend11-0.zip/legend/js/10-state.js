/* ============================================================
 *  10-state.js  —— Game 状态 + 初始化 + 装备/属性计算
 *  改动：Game.worn 新增 bracelet 槽位
 * ============================================================ */

const Game = {
  player:null, bag:[], worn:null,
  mat:0, pages:0,
  skillLv:{},
  areaState:{}, flags:{ dragonCity:false, niumo:false, ghost:false },
  quest:{ doing:[], avail:[], refreshTs:0 },
  ui:{ areaId:null, floorIdx:null },
  battle:null,
  pets:[], activePets:[],
  gems:[], fragments:{},
  stats:{ kills:0, deaths:0 }
};

function initGame(){
  Game.player = {
    lv:1, exp:0, hp:100, maxHp:100, mp:50, maxMp:50,
    baseAtkMin:10, baseAtkMax:15,
    baseDefMin:5,  baseDefMax:8,
    baseSpd:10,
    gold:100, potion:5, potionMp:3, bagMax:30, rage:0
  };
  Game.bag = [];
  Game.worn = { weapon:null, helmet:null, cloth:null, shoe:null, belt:null, bracelet:null, ring:null, neck:null };
  Game.mat = 0;
  Game.pages = 0;
  Game.skillLv = {};
  Object.keys(SKILLS).forEach(k=>{ Game.skillLv[k] = 1; });
  Game.areaState = {};
  Game.flags = { dragonCity:false, niumo:false, ghost:false };
  Game.quest = { doing:[], avail:[], refreshTs: Date.now() - QUEST_POOL_CD - 1000 };
  Game.ui = { areaId:null, floorIdx:null };
  Game.battle = null;
  Game.pets = [];
  Game.activePets = [];
  Game.gems = [];
  Game.fragments = {};
  Object.keys(GEMS).forEach(k=>{
    Game.fragments[k] = { normal:0, rare:0, legend:0 };
  });
  Game.stats = { kills:0, deaths:0 };
  Quest.refreshPool(true);
}

/* ---------------- 品质 ---------------- */
function rollQuality(boost){
  const r = Math.random();
  const epicC = 0.03 + (boost||0);
  const fineC = 0.15 + (boost||0);
  const goodC = 0.40 + (boost||0)*1.5;
  if(r < epicC) return 'epic';
  if(r < fineC) return 'fine';
  if(r < goodC) return 'good';
  return 'normal';
}

/* ---------------- 装备生成 ---------------- */
function makeEquip(name, quality){
  const base = EQUIP_BASE[name];
  if(!base) return null;
  const q = quality || rollQuality();
  const qc = QUALITY[q];
  const qMin = 1 + qc.rate;
  const atkMin = Math.round(base.atk * qMin);
  const defMin = Math.round(base.def * qMin);
  const atkMax = Math.round(atkMin * 2.2);
  const defMax = Math.round(defMin * 2.0);
  const eq = {
    uid: uid(), name, slot: base.slot, tier: base.tier,
    atkMin, atkMax, defMin, defMax,
    spd: base.spd || 0,
    hp:  base.hp  || 0,
    quality: q,
    refineAtk:0, refineDef:0, refineHp:0, refineTimes:0,
    affix:null, affixVal:0,
    sockets: [null, null, null]
  };
  const chance = AFFIX_CHANCE[q] || 0;
  if(Math.random() < chance){
    const a = pick(AFFIXES);
    const v = a.roll();
    eq.affix = a.k;
    eq.affixVal = v;
  }
  return eq;
}

/* ---------------- 装备区间 ---------------- */
function equipBaseRange(eq){
  if(!eq) return { atkMin:0, atkMax:0, defMin:0, defMax:0, spd:0, hp:0 };
  let atkMin = eq.atkMin, atkMax = eq.atkMax;
  let defMin = eq.defMin, defMax = eq.defMax;
  let spd = eq.spd || 0;
  let hp  = eq.hp  || 0;
  if(eq.affix){
    const v = eq.affixVal || 0;
    switch(eq.affix){
      case 'atk':    atkMax += v; break;
      case 'def':    defMax += v; break;
      case 'spd':    spd += v; break;
      case 'hp':     hp += v; break;
    }
  }
  return { atkMin, atkMax, defMin, defMax, spd, hp };
}

function equipWithRefineRange(eq){
  const b = equipBaseRange(eq);
  if(!eq) return b;
  return {
    atkMin: b.atkMin,
    atkMax: b.atkMax + (eq.refineAtk || 0),
    defMin: b.defMin,
    defMax: b.defMax + (eq.refineDef || 0),
    spd: b.spd,
    hp: b.hp + (eq.refineHp || 0)
  };
}

function equipGemBonus(eq){
  const bonus = { atk:0, def:0, hp:0, spd:0,
                  combo:0, counter:0, lsPct:0, lsFlat:0, crit:0 };
  if(!eq || !eq.sockets) return bonus;
  eq.sockets.forEach(gem=>{
    if(!gem) return;
    const cfg = getGemCfg(gem.key, gem.quality);
    if(!cfg) return;
    bonus[cfg.stat] = (bonus[cfg.stat] || 0) + cfg.value;
  });
  return bonus;
}

function equipFullRange(eq){
  const b = equipWithRefineRange(eq);
  const g = equipGemBonus(eq);
  return {
    atkMin: b.atkMin,
    atkMax: b.atkMax + g.atk,
    defMin: b.defMin,
    defMax: b.defMax + g.def,
    spd: b.spd + g.spd,
    hp:  b.hp + g.hp,
    combo: g.combo,
    counter: g.counter,
    lsPct: g.lsPct,
    lsFlat: g.lsFlat,
    crit: g.crit
  };
}

function equipFullBonus(eq){
  const r = equipFullRange(eq);
  return {
    atk: r.atkMax, def: r.defMax, spd: r.spd, hp: r.hp,
    combo: r.combo, counter: r.counter,
    lsPct: r.lsPct, lsFlat: r.lsFlat, crit: r.crit, critd: 0
  };
}

function equipCompareStat(eq){
  if(!eq) return { atk:0, def:0, spd:0, hp:0, combo:0, counter:0, lsPct:0, lsFlat:0, crit:0, critd:0 };
  const r = equipBaseRange(eq);
  let combo = 0, counter = 0, lsPct = 0, lsFlat = 0, crit = 0, critd = 0;
  if(eq.affix){
    const v = eq.affixVal || 0;
    switch(eq.affix){
      case 'crit':   crit += v; break;
      case 'critd':  critd += v; break;
      case 'combo':  combo += v; break;
      case 'counter':counter += v; break;
      case 'lsPct':  lsPct += v; break;
      case 'lsFlat': lsFlat += v; break;
    }
  }
  return { atk: r.atkMax, def: r.defMax, spd: r.spd, hp: r.hp, combo, counter, lsPct, lsFlat, crit, critd };
}

function equipAffixDesc(eq){
  if(!eq || !eq.affix) return '';
  const a = AFFIXES.find(x=>x.k===eq.affix);
  return a ? a.desc(eq.affixVal) : '';
}

/* ---------------- 玩家属性 ---------------- */
function calcAttr(){
  let atkMin = Game.player.baseAtkMin, atkMax = Game.player.baseAtkMax;
  let defMin = Game.player.baseDefMin, defMax = Game.player.baseDefMax;
  let spd = Game.player.baseSpd, addHp = 0;
  let combo = 0, counter = 0, lsPct = 0, lsFlat = 0;
  let crit = 0.12, critD = 1.3;
  for(const s in Game.worn){
    const e = Game.worn[s]; if(!e) continue;
    const r = equipFullRange(e);
    atkMin += r.atkMin; atkMax += r.atkMax;
    defMin += r.defMin; defMax += r.defMax;
    spd += r.spd; addHp += r.hp;
    combo += r.combo; counter += r.counter;
    lsPct += r.lsPct; lsFlat += r.lsFlat;
    crit += r.crit / 100;
    if(e.affix){
      const v = e.affixVal || 0;
      switch(e.affix){
        case 'crit':   crit += v/100; break;
        case 'critd':  critD += v/100; break;
        case 'combo':  combo += v; break;
        case 'counter':counter += v; break;
        case 'lsPct':  lsPct += v; break;
        case 'lsFlat': lsFlat += v; break;
      }
    }
  }
  /* 套装加成（来自 20-equip-make.js） */
  const sb = getSetBonusTotal(Game.worn);
  atkMin += sb.atkMin; atkMax += sb.atkMax;
  defMin += sb.defMin; defMax += sb.defMax;
  addHp += sb.hp; spd += sb.spd;

  /* 宠物被动 */
  const activePetObjs = getActivePetObjects();
  activePetObjs.forEach(p=>{
    const pst = petStatFor(p);
    atkMin += pst.pAtk||0; atkMax += pst.pAtk||0;
    defMin += pst.pDef||0; defMax += pst.pDef||0;
    spd += pst.pSpd||0;
    const st = petSkillStateFor(p);
    if(st.pSpdBonus) spd = Math.floor(spd * (1 + st.pSpdBonus));
    if(st.pDefBonus){
      defMin = Math.floor(defMin * (1 + st.pDefBonus));
      defMax = Math.floor(defMax * (1 + st.pDefBonus));
    }
  });
  return {
    atkMin, atkMax, defMin, defMax,
    spd, addHp,
    combo: combo/100,
    counter: counter/100,
    lsPct: lsPct/100,
    lsFlat,
    crit, critD
  };
}

/* ---------------- 技能等级 ---------------- */
function getSkillLv(key){
  return (Game.skillLv && Game.skillLv[key]) || 1;
}
function skillDmgMul(key, base){
  const lv = getSkillLv(key);
  return base * (1 + 0.15 * (lv - 1));
}
function skillHealRate(key, base){
  const lv = getSkillLv(key);
  return base * (1 + 0.05 * (lv - 1));
}
function skillBuffMul(key, base){
  const lv = getSkillLv(key);
  return base + 0.02 * (lv - 1);
}
function skillPoisonDmg(){
  const lv = getSkillLv('du');
  return POISON_DMG[lv] || 20;
}

/* ---------------- 常用 ---------------- */
function rollPlayerAtk(){ const a = calcAttr(); return rnd(a.atkMin, a.atkMax); }
function rollPlayerDef(){ const a = calcAttr(); return rnd(a.defMin, a.defMax); }
function playerMaxHp(){ return Game.player.maxHp + calcAttr().addHp; }
function playerMaxMp(){ return Game.player.maxMp; }

/* ---------------- 经验 ---------------- */
function addExp(v){
  const p = Game.player;
  const oldLv = p.lv;
  p.exp += v;
  let leveled = false;
  while(p.exp >= expNeed(p.lv)){
    p.exp -= expNeed(p.lv);
    p.lv++;
    p.baseAtkMin += 3;
    p.baseAtkMax += 4;
    p.baseDefMin += 1;
    p.baseDefMax += 2;
    p.maxHp  += 15;
    p.baseSpd += 1;
    p.maxMp  += 8;
    leveled = true;
  }
  if(leveled){
    p.hp = playerMaxHp(); p.mp = playerMaxMp();
    toast("升级！Lv." + p.lv);
    if(oldLv < 10 && p.lv >= 10) toast("🆕 可携带宠物 2 只");
    if(oldLv < 20 && p.lv >= 20) toast("🆕 可携带宠物 3 只");
    if(oldLv < 30 && p.lv >= 30) toast("🆕 可携带宠物 4 只");
    Save.auto();
  }
  Render.top();
}

/* ---------------- 区域状态 ---------------- */
function areaState(id){
  if(!Game.areaState[id]){
    const def = AREA_MAP[id];
    Game.areaState[id] = {
      floors: def.floors.map(()=>({ groups:[], bossDeath:0, spawned:false }))
    };
  }
  return Game.areaState[id];
}

function spawnGroup(areaId, fi){
  const ar = AREA_MAP[areaId];
  const pool = ar.floors[fi].pool;
  const count = rnd(1,4);
  const members = [];
  let groupName = '';
  for(let i=0;i<count;i++){
    const proto = pick(pool);
    const isElite = Math.random() < ELITE_CHANCE;
    const m = {
      mid: uid(), protoId: proto.id, name: proto.name,
      hp: proto.hp, maxHp: proto.hp,
      atk: proto.atk, def: proto.def, spd: proto.spd,
      exp: proto.exp, gMin: proto.gMin, gMax: proto.gMax,
      behavior: proto.behavior,
      elite: isElite, affixes: [],
      dead: false, deathTs: 0, vamp: 0, pois: 0,
      summonCount: 0, poison: null
    };
    if(i === 0) groupName = proto.name;
    if(isElite){
      m.name = "精英·" + m.name;
      m.hp = Math.floor(m.hp*1.6); m.maxHp = m.hp;
      m.atk = Math.floor(m.atk*1.3);
      m.def = Math.floor(m.def*1.3);
      m.exp = Math.floor(m.exp*1.8);
      m.gMin = Math.floor(m.gMin*2); m.gMax = Math.floor(m.gMax*2);
      const n = rnd(1,2);
      const chosen = [...ELITE_AFFIXES].sort(()=>Math.random()-0.5).slice(0, n);
      chosen.forEach(af=>{ af.apply(m); m.affixes.push(af.k); });
    }
    members.push(m);
  }
  return { gid: uid(), name: groupName, members, alive:true, deathTs:0 };
}

function spawnFloor(areaId, fi){
  const st = areaState(areaId).floors[fi];
  st.groups = [];
  const n = rnd(4, 8);
  for(let g=0; g<n; g++) st.groups.push(spawnGroup(areaId, fi));
  st.spawned = true;
}

function tickRespawn(areaId, fi){
  const st = areaState(areaId).floors[fi];
  const now = Date.now();
  let changed = false;
  st.groups.forEach((g, gi)=>{
    if(!g.alive && g.deathTs && now - g.deathTs >= RESPAWN_MON){
      const ng = spawnGroup(areaId, fi);
      st.groups[gi] = ng;
      changed = true;
    }
  });
  if(st.bossDeath && now - st.bossDeath >= RESPAWN_BOSS) st.bossDeath = 0;
  return changed;
}

function rollDropEquip(areaId, monType){
  const ar = AREA_MAP[areaId];
  if(!ar || !ar.dropTier) return null;
  const dt = ar.dropTier;
  let tier;
  if(monType === 'boss') tier = dt.boss;
  else if(monType === 'elite'){
    const arr = dt.elite;
    tier = Array.isArray(arr) ? pick(arr) : arr;
  } else {
    tier = dt.normal;
  }
  const pool = EQUIP_BY_TIER[tier] || [];
  if(pool.length === 0) return null;
  const name = pick(pool);
  const boost = monType === 'boss' ? 0.15 : (monType === 'elite' ? 0.08 : 0);
  return makeEquip(name, rollQuality(boost));
}