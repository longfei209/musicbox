/* ============================================================
 *  32-combat-ui.js  —— 战斗界面渲染
 *  定义为独立对象 CombatUI，由 68-nav.js 合并进 Combat
 *  优化：DOM diff，避免每 1.5s 定时器重建整棵树打断动画
 *  新增：怪物血条颜色（黄/红/中毒紫）
 *  改动：技能按钮只显示名字（不再显示等级）；
 *        冷却中显示名字 + [剩余回合] 红底标签；
 *        红药/蓝药显示名字 + [数量] 小标签；
 *        战神 buff 持续回合在属性栏提示区显示（原有逻辑）
 * ============================================================ */

const CombatUI = {
  /* ---------------- 战斗界面渲染 ---------------- */
  render(){
    const b = Game.battle; if(!b) return;
    const ar = AREA_MAP[Game.ui.areaId];
    const fi = Game.ui.floorIdx;
    $('bLoc').textContent = b.kind === 'boss'
      ? `${ar.name} 第${fi+1}层 · BOSS`
      : `${ar.name} 第${fi+1}层 · ${b.group ? b.group.name : ''}`;

    this._renderLeft(b);
    this._renderMonsters(b);
    this._renderSkillBtns(b);
    this._renderTip(b);
  },

  /* ---------------- 怪物血条状态类 ----------------
   * 中毒 > 残血 > 中血 > 正常
   * ------------------------------------------------ */
  _monsterHpBarClass(m){
    if(m.poison && m.poison.turns > 0) return 'poisoned';
    const pct = m.hp / m.maxHp;
    if(pct < 0.20) return 'hp-low';
    if(pct < 0.50) return 'hp-mid';
    return '';
  },

  /* ---------------- 左侧玩家 + 宠物 ---------------- */
  _renderLeft(b){
    const a = calcAttr();
    const mHp = playerMaxHp(), mMp = playerMaxMp();
    const hpP = clamp(Game.player.hp/mHp,0,1)*100;
    const mpP = clamp(Game.player.mp/mMp,0,1)*100;
    const rage = Game.player.rage || 0;
    const zsActive = b.buff.zhanshen > 0;

    /* 首次进入战斗：完整建结构 */
    let pBox = $('pBox');
    if(!pBox){
      const activePetObjs = Game.activePets
        .map(u => Game.pets.find(p=>p.uid === u))
        .filter(Boolean);
      let petHtml = '';
      activePetObjs.forEach(p=>{ petHtml += this._petBoxHtml(p); });

      $('bLeft').innerHTML = `
        <div class="unit-box p-box ${zsActive?'zs-active':''}" id="pBox">
          <div class="u-emoji">🧙</div>
          <div class="u-lv">Lv.${Game.player.lv}</div>
          <div class="u-bar hp">
            <i style="width:${hpP}%"></i>
            <span class="u-num">${Math.floor(Game.player.hp)}</span>
          </div>
          <div class="u-bar mp">
            <i style="width:${mpP}%"></i>
            <span class="u-num">${Math.floor(Game.player.mp)}</span>
          </div>
        </div>
        <div class="rage-line">怒 ${rage}/${RAGE_MAX}</div>
        <div id="petList" style="display:flex;flex-direction:column;gap:6px;align-items:center;">${petHtml}</div>
      `;
      return;
    }

    /* 已存在：只更新数据 */
    const lvEl = pBox.querySelector('.u-lv');
    const wantLv = 'Lv.' + Game.player.lv;
    if(lvEl.textContent !== wantLv) lvEl.textContent = wantLv;

    const hpBar = pBox.querySelector('.u-bar.hp');
    hpBar.querySelector('i').style.width = hpP + '%';
    hpBar.querySelector('.u-num').textContent = Math.floor(Game.player.hp);

    const mpBar = pBox.querySelector('.u-bar.mp');
    mpBar.querySelector('i').style.width = mpP + '%';
    mpBar.querySelector('.u-num').textContent = Math.floor(Game.player.mp);

    if(zsActive) pBox.classList.add('zs-active');
    else pBox.classList.remove('zs-active');

    const rageEl = $('bLeft').querySelector('.rage-line');
    if(rageEl){
      const wantRage = `怒 ${rage}/${RAGE_MAX}`;
      if(rageEl.textContent !== wantRage) rageEl.textContent = wantRage;
    }

    this._renderPets();
  },

  /* 宠物方块 HTML 字符串 */
  _petBoxHtml(p){
    const maxHp = petStatFor(p).hp;
    const hpPct = clamp(p.hp/maxHp, 0, 1) * 100;
    const isDown = p.deadInBattle || !petAlive(p);
    if(isDown){
      let txt = p.deadInBattle ? '倒下' : (Math.ceil((p.downUntil - Date.now())/1000) + 's');
      return `<div class="unit-box pet-box-single down" id="pet-${p.uid}">
        <div class="u-emoji">${p.avatar}</div>
        <div class="u-lv">${txt}</div>
        <div class="u-bar hp pet-hp"><i style="width:0%"></i></div>
      </div>`;
    }
    return `<div class="unit-box pet-box-single" id="pet-${p.uid}">
      <div class="u-emoji">${p.avatar}</div>
      <div class="u-lv">Lv.${p.lv}</div>
      <div class="u-bar hp pet-hp">
        <i style="width:${hpPct}%"></i>
        <span class="u-num">${Math.floor(p.hp)}</span>
      </div>
    </div>`;
  },

  /* 宠物列表 diff */
  _renderPets(){
    const petList = $('petList');
    if(!petList) return;
    const activePetObjs = Game.activePets
      .map(u => Game.pets.find(p=>p.uid === u))
      .filter(Boolean);

    /* 删除不在列表的 */
    const wantIds = new Set(activePetObjs.map(p => 'pet-' + p.uid));
    [...petList.children].forEach(el=>{
      if(!wantIds.has(el.id)) el.remove();
    });

    /* 更新或新建 */
    activePetObjs.forEach(p=>{
      const exist = document.getElementById('pet-' + p.uid);
      if(exist){
        this._updatePetBox(exist, p);
      }else{
        const wrap = document.createElement('div');
        wrap.innerHTML = this._petBoxHtml(p);
        petList.appendChild(wrap.firstElementChild);
      }
    });
  },

  _updatePetBox(el, p){
    const maxHp = petStatFor(p).hp;
    const hpPct = clamp(p.hp/maxHp, 0, 1) * 100;
    const isDown = p.deadInBattle || !petAlive(p);
    const lvEl = el.querySelector('.u-lv');
    const hpBar = el.querySelector('.u-bar.hp');

    if(isDown){
      el.classList.add('down');
      let txt = p.deadInBattle ? '倒下' : (Math.ceil((p.downUntil - Date.now())/1000) + 's');
      if(lvEl.textContent !== txt) lvEl.textContent = txt;
      const i = hpBar.querySelector('i');
      if(i) i.style.width = '0%';
      const num = hpBar.querySelector('.u-num');
      if(num) num.remove();
    }else{
      el.classList.remove('down');
      const wantLv = 'Lv.' + p.lv;
      if(lvEl.textContent !== wantLv) lvEl.textContent = wantLv;
      let i = hpBar.querySelector('i');
      let num = hpBar.querySelector('.u-num');
      if(!num){
        num = document.createElement('span');
        num.className = 'u-num';
        hpBar.appendChild(num);
      }
      i.style.width = hpPct + '%';
      num.textContent = Math.floor(p.hp);
    }
  },

  /* ---------------- 右侧怪物网格 ---------------- */
  _renderMonsters(b){
    const grid = $('bGrid');

    /* 删除不在列表的 */
    const wantIds = new Set(b.monsters.map(m => 'mon-' + m.mid));
    [...grid.children].forEach(el=>{
      if(!wantIds.has(el.id)) el.remove();
    });

    /* 更新或新建 */
    b.monsters.forEach((m, i)=>{
      const exist = document.getElementById('mon-' + m.mid);
      if(exist){
        this._updateMonsterCard(exist, m, i);
      }else{
        grid.appendChild(this._buildMonsterCard(m, i));
      }
    });
  },

  _buildMonsterCard(m, i){
    const card = document.createElement('div');
    card.className = 'unit-box mon-unit clickable';
    if(m.dead) card.classList.add('dead');
    if(m.elite) card.classList.add('elite');
    if(m.isBoss) card.classList.add('boss');
    card.id = 'mon-' + m.mid;

    const hP = clamp(m.hp/m.maxHp, 0, 1) * 100;
    const hpCls = this._monsterHpBarClass(m);
    const tag = m.isBoss ? '👹' : (m.elite ? '★' : '🐾');
    const shortName = m.name.length > 4 ? m.name.slice(0,4) : m.name;
    const poisonTag = (m.poison && m.poison.turns > 0) ? '<span style="color:#c8a;font-size:9px;">☠</span>' : '';

    card.innerHTML = `
      <div class="u-emoji">${tag}</div>
      <div class="u-name">${shortName}${poisonTag}</div>
      <div class="u-bar hp ${hpCls}">
        <i style="width:${hP}%"></i>
        <span class="u-num">${Math.max(0,Math.floor(m.hp))}</span>
      </div>
    `;
    card.onclick = () => this.clickMonster(i);
    return card;
  },

  _updateMonsterCard(card, m, i){
    if(m.dead) card.classList.add('dead');
    else card.classList.remove('dead');

    const hpBar = card.querySelector('.u-bar.hp');
    const hP = clamp(m.hp/m.maxHp, 0, 1) * 100;
    hpBar.querySelector('i').style.width = hP + '%';
    hpBar.querySelector('.u-num').textContent = Math.max(0, Math.floor(m.hp));

    /* 血条状态颜色 */
    const wantCls = this._monsterHpBarClass(m);
    ['hp-low','hp-mid','poisoned'].forEach(c => hpBar.classList.remove(c));
    if(wantCls) hpBar.classList.add(wantCls);

    /* 中毒标记 */
    const nameEl = card.querySelector('.u-name');
    const shortName = m.name.length > 4 ? m.name.slice(0,4) : m.name;
    const poisonTag = (m.poison && m.poison.turns > 0) ? '<span style="color:#c8a;font-size:9px;">☠</span>' : '';
    const wantHtml = shortName + poisonTag;
    if(nameEl.innerHTML !== wantHtml) nameEl.innerHTML = wantHtml;

    /* 重新绑 onclick（索引稳定，安全） */
    card.onclick = () => this.clickMonster(i);
  },

  /* ---------------- 技能 / 药水 / 自动按钮 ---------------- */
  _renderSkillBtns(b){
    this._refreshSkillBtn('bSkill1', 'liehuo');
    this._refreshSkillBtn('bSkill2', 'banyue');
    this._refreshSkillBtn('bSkill3', 'zhiyu');
    this._refreshSkillBtn('bSkill4', 'du');
    this._refreshSkillBtn('bSkill5', 'zhanshen');
    $('bRageBtn').disabled = (Game.player.rage || 0) < RAGE_MAX;

    /* 红药：名字 + [数量] */
    const potBtn = $('bPotionBtn');
    if(potBtn){
      const lbl = potBtn.querySelector('.btn-label');
      if(lbl){
        const want = `红药<span class="cd-tag">${Game.player.potion}</span>`;
        if(lbl.innerHTML !== want) lbl.innerHTML = want;
      }
    }
    /* 蓝药：名字 + [数量] */
    const mpPotBtn = $('bPotionMpBtn');
    if(mpPotBtn){
      const lbl = mpPotBtn.querySelector('.btn-label');
      if(lbl){
        const want = `蓝药<span class="cd-tag">${Game.player.potionMp}</span>`;
        if(lbl.innerHTML !== want) lbl.innerHTML = want;
      }
    }

    /* 自动按钮：文字切换 */
    const autoBtn = $('bAutoBtn');
    if(autoBtn){
      const lbl = autoBtn.querySelector('.btn-label');
      if(lbl){
        const want = b.auto ? '停止' : '自动';
        if(lbl.textContent !== want) lbl.textContent = want;
      }
    }
  },

  /* ---------------- 技能按钮刷新 ----------------
   * 未解锁：只显示名字（无等级），按钮禁用
   * 冷却中：名字 + [剩余回合] 红底标签，按钮禁用
   * 可用：  只显示名字，按钮可用
   * ------------------------------------------------ */
  _refreshSkillBtn(id, key){
    const sk = SKILLS[key];
    const btn = $(id);
    if(!btn) return;
    const b = Game.battle;
    const shortName = sk.name.slice(0,2);
    const lbl = btn.querySelector('.btn-label');
    if(!lbl) return;

    const cd = (b && b.cds) ? (b.cds[key] || 0) : 0;

    let wantHtml, wantDisabled;
    if(Game.player.lv < sk.unlock){
      /* 未解锁 */
      wantHtml = shortName;
      wantDisabled = true;
    }else if(cd > 0){
      /* 冷却中 */
      wantHtml = `${shortName}<span class="cd-tag">${cd}</span>`;
      wantDisabled = true;
    }else{
      /* 可用 */
      wantHtml = shortName;
      wantDisabled = false;
    }

    if(lbl.innerHTML !== wantHtml) lbl.innerHTML = wantHtml;
    if(btn.disabled !== wantDisabled) btn.disabled = wantDisabled;
  },

  /* ---------------- 属性栏提示 ----------------
   * 战神 buff 持续回合在这里显示：🛡️战神祝福(N)
   * ------------------------------------------------ */
  _renderTip(b){
    const a = calcAttr();
    const rage = Game.player.rage || 0;
    const zsActive = b.buff.zhanshen > 0;
    const tipEl = $('bTip');
    if(!tipEl) return;

    let want;
    if(zsActive){
      const zsAtkMin = Math.floor(a.atkMin * 1.3);
      const zsAtkMax = Math.floor(a.atkMax * 1.3);
      const zsDefMin = Math.floor(a.defMin * 1.3);
      const zsDefMax = Math.floor(a.defMax * 1.3);
      want = `怒 ${rage}/${RAGE_MAX} · 🛡️战神祝福(${b.buff.zhanshen}) 攻 ${zsAtkMin}-${zsAtkMax} 防 ${zsDefMin}-${zsDefMax}`;
      tipEl.classList.add('zs-tip');
    }else{
      tipEl.classList.remove('zs-tip');
      if(b.pendingSkill) want = `点击怪物释放 ${SKILLS[b.pendingSkill].name}`;
      else if(b.auto) want = '自动战斗中…';
      else want = `点击怪物攻击 · 怒 ${rage}/${RAGE_MAX} · 攻 ${a.atkMin}-${a.atkMax} 防 ${a.defMin}-${a.defMax}`;
    }
    if(tipEl.textContent !== want) tipEl.textContent = want;
  },

  /* ---------------- 飘字 ---------------- */
  _floatMon(m, text, cls){
    const el = document.getElementById('mon-' + m.mid);
    floatText(el, text, FC[cls] || FC.normal);
  },
  _floatPlayer(text, cls){
    const el = $('pBox') || $('bLeft');
    floatText(el, text, FC[cls] || FC.normal);
  },
  _floatPet(p, text, cls){
    const el = document.getElementById('pet-' + p.uid) || $('bLeft');
    floatText(el, text, FC[cls] || FC.normal);
  }
};