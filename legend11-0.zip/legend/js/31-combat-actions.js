/* ============================================================
 *  31-combat-actions.js  —— 战斗主体逻辑
 *  改动：
 *    - 击杀时宠物经验累计到 loot.petExp（不再直接加）
 *    - 结算弹窗点「确定」时才把 petExp 发给上阵宠物
 *    - end() 中活着的宠物不再满血，保留当前 HP 由 tickRecover 逐步恢复
 *    - 复活倒计时到了立即复活满血（跟之前一致）
 * ============================================================ */

const AUTO_PRIORITY = [
  { name:'红药', cond:(b,mHp)=>Game.player.potion>0 && Game.player.hp/mHp<AUTO_POTION_THRESHOLD, act:function(){this.potion();} },
  { name:'蓝药', cond:(b,mHp,mMp)=>Game.player.potionMp>0 && Game.player.mp/mMp<0.2, act:function(){this.potionMp();} },
  { name:'怒斩', cond:()=>(Game.player.rage||0)>=RAGE_MAX, act:function(){this.useRage();} },
  { name:'半月', cond:(b)=>Game.player.lv>=3 && !b.cds.banyue && b.monsters.filter(m=>!m.dead).length>=2 && Game.player.mp>=SKILLS.banyue.mp, act:function(){this.useSkill('banyue');} },
  { name:'毒术', cond:(b)=>Game.player.lv>=6 && !b.cds.du && Game.player.mp>=SKILLS.du.mp, act:function(){this._autoUseTargetSkill('du');} },
  { name:'治愈', cond:(b,mHp)=>Game.player.lv>=5 && !b.cds.zhiyu && Game.player.hp/mHp<0.5 && Game.player.mp>=SKILLS.zhiyu.mp, act:function(){this.useSkill('zhiyu');} },
  { name:'战神', cond:(b)=>Game.player.lv>=8 && !b.cds.zhanshen && b.buff.zhanshen===0 && Game.player.mp>=SKILLS.zhanshen.mp, act:function(){this.useSkill('zhanshen');} },
  { name:'烈火', cond:(b)=>Game.player.lv>=1 && !b.cds.liehuo && Game.player.mp>=SKILLS.liehuo.mp, act:function(){this._autoUseTargetSkill('liehuo');} },
  { name:'普攻', cond:()=>true, act:function(){this.attack();} }
];

const CombatActions = {
  /* ================= 开始战斗 ================= */
  startGroup(gi){
    const st = areaState(Game.ui.areaId).floors[Game.ui.floorIdx];
    const group = st.groups[gi];
    if(!group || !group.alive) return toast("该组已清空");
    if(group.members.every(m=>m.dead)) return toast("该组已清空");
    group.members.forEach(m=>{ m.summonCount = 0; m.poison = null; m.slow = null; });
    Game.battle = {
      kind:'group', gi, group,
      monsters: group.members,
      auto:false, pendingSkill:null, roundCount:0,
      buff:{ zhanshen:0 }, cds:{},
      lastTarget: null, resolving: false,
      timestopUsed: false, nirvanaUsed: false, _timestopActive: false,
      loot: newBattleLoot()
    };
    Game.activePets.forEach(u=>{
      const p = Game.pets.find(x=>x.uid === u);
      if(p && petAlive(p)){
        /* 进战斗时，活着的宠物补满 HP（相当于"满状态出战"） */
        p.hp = petStatFor(p).hp;
        p.skillCd = {};
        p.deadInBattle = false;
      }
    });
    Nav.go('battle');
  },

  startBoss(){
    const ar = AREA_MAP[Game.ui.areaId];
    const fi = Game.ui.floorIdx;
    const st = areaState(Game.ui.areaId).floors[fi];
    if(st.bossDeath) return toast("BOSS 未复活");
    const def = ar.floors[fi].boss;
    const boss = {
      mid: uid(), protoId: def.id, name: def.name,
      hp: def.hp, maxHp: def.hp,
      atk: def.atk, def: def.def, spd: def.spd,
      exp: def.exp, gMin: def.gMin, gMax: def.gMax,
      behavior:'normal', elite:false, affixes:[],
      dead:false, deathTs:0, vamp:0, pois:0, summonCount:0, poison:null, slow:null,
      isBoss:true,
      dropEquip: def.dropEquip || null,
      unlockDragon: def.unlockDragon || false,
      unlockNiumo: def.unlockNiumo || false,
      unlockGhost: def.unlockGhost || false
    };
    const guards = _makeBossGuards(def);
    Game.battle = {
      kind:'boss', monsters:[boss, ...guards], boss, group:null,
      auto:false, pendingSkill:null, roundCount:0,
      buff:{ zhanshen:0 }, cds:{},
      lastTarget: null, resolving: false,
      timestopUsed: false, nirvanaUsed: false, _timestopActive: false,
      loot: newBattleLoot()
    };
    Game.activePets.forEach(u=>{
      const p = Game.pets.find(x=>x.uid === u);
      if(p && petAlive(p)){
        p.hp = petStatFor(p).hp;
        p.skillCd = {};
        p.deadInBattle = false;
      }
    });
    Nav.go('battle');
  },

  /* ================= 玩家操作 ================= */
  attack(){
    const b = Game.battle; if(!b || b.pendingSkill || b.resolving) return;
    const alive = b.monsters.filter(m=>!m.dead);
    if(alive.length === 0) return;
    let target = null;
    if(b.lastTarget) target = b.monsters.find(m => m.mid === b.lastTarget && !m.dead) || null;
    if(!target){ alive.sort((a,b)=>a.hp - b.hp); target = alive[0]; }
    b.lastTarget = target.mid;
    this._resolveRound({ type:'attack', target });
  },

  clickMonster(i){
    const b = Game.battle; if(!b || b.resolving) return;
    const m = b.monsters[i];
    if(!m || m.dead) return;
    if(b.pendingSkill){
      const skKey = b.pendingSkill;
      b.pendingSkill = null;
      b.lastTarget = m.mid;
      this._resolveRound({ type:'skill', skill: skKey, target: m });
    }else{
      b.lastTarget = m.mid;
      this._resolveRound({ type:'attack', target: m });
    }
  },

  useSkill(key){
    const b = Game.battle; if(!b || b.resolving) return;
    const sk = SKILLS[key]; if(!sk) return;
    if(Game.player.lv < sk.unlock) return toast(`需 Lv.${sk.unlock}`);
    if(b.cds && b.cds[key] > 0) return toast("冷却中");
    if(Game.player.mp < sk.mp) return toast("蓝量不足");

    if(key === 'liehuo' || key === 'du'){
      if(!b.lastTarget){ b.pendingSkill = key; this.render(); return; }
      let target = b.monsters.find(m => m.mid === b.lastTarget && !m.dead);
      if(!target){ const alive = b.monsters.filter(m => !m.dead); target = alive[0]; }
      if(!target) return;
      b.lastTarget = target.mid;
      this._resolveRound({ type:'skill', skill: key, target });
      return;
    }
    this._resolveRound({ type:'skill', skill: key, target: null });
  },

  useRage(){
    const b = Game.battle; if(!b || b.resolving) return;
    if((Game.player.rage||0) < RAGE_MAX) return toast("怒气不足");
    const alive = b.monsters.filter(m=>!m.dead);
    if(alive.length === 0) return;
    let target = null;
    if(b.lastTarget) target = b.monsters.find(m => m.mid === b.lastTarget && !m.dead) || null;
    if(!target){ alive.sort((a,b)=>a.hp-b.hp); target = alive[0]; }
    b.lastTarget = target.mid;
    this._resolveRound({ type:'rage', target });
  },

  potion(){
    const b = Game.battle; if(!b || b.resolving) return;
    if(Game.player.potion <= 0) return toast("没有红药");
    Game.player.potion--;
    const heal = Math.floor(playerMaxHp() * 0.35);
    Game.player.hp = Math.min(playerMaxHp(), Game.player.hp + heal);
    this._floatPlayer(`+${heal}`, 'heal');
    _healPlayerAnim();
    Render.top();
    this._monsterPhaseOnly();
  },

  potionMp(){
    const b = Game.battle; if(!b || b.resolving) return;
    if(Game.player.potionMp <= 0) return toast("没有蓝药");
    Game.player.potionMp--;
    const heal = Math.floor(playerMaxMp() * 0.30);
    Game.player.mp = Math.min(playerMaxMp(), Game.player.mp + heal);
    this._floatPlayer(`+${heal}MP`, 'heal');
    Render.top();
    this._monsterPhaseOnly();
  },

  flee(){
    const b = Game.battle; if(!b || b.resolving) return;
    if(Math.random() < 0.45){
      toast('逃跑成功');
      this.stopAuto();
      setTimeout(()=>this.end(), 300);
    }else{
      toast('逃跑失败');
      this._monsterPhaseOnly();
    }
  },

  /* ================= 自动战斗 ================= */
  toggleAuto(){
    const b = Game.battle; if(!b) return;
    b.auto = !b.auto;
    this.render();
    if(b.auto) this._autoTick();
  },

  _autoUseTargetSkill(key){
    const b = Game.battle; if(!b) return;
    const alive = b.monsters.filter(m => !m.dead);
    if(alive.length === 0) return;
    let target = null;
    if(b.lastTarget){
      target = b.monsters.find(m => m.mid === b.lastTarget && !m.dead) || null;
    }
    if(!target){
      alive.sort((a, b) => a.hp - b.hp);
      target = alive[0];
    }
    if(target){
      b.lastTarget = target.mid;
      this._resolveRound({ type:'skill', skill: key, target });
    }else{
      this.attack();
    }
  },

  _autoTick(){
    const b = Game.battle; if(!b || !b.auto) return;
    clearTimeout(b._timer);
    b._timer = setTimeout(()=>{
      const cur = Game.battle;
      if(!cur || !cur.auto) return;
      if(cur.resolving){ this._autoTick(); return; }
      const alive = cur.monsters.filter(m => !m.dead);
      if(alive.length === 0) return;
      const mHp = playerMaxHp();
      const mMp = playerMaxMp();
      for(const rule of AUTO_PRIORITY){
        if(rule.cond(cur, mHp, mMp)){
          rule.act.call(this);
          break;
        }
      }
      if(Game.battle && Game.battle.auto) this._autoTick();
    }, 460);
  },

  stopAuto(){
    const b = Game.battle;
    if(b){ b.auto = false; clearTimeout(b._timer); }
  },

  /* ================= 涅槃 ================= */
  _tryNirvana(){
    const b = Game.battle;
    if(!b || b.nirvanaUsed) return false;
    const alivePets = getActivePetObjects().filter(p => !p.deadInBattle);
    const nirvanaPet = alivePets.find(p => petSkillStateFor(p).nirvana);
    if(!nirvanaPet) return false;
    b.nirvanaUsed = true;
    Game.player.hp = Math.max(1, Math.floor(playerMaxHp() * 0.10));
    const before = nirvanaPet.hp;
    nirvanaPet.hp = Math.max(1, Math.floor(before / 2));
    this._floatPlayer('涅槃', 'heal');
    this._floatPet(nirvanaPet, `-${before - nirvanaPet.hp}`, 'reflect');
    toast(`🔥 ${nirvanaPet.name} 涅槃！替主人挡下致命伤`);
    _healPlayerAnim();
    Render.top();
    return true;
  },

  /* ================= 焚天追加伤害 ================= */
  _applyFlame(target){
    const b = Game.battle;
    if(!b || !target || target.dead) return;
    const pets = getActivePetObjects().filter(p => !p.deadInBattle);
    pets.forEach(p => {
      if(target.dead) return;
      const ps = petSkillStateFor(p);
      if(!ps.flame) return;
      const pst = petStatFor(p);
      const dmg = calcDamage(pst.atk * 0.4, target.def);
      target.hp -= dmg;
      _hitMonsterAnim(target, false);
      this._floatMon(target, `🔥焚天-${dmg}`, 'crit');
      if(target.hp <= 0 && !target.dead) this._killMonster(target);
    });
  },

  /* ================= 回合结算 ================= */
  async _resolveRound(action){
    const b = Game.battle; if(!b || b.resolving) return;
    b.resolving = true;
    const battleRef = b;
    try {
      if(!b.cds) b.cds = {};
      b.roundCount++;

      const pa = calcAttr();
      let atkMul = 1, defMul = 1;
      if(b.buff.zhanshen > 0){
        atkMul = skillBuffMul('zhanshen', 1.3);
        defMul = skillBuffMul('zhanshen', 1.3);
      }

      const units = [];
      units.push({ side:'me', spd: pa.spd });
      const activePetObjs = getActivePetObjects();
      activePetObjs.forEach(p=>{
        if(p.deadInBattle) return;
        const pst = petStatFor(p);
        const ps = petSkillStateFor(p);
        const spdBonus = ps.spdBonus || 0;
        units.push({ side:'pet', spd: Math.floor(pst.spd * (1 + spdBonus)), pet: p });
      });
      b.monsters.forEach(m=>{
        if(m.dead) return;
        let spd = m.spd;
        if(m.slow && m.slow.turns > 0) spd = Math.floor(spd * (1 - m.slow.amount));
        units.push({ side:'mon', spd, m });
      });
      units.sort((a,b)=>b.spd - a.spd);

      if(b.roundCount === 1 && !b.timestopUsed){
        const hasTimestop = activePetObjs.some(p => {
          if(p.deadInBattle) return false;
          return petSkillStateFor(p).timestop;
        });
        if(hasTimestop){
          b.timestopUsed = true;
          b._timestopActive = true;
          toast('⏳ 时停！怪物本回合无法行动');
        }
      }

      const isAuto = b.auto;

      for(const u of units){
        if(Game.battle !== battleRef) return;
        if(u.side === 'mon' && b._timestopActive) continue;
        if(u.side === 'me') await this._doPlayerActionAnimated(action, atkMul, isAuto);
        else if(u.side === 'pet') await this._doPetActionAnimated(u.pet, isAuto);
        else {
          if(u.m.dead) continue;
          await this._doMonsterActionAnimated(u.m, defMul, isAuto);
        }
        if(Game.battle !== battleRef) return;
        if(Game.player.hp <= 0){
          if(!this._tryNirvana()) break;
        }
        if(b.monsters.every(x=>x.dead)) break;
      }
      b._timestopActive = false;

      if(Game.battle !== battleRef) return;
      if(Game.player.hp <= 0){ this._onPlayerDead(); return; }
      if(b.monsters.every(x=>x.dead)){ this._onBattleClear(); return; }

      this._tickPoison();
      if(Game.battle !== battleRef) return;
      if(Game.player.hp <= 0){
        if(!this._tryNirvana()){ this._onPlayerDead(); return; }
      }
      if(b.monsters.every(x=>x.dead)){ this._onBattleClear(); return; }

      activePetObjs.forEach(p=>{
        if(p.deadInBattle) return;
        const ps = petSkillStateFor(p);
        if(ps.regen){
          const heal = Math.floor(playerMaxHp() * ps.regen);
          if(heal > 0 && Game.player.hp < playerMaxHp()){
            Game.player.hp = Math.min(playerMaxHp(), Game.player.hp + heal);
            this._floatPlayer(`+${heal}`, 'heal');
          }
        }
      });

      Game.player.mp = Math.min(playerMaxMp(), Game.player.mp + MP_REGEN_PER_TURN);
      if(b.buff.zhanshen > 0) b.buff.zhanshen--;
      for(const k in b.cds){ if(b.cds[k] > 0) b.cds[k]--; }
      b.monsters.forEach(m=>{
        if(m.slow && m.slow.turns > 0){
          m.slow.turns--;
          if(m.slow.turns <= 0) m.slow = null;
        }
      });
      Game.activePets.forEach(u=>{
        const p = Game.pets.find(x=>x.uid === u);
        if(p && p.skillCd){ for(const k in p.skillCd){ if(p.skillCd[k] > 0) p.skillCd[k]--; } }
      });

      this.render();
      Render.top();
      Save.auto();
    } finally {
      if(Game.battle === battleRef) battleRef.resolving = false;
    }
  },

  async _monsterPhaseOnly(){
    const b = Game.battle; if(!b || b.resolving) return;
    b.resolving = true;
    const battleRef = b;
    try {
      const defMul = b.buff.zhanshen > 0 ? skillBuffMul('zhanshen', 1.3) : 1.0;
      const isAuto = b.auto;
      const order = b.monsters.filter(m=>!m.dead).sort((a,b)=>b.spd - a.spd);
      for(const m of order){
        if(Game.battle !== battleRef) return;
        if(m.dead) continue;
        await this._doMonsterActionAnimated(m, defMul, isAuto);
        if(Game.battle !== battleRef) return;
        if(Game.player.hp <= 0){
          if(!this._tryNirvana()) break;
        }
      }
      if(Game.battle !== battleRef) return;
      if(Game.player.hp <= 0){ this._onPlayerDead(); return; }
      this._tickPoison();
      if(Game.battle !== battleRef) return;
      if(Game.player.hp <= 0){
        if(!this._tryNirvana()){ this._onPlayerDead(); return; }
      }
      if(b.monsters.every(x=>x.dead)){ this._onBattleClear(); return; }
      for(const k in b.cds){ if(b.cds[k] > 0) b.cds[k]--; }
      if(b.buff.zhanshen > 0) b.buff.zhanshen--;
      b.monsters.forEach(m=>{
        if(m.slow && m.slow.turns > 0){
          m.slow.turns--;
          if(m.slow.turns <= 0) m.slow = null;
        }
      });
      Game.activePets.forEach(u=>{
        const p = Game.pets.find(x=>x.uid === u);
        if(p && p.skillCd){ for(const k in p.skillCd){ if(p.skillCd[k] > 0) p.skillCd[k]--; } }
      });
      Game.player.mp = Math.min(playerMaxMp(), Game.player.mp + MP_REGEN_PER_TURN);
      this.render();
      Render.top();
      Save.auto();
    } finally {
      if(Game.battle === battleRef) battleRef.resolving = false;
    }
  },

  /* ================= 中毒结算 ================= */
  _tickPoison(){
    const b = Game.battle; if(!b) return;
    b.monsters.forEach(m=>{
      if(m.dead || !m.poison || m.poison.turns <= 0) return;
      const dmg = m.poison.dmg;
      m.hp -= dmg;
      this._floatMon(m, `☠-${dmg}`, 'poison');
      m.poison.turns--;
      if(m.poison.turns <= 0) m.poison = null;
      if(m.hp <= 0 && !m.dead) this._killMonster(m);
    });
  },

  /* ================= 玩家行动 ================= */
  async _doPlayerActionAnimated(action, atkMul, isAuto){
    const battleRef = Game.battle; if(!battleRef) return;
    const playerEl = $('pBox');
    let targetM = action.target;
    if(!targetM || targetM.dead){
      const alive = battleRef.monsters.filter(m=>!m.dead);
      targetM = alive[0] || null;
    }
    const targetEl = targetM ? document.getElementById('mon-' + targetM.mid) : null;

    if(!isAuto && playerEl && targetEl){
      await _chargeTo(playerEl, targetEl, 260);
      if(Game.battle !== battleRef) return;
      this._doPlayerAction(action, atkMul);
      _returnFromCharge(playerEl, 220);
      await _sleep(240);
    }else{
      this._doPlayerAction(action, atkMul);
    }
  },

  _doPlayerAction(action, atkMul){
    const b = Game.battle; if(!b) return;
    const a = calcAttr();

    if(action.type === 'attack'){
      const t = action.target;
      if(!t || t.dead) return;
      const baseAtk = rnd(a.atkMin, a.atkMax) * atkMul;
      this._playerHit(t, baseAtk);
      this._applyFlame(t);
      if(Math.random() < a.combo && !t.dead){
        const baseAtk2 = rnd(a.atkMin, a.atkMax) * atkMul * 0.6;
        this._playerHit(t, baseAtk2, '连击');
      }
      Game.player.rage = Math.min(RAGE_MAX, (Game.player.rage||0) + 1);
    }
    else if(action.type === 'skill'){
      const key = action.skill;
      const sk = SKILLS[key];
      if(!sk || Game.player.lv < sk.unlock) return;
      if(b.cds[key] > 0) return;
      if(Game.player.mp < sk.mp) return;
      b.cds[key] = sk.cd;
      Game.player.mp -= sk.mp;

      if(key === 'liehuo'){
        const t = action.target;
        if(!t || t.dead) return;
        const mul = skillDmgMul('liehuo', 1.8);
        const baseAtk = rnd(a.atkMin, a.atkMax) * atkMul * mul;
        this._playerHit(t, baseAtk);
        this._applyFlame(t);
        _popSkillEmoji(document.getElementById('mon-'+t.mid), '🔥', true, true);
        _pulseCard(t, 'anim-fire-pulse');
        if(Math.random() < a.combo && !t.dead){
          const baseAtk2 = rnd(a.atkMin, a.atkMax) * atkMul * mul * 0.6;
          this._playerHit(t, baseAtk2, '连击');
        }
      }
      else if(key === 'banyue'){
        _popSkillEmoji($('bGrid'), '⚔️', false, false);
        const mul = skillDmgMul('banyue', 0.9);
        b.monsters.filter(m=>!m.dead).forEach(t=>{
          const baseAtk = rnd(a.atkMin, a.atkMax) * atkMul * mul;
          this._playerHit(t, baseAtk);
        });
      }
      else if(key === 'zhiyu'){
        const rate = skillHealRate('zhiyu', 0.25);
        const heal = Math.floor(playerMaxHp() * rate);
        Game.player.hp = Math.min(playerMaxHp(), Game.player.hp + heal);
        this._floatPlayer(`+${heal}`, 'heal');
        _popSkillEmoji($('pBox'), '💚', false, false);
        _healPlayerAnim();
        getActivePetObjects().forEach(p=>{
          const pMax = petStatFor(p).hp;
          const pHeal = Math.floor(pMax * rate);
          if(pHeal > 0 && p.hp < pMax){
            p.hp = Math.min(pMax, p.hp + pHeal);
            this._floatPet(p, `+${pHeal}`, 'heal');
            const petEl = document.getElementById('pet-' + p.uid);
            if(petEl){
              petEl.classList.remove('anim-heal-glow');
              void petEl.offsetWidth;
              petEl.classList.add('anim-heal-glow');
              setTimeout(()=>petEl.classList.remove('anim-heal-glow'), 700);
            }
          }
        });
      }
      else if(key === 'du'){
        const t = action.target;
        if(!t || t.dead) return;
        const dmg = skillPoisonDmg();
        t.poison = { turns: 3, dmg: dmg };
        _popSkillEmoji(document.getElementById('mon-'+t.mid), '☠️', true, true);
        this._floatMon(t, `中毒`, 'poison');
        toast(`☠️ ${t.name} 中毒 3 回合（每回合 -${dmg}）`);
      }
      else if(key === 'zhanshen'){
        b.buff.zhanshen = 3;
        _popSkillEmoji($('pBox'), '🛡️', false, false);
        _buffPlayerAnim();
        const bonus = Math.floor((skillBuffMul('zhanshen', 1.3) - 1) * 100);
        toast(`🛡️ 战神祝福！攻防+${bonus}%`);
      }
      Game.player.rage = Math.min(RAGE_MAX, (Game.player.rage||0) + 1);
    }
    else if(action.type === 'rage'){
      const t = action.target;
      if(!t || t.dead) return;
      Game.player.rage = 0;
      const baseAtk = rnd(a.atkMin, a.atkMax) * atkMul * 3.0;
      this._playerHit(t, baseAtk, '怒斩', true);
      this._applyFlame(t);
      _popSkillEmoji(document.getElementById('mon-'+t.mid), '⚡', false, false);
      _pulseCard(t, 'anim-rage-hit');
    }
  },

  _playerHit(target, baseAtk, tag, forceCrit){
    const a = calcAttr();
    let isCrit = false;
    if(forceCrit) isCrit = true;
    else if(Math.random() < a.crit) isCrit = true;

    let dmg = calcDamage(baseAtk, target.def);
    if(isCrit) dmg = Math.floor(dmg * a.critD);
    target.hp -= dmg;

    const tagTxt = tag ? `[${tag}]` : '';
    _hitMonsterAnim(target, isCrit);
    this._floatMon(target, `${tagTxt}-${dmg}`, isCrit ? 'crit' : 'normal');

    this._applyLifesteal(dmg, 'player');
    if(target.hp <= 0 && !target.dead) this._killMonster(target);
  },

  _applyLifesteal(dmg, who){
    if(who === 'player'){
      const a = calcAttr();
      let totalHeal = 0;
      if(a.lsPct > 0) totalHeal += Math.floor(dmg * a.lsPct);
      if(a.lsFlat > 0) totalHeal += a.lsFlat;
      if(totalHeal > 0){
        Game.player.hp = Math.min(playerMaxHp(), Game.player.hp + totalHeal);
        this._floatPlayer(`+${totalHeal}`, 'heal');
      }
    }
  },

  _petLifesteal(p, dmg){
    const pst = petStatFor(p);
    const ps = petSkillStateFor(p);
    if(ps.ls > 0){
      const heal = Math.floor(dmg * ps.ls);
      if(heal > 0) p.hp = Math.min(pst.hp, p.hp + heal);
    }
  },

  /* ================= 宠物行动 ================= */
  async _doPetActionAnimated(p, isAuto){
    if(!petAlive(p) || p.deadInBattle) return;
    const battleRef = Game.battle; if(!battleRef) return;
    const petEl = document.getElementById('pet-' + p.uid);
    const alive = battleRef.monsters.filter(m=>!m.dead);
    const targetM = alive.sort((a,b)=>a.hp-b.hp)[0] || null;
    const targetEl = targetM ? document.getElementById('mon-' + targetM.mid) : null;

    if(!isAuto && petEl && targetEl){
      await _chargeTo(petEl, targetEl, 220);
      if(Game.battle !== battleRef) return;
      this._doPetAction(p);
      _returnFromCharge(petEl, 180);
      await _sleep(200);
    }else{
      this._doPetAction(p);
    }
  },

  _doPetAction(p){
    const b = Game.battle; if(!b || !p) return;
    if(!petAlive(p) || p.deadInBattle) return;
    const pst = petStatFor(p);
    const ps = petSkillStateFor(p);
    const alive = b.monsters.filter(m=>!m.dead);
    if(alive.length === 0) return;

    if(ps.heal && (!p.skillCd.heal || p.skillCd.heal <= 0)){
      const heal = Math.floor(playerMaxHp() * ps.heal);
      Game.player.hp = Math.min(playerMaxHp(), Game.player.hp + heal);
      this._floatPlayer(`+${heal}`, 'heal');
      _healPlayerAnim();
      p.skillCd.heal = PET_SKILL_CD.heal;
    }

    let petAtkBonus = 1;
    if(ps.ragePet && Game.player.hp / playerMaxHp() < 0.3) petAtkBonus *= 1.5;
    if(ps.atkBonus) petAtkBonus *= (1 + ps.atkBonus);

    const target = pick(alive);
    const pierceRate = ps.pierce || 0;
    const effDef = (def) => def * (1 - pierceRate);

    const canGroup = ps.group && (!p.skillCd.group || p.skillCd.group <= 0);

    if(canGroup){
      alive.forEach(t=>{
        let dmg = calcDamage(pst.atk * 0.22 * petAtkBonus, effDef(t.def) * 0.5);
        let isCrit = Math.random() < (0.05 + ps.crit);
        if(isCrit) dmg = Math.floor(dmg * 1.3);
        t.hp -= dmg;
        _hitMonsterAnim(t, isCrit);
        this._floatMon(t, `${p.avatar}-${dmg}`, isCrit ? 'crit' : 'normal');
        this._petLifesteal(p, dmg);
        if(ps.pois){
          const pd = Math.max(1, Math.floor(pst.atk * 0.15));
          t.hp -= pd;
          this._floatMon(t, `${p.avatar}-${pd}`, 'poison');
        }
        if(ps.slow && Math.random() < ps.slow){
          t.slow = { turns: 2, amount: 0.2 };
        }
        if(t.hp <= 0 && !t.dead) this._killMonster(t);
      });
      p.skillCd.group = PET_SKILL_CD.group;
    }else{
      let dmg = calcDamage(pst.atk * petAtkBonus, effDef(target.def));
      let isHeavy = ps.heavy && Math.random() < ps.heavy;
      if(isHeavy) dmg = Math.floor(dmg * 1.8);
      let isCrit = Math.random() < (0.05 + ps.crit);
      if(isCrit) dmg = Math.floor(dmg * 1.3);
      target.hp -= dmg;
      _hitMonsterAnim(target, isCrit || isHeavy);
      const tag = isHeavy ? '重击' : '';
      this._floatMon(target, `${p.avatar}${tag}-${dmg}`, (isCrit || isHeavy) ? 'crit' : 'normal');
      this._petLifesteal(p, dmg);
      if(ps.pois){
        const pd = Math.max(1, Math.floor(pst.atk * 0.15));
        target.hp -= pd;
        this._floatMon(target, `${p.avatar}-${pd}`, 'poison');
      }
      if(ps.slow && Math.random() < ps.slow && !target.dead){
        target.slow = { turns: 2, amount: 0.2 };
        this._floatMon(target, '减速', 'reflect');
      }
      if(target.hp <= 0 && !target.dead) this._killMonster(target);
      if(ps.double && Math.random() < ps.double && !target.dead){
        let dmg2 = calcDamage(pst.atk * petAtkBonus * 0.6, effDef(target.def) * 0.6);
        target.hp -= dmg2;
        _hitMonsterAnim(target, false);
        this._floatMon(target, `${p.avatar}[连咬]-${dmg2}`, 'normal');
        this._petLifesteal(p, dmg2);
        if(target.hp <= 0 && !target.dead) this._killMonster(target);
      }
    }
  },

  /* ================= 怪物行动 ================= */
  async _doMonsterActionAnimated(m, defMul, isAuto){
    const battleRef = Game.battle; if(!battleRef) return;
    const card = document.getElementById('mon-' + m.mid);

    const alivePets = getActivePetObjects().filter(p=>!p.deadInBattle);
    let targetEl = null;
    let targetIsPet = false;
    let targetPet = null;
    if(alivePets.length > 0 && Math.random() < 0.5){
      targetIsPet = true;
      targetPet = pick(alivePets);
      targetEl = document.getElementById('pet-' + targetPet.uid);
    }else{
      targetEl = $('pBox');
    }

    if(!isAuto && card && targetEl){
      await _chargeTo(card, targetEl, 220);
      if(Game.battle !== battleRef) return;
      this._doMonsterAction(m, defMul, { targetIsPet, targetPet });
      _returnFromCharge(card, 180);
      await _sleep(200);
    }else{
      this._doMonsterAction(m, defMul, { targetIsPet, targetPet });
    }
  },

  _doMonsterAction(m, defMul, presetTarget){
    const b = Game.battle; if(!b) return;
    if(m.dead) return;

    if(m.behavior === 'healer'){
      const allies = b.monsters.filter(x=>!x.dead && x !== m);
      if(allies.length > 0){
        const worst = allies.sort((a,b)=>a.hp/a.maxHp - b.hp/b.maxHp)[0];
        const heal = Math.floor(worst.maxHp * 0.15);
        worst.hp = Math.min(worst.maxHp, worst.hp + heal);
        this._floatMon(worst, `+${heal}`, 'heal');
        return;
      }
    }

    if(m.behavior === 'summon' && b.roundCount % 2 === 0){
      if(!m.summonCount) m.summonCount = 0;
      const aliveCount = b.monsters.filter(x=>!x.dead).length;
      if(m.summonCount < 2 && aliveCount < 5){
        const nm = {
          mid: uid(), protoId: m.protoId+'_sum_'+m.summonCount, name:'召唤小怪',
          hp: Math.floor(m.maxHp*0.3), maxHp: Math.floor(m.maxHp*0.3),
          atk: Math.floor(m.atk*0.5), def: Math.floor(m.def*0.5),
          spd: m.spd+2, exp: Math.floor(m.exp*0.2),
          gMin:1, gMax:5, behavior:'normal',
          elite:false, affixes:[], dead:false, deathTs:0, vamp:0, pois:0,
          summonCount: 0, poison: null, slow: null
        };
        b.monsters.push(nm);
        m.summonCount++;
        this.render();
      }
    }

    let atkVal = m.atk;
    if(m.behavior === 'rage' && m.hp/m.maxHp < 0.5) atkVal = Math.floor(atkVal * 1.5);
    const a = calcAttr();
    const defMulFinal = defMul > 1 ? 1.3 : 1;

    const targetIsPet = presetTarget && presetTarget.targetIsPet;
    const targetPet = presetTarget && presetTarget.targetPet;

    if(targetIsPet && targetPet && petAlive(targetPet) && !targetPet.deadInBattle){
      const pst = petStatFor(targetPet);
      let dmg = calcDamage(atkVal, pst.def * defMulFinal * 0.9);
      let isCrit = Math.random() < 0.08;
      if(isCrit) dmg = Math.floor(dmg * 1.25);
      petTakeDamage(targetPet, dmg);
      const petEl = document.getElementById('pet-' + targetPet.uid);
      if(petEl){
        petEl.classList.remove('anim-hit-shake');
        void petEl.offsetWidth;
        petEl.classList.add('anim-hit-shake');
        setTimeout(()=>petEl.classList.remove('anim-hit-shake'), 450);
      }
      this._floatPet(targetPet, `-${dmg}`, isCrit ? 'crit' : 'normal');
      if(!petAlive(targetPet) || targetPet.hp <= 0){
        targetPet.deadInBattle = true;
        targetPet.downUntil = Date.now() + PET_DOWN_MS;
        toast(`${targetPet.name} 倒下，本场不再出手`);
      }
      const ps = petSkillStateFor(targetPet);
      if(ps.reflect){
        const rdmg = Math.max(1, Math.floor(dmg * ps.reflect));
        m.hp -= rdmg;
        this._floatMon(m, `-${rdmg}`, 'reflect');
        if(m.hp <= 0 && !m.dead) this._killMonster(m);
      }
    }else{
      let dodgeRate = 0;
      getActivePetObjects().forEach(p=>{
        if(p.deadInBattle) return;
        const ps = petSkillStateFor(p);
        if(ps.dodge) dodgeRate = Math.max(dodgeRate, ps.dodge);
      });
      if(dodgeRate > 0 && Math.random() < dodgeRate){
        this._floatPlayer('闪避', 'heal');
        return;
      }

      const playerDef = rnd(a.defMin, a.defMax);
      let dmg = calcDamage(atkVal, playerDef * defMulFinal * 0.9);
      let isCrit = Math.random() < 0.08;
      if(isCrit) dmg = Math.floor(dmg * 1.25);

      let guardPets = getActivePetObjects().filter(p=>{
        const ps = petSkillStateFor(p);
        return ps.guard && petAlive(p) && !p.deadInBattle;
      });
      if(guardPets.length > 0){
        const totalGuard = guardPets.reduce((s,p)=>s + petSkillStateFor(p).guard, 0);
        const shared = Math.floor(dmg * Math.min(0.6, totalGuard));
        const per = Math.floor(shared / guardPets.length);
        guardPets.forEach(p=>{
          petTakeDamage(p, per);
          this._floatPet(p, `护-${per}`, 'reflect');
          if(p.hp <= 0){
            p.deadInBattle = true;
            p.downUntil = Date.now() + PET_DOWN_MS;
          }
        });
        dmg -= shared;
      }

      Game.player.hp -= dmg;
      if(dmg > 0){
        _hitPlayerAnim();
        this._floatPlayer(`-${dmg}`, isCrit ? 'crit' : 'normal');
      }

      let totalReflect = 0;
      getActivePetObjects().forEach(p=>{
        const ps = petSkillStateFor(p);
        if(ps.reflect) totalReflect += ps.reflect;
      });
      if(totalReflect > 0){
        const rdmg = Math.max(1, Math.floor(dmg * totalReflect));
        m.hp -= rdmg;
        this._floatMon(m, `-${rdmg}`, 'reflect');
        if(m.hp <= 0 && !m.dead) this._killMonster(m);
      }

      if(!m.dead && Math.random() < a.counter){
        const counterDmg = calcDamage(rnd(a.atkMin, a.atkMax), m.def);
        m.hp -= counterDmg;
        _hitMonsterAnim(m, false);
        this._floatMon(m, `[反击]-${counterDmg}`, 'normal');
        if(m.hp <= 0 && !m.dead) this._killMonster(m);
      }
    }

    if(m.vamp) m.hp = Math.min(m.maxHp, m.hp + Math.floor(atkVal * m.vamp * 0.5));
    if(m.pois && !targetIsPet){
      Game.player.hp -= m.pois;
      this._floatPlayer(`-${m.pois}`, 'poison');
    }
  },

  /* ================= 击杀 ================= */
  _killMonster(m){
    if(m.dead) return;
    m.dead = true;
    m.hp = 0;
    m.deathTs = Date.now();
    Game.stats.kills++;
    Game.player.mp = Math.min(playerMaxMp(), Game.player.mp + MP_REGEN_PER_KILL);

    const card = document.getElementById('mon-' + m.mid);
    if(card){ card.classList.add('dead'); card.onclick = null; }

    const b = Game.battle;
    const loot = b.loot;
    loot.killedNames.push(m.name);
    loot.exp += m.exp;
    /* 宠物经验累计（结算时发放，中途死掉就丢） */
    loot.petExp += Math.floor(m.exp * 0.5);
    const gold = rnd(m.gMin, m.gMax);
    loot.gold += gold;

    Quest.onKill(m.protoId);

    let dropChance = m.isBoss ? 0.85 : (m.elite ? 0.55 : 0.18);
    if(Math.random() < dropChance){
      const monType = m.isBoss ? 'boss' : (m.elite ? 'elite' : 'normal');
      const eq = rollDropEquip(Game.ui.areaId, monType);
      if(eq){
        if(Game.bag.length + loot.items.length < Game.player.bagMax){
          loot.items.push({ name: eq.name, quality: eq.quality, eq: eq });
        }
      }
    }

    this._tryDropGemOrFrag(m, loot);

    let pageRate = PAGE_DROP.normalMon;
    if(m.isBoss) pageRate = PAGE_DROP.boss;
    else if(m.elite) pageRate = PAGE_DROP.elite;
    if(Math.random() < pageRate) loot.pages += 1;

    if(m.elite && !m.isBossGuard && Math.random() < 0.08 && Game.pets.length < PET_WAREHOUSE_MAX){
      const tpl = rollPetTemplate();
      const q = rollPetQuality(0.05);
      const pet = makePet(tpl, q);
      Pet.tryAdd(pet);
      showBattleDrop(`🥚 精英掉落宠物蛋！`);
    }
    if(m.isBoss){
      if(Math.random() < 0.25 && Game.pets.length < PET_WAREHOUSE_MAX){
        const tpl = rollPetTemplate();
        const q = rollPetQuality(0.15);
        const pet = makePet(tpl, q);
        Pet.tryAdd(pet);
        showBattleDrop(`🥚 BOSS 掉落宠物蛋！`);
      }
      if(m.unlockDragon){ Game.flags.dragonCity = true; showBattleDrop('🌐 魔龙城已解锁！'); }
      if(m.unlockNiumo){ Game.flags.niumo = true; showBattleDrop('🐂 牛魔洞已解锁！'); }
      if(m.unlockGhost){ Game.flags.ghost = true; showBattleDrop('👻 幽灵船已解锁！'); }
      areaState(Game.ui.areaId).floors[Game.ui.floorIdx].bossDeath = Date.now();
    }
  },

  _tryDropGemOrFrag(m, loot){
    let rate = GEM_DROP_RATE.normalMon;
    if(m.isBoss) rate = GEM_DROP_RATE.boss;
    else if(m.elite) rate = GEM_DROP_RATE.elite;
    if(Math.random() >= rate) return;
    const isGem = Math.random() < GEM_DROP_SPLIT;
    if(isGem){
      const boost = m.isBoss ? 0.15 : (m.elite ? 0.05 : 0);
      const key = randomGemKey();
      const q = rollGemQuality(boost);
      loot.gems.push({ key, quality: q });
    }else{
      const key = randomGemKey();
      const r = Math.random();
      const q = r < 0.02 ? 'legend' : (r < 0.10 ? 'rare' : 'normal');
      const exist = loot.frags.find(f=>f.key===key && f.quality===q);
      if(exist) exist.count++;
      else loot.frags.push({ key, quality: q, count: 1 });
    }
  },

  /* ================= 战斗结束（胜利） ================= */
  _onBattleClear(){
    const b = Game.battle; if(!b) return;
    this.stopAuto();
    if(b.kind === 'group' && b.group){
      b.group.alive = false;
      b.group.deathTs = Date.now();
    }

    const loot = b.loot;
    _showBattleResult(loot, ()=>{
      /* 玩家经验入账 */
      if(loot.exp > 0) addExp(loot.exp);
      /* 宠物经验入账：每只上阵宠物都拿一份 */
      if(loot.petExp > 0){
        const petNames = [];
        Game.activePets.forEach(u=>{
          const p = Game.pets.find(x=>x.uid === u);
          if(p){
            petAddExp(p, loot.petExp);
            petNames.push(p.name);
          }
        });
        if(petNames.length > 0){
          toast(`宠物经验 +${loot.petExp}（${petNames.length}只）`);
        }
      }
      if(loot.gold > 0) Game.player.gold += loot.gold;
      if(loot.pages > 0) Game.pages = (Game.pages || 0) + loot.pages;
      loot.items.forEach(it=>{
        if(Game.bag.length < Game.player.bagMax) Game.bag.push(it.eq);
      });
      loot.gems.forEach(g=>{
        Game.gems.push({ uid: 'g_'+Math.random().toString(36).slice(2,10), key: g.key, quality: g.quality });
      });
      loot.frags.forEach(f=>{
        const frag = Game.fragments[f.key];
        if(frag) frag[f.quality] = Math.min(FRAG_MAX_STACK, (frag[f.quality]||0) + f.count);
      });
      Quest.onBagChange();
      Save.auto();
      this.end();
    });
  },

  /* ================= 死亡 ================= */
  _onPlayerDead(){
    const p = Game.player;
    const isProtected = p.lv <= 3;
    let lines = ['💀 你死亡了'];
    if(isProtected){
      lines.push('（3 级以下保护，无损失）');
    }else{
      const slots = SLOT_ORDER.filter(s => Game.worn[s]);
      let lostEquipName = null;
      if(slots.length > 0){
        const slot = pick(slots);
        const eq = Game.worn[slot];
        lostEquipName = eq.name;
        Game.worn[slot] = null;
      }
      const need = expNeed(p.lv);
      const expLoss = Math.min(p.exp, Math.floor(need * 0.15));
      p.exp -= expLoss;
      const lossPct = rnd(5, 20);
      const goldLost = Math.floor(p.gold * lossPct / 100);
      p.gold -= goldLost;

      lines.push('');
      if(lostEquipName) lines.push(`掉落装备：${lostEquipName}`);
      else lines.push('掉落装备：（无可掉落）');
      lines.push(`损失经验：${expLoss}`);
      lines.push(`损失金币：${goldLost}（-${lossPct}%）`);
    }

    Game.player.hp = playerMaxHp();
    Game.player.mp = playerMaxMp();
    Game.stats.deaths++;
    this.stopAuto();
    Save.auto();

    this.end();
    setTimeout(()=>{
      confirmBox(lines.join('\n'), ()=>{ Render.top(); Render.home(); });
    }, 200);
  },

  quit(){
    if(Game.battle && Game.battle.monsters.some(m=>!m.dead)){
      confirmBox("战斗未结束，确定退出？", ()=>{
        this.stopAuto();
        this.end();
      });
    }else{
      this.stopAuto();
      this.end();
    }
  },

  /* ================= 退出战斗 =================
   * 活着的宠物：保留当前 HP，交给 tickRecover 逐步恢复
   * 死掉的宠物：清 deadInBattle，CD 到了复活满血
   * ------------------------------------------------ */
  end(){
    this.stopAuto();
    Game.battle = null;
    Game.activePets.forEach(u=>{
      const p = Game.pets.find(x=>x.uid === u);
      if(!p) return;
      p.deadInBattle = false;
      p.skillCd = {};   /* 清 CD */
      /* 复活倒计时已到 → 立即满血复活 */
      if(p.downUntil && p.downUntil <= Date.now()){
        p.downUntil = 0;
        p.hp = petStatFor(p).hp;
      }
      /* 没死的宠物保留当前 HP，由 tickRecover 逐步回 */
    });
    Nav.home();
    Render.top();
  }
};