/* ============================================================
 *  67-render-save.js  —— 存档 / 读档页
 * ============================================================ */

const RenderSave = {
  _fmtTime(ts){
    if(!ts) return '';
    const d = new Date(ts);
    const pad = n => n<10?'0'+n:''+n;
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  },

  /* ---------------- 存档页 ---------------- */
  savePage(){
    let html = `<div class="dim" style="font-size:12px;padding:0 0 8px;">
      手动存档有 2 个槽位，覆盖前会确认。
    </div>`;

    const autoSum = Save.getSummary(Save.KEY_AUTO);
    html += `<div class="card" style="opacity:.7;">
      <div class="card-title">🤖 自动存档 <span class="dim">[系统]</span></div>
      <div class="card-meta">${autoSum
        ? `Lv.${autoSum.lv} · ${fmt(autoSum.gold)}金 · ${this._fmtTime(autoSum.ts)}`
        : '暂无自动存档'}</div>
      <div class="card-meta dim" style="font-size:11px;">关键节点自动写入，不可手动覆盖</div>
    </div>`;

    const m1 = Save.getSummary(Save.KEY_M1);
    html += `<div class="card">
      <div class="card-title">📁 手动存档 1</div>
      <div class="card-meta">${m1
        ? `Lv.${m1.lv} · ${fmt(m1.gold)}金 · ${this._fmtTime(m1.ts)}`
        : '空槽'}</div>
      <div class="card-actions">
        <button class="btn ${m1?'danger':'primary'}" onclick="Render._doSave(1)">
          ${m1?'覆盖保存':'保存到槽 1'}
        </button>
      </div>
    </div>`;

    const m2 = Save.getSummary(Save.KEY_M2);
    html += `<div class="card">
      <div class="card-title">📁 手动存档 2</div>
      <div class="card-meta">${m2
        ? `Lv.${m2.lv} · ${fmt(m2.gold)}金 · ${this._fmtTime(m2.ts)}`
        : '空槽'}</div>
      <div class="card-actions">
        <button class="btn ${m2?'danger':'primary'}" onclick="Render._doSave(2)">
          ${m2?'覆盖保存':'保存到槽 2'}
        </button>
      </div>
    </div>`;

    $('saveBody').innerHTML = html;
  },

  _doSave(slot){
    const key = slot === 1 ? Save.KEY_M1 : Save.KEY_M2;
    const exists = Save.getSummary(key);
    if(exists){
      confirmBox(`覆盖手动存档 ${slot}？`, ()=>{
        Save.manual(slot);
        Render.savePage();
      });
    }else{
      Save.manual(slot);
      Render.savePage();
    }
  },

  /* ---------------- 读档页 ---------------- */
  loadPage(){
    let html = `<div class="dim" style="font-size:12px;padding:0 0 8px;">
      点击「读取」加载对应槽的进度（会覆盖当前进度）
    </div>`;

    const slots = [
      { id:'auto', key: Save.KEY_AUTO, label:'🤖 自动存档' },
      { id:1,      key: Save.KEY_M1,   label:'📁 手动存档 1' },
      { id:2,      key: Save.KEY_M2,   label:'📁 手动存档 2' }
    ];

    slots.forEach(sl=>{
      const sum = Save.getSummary(sl.key);
      html += `<div class="card">
        <div class="card-title">${sl.label}</div>
        <div class="card-meta">${sum
          ? `Lv.${sum.lv} · ${fmt(sum.gold)}金 · ${this._fmtTime(sum.ts)}`
          : '空槽'}</div>
        ${sum ? `<div class="card-actions"><button class="btn primary" onclick="Render._doLoad('${sl.id}')">读取</button></div>` : ''}
      </div>`;
    });

    $('loadBody').innerHTML = html;
  },

  _doLoad(slot){
    confirmBox("读取此存档会覆盖当前进度，确定？", ()=>{
      Save.load(slot);
    });
  }
};