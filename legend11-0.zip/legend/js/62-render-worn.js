/* ============================================================
 *  62-render-worn.js  —— 人物页
 *  新布局：中间小人 + 左右各 4 格装备栏
 *  左：武器 / 头盔 / 衣服 / 鞋子
 *  右：腰带 / 手镯 / 戒指 / 项链
 *  点击空槽 → 弹「选择该槽位装备」
 *  点击有装备 → 弹装备详情
 * ============================================================ */

const RenderWorn = {
  wornPage(){
    let html = `<div class="worn-layout">
      <div class="worn-col worn-col-left">
        ${this._slotHtml('weapon')}
        ${this._slotHtml('helmet')}
        ${this._slotHtml('cloth')}
        ${this._slotHtml('shoe')}
      </div>
      <div class="worn-center">
        ${this._centerHtml()}
      </div>
      <div class="worn-col worn-col-right">
        ${this._slotHtml('belt')}
        ${this._slotHtml('bracelet')}
        ${this._slotHtml('ring')}
        ${this._slotHtml('neck')}
      </div>
    </div>`;
    $('wornBody').innerHTML = html;
  },

  /* 中间小人 + 简略属性 */
  _centerHtml(){
    const a = calcAttr();
    const mHp = playerMaxHp(), mMp = playerMaxMp();
    return `
      <div class="worn-avatar">🧙</div>
      <div class="worn-lv">Lv.${Game.player.lv}</div>
      <div class="worn-stat">HP ${Math.floor(Game.player.hp)}/${mHp}</div>
      <div class="worn-stat">MP ${Math.floor(Game.player.mp)}/${mMp}</div>
      <div class="worn-stat">攻 ${a.atkMin}-${a.atkMax}</div>
      <div class="worn-stat">防 ${a.defMin}-${a.defMax}</div>
      <div class="worn-stat">速 ${a.spd}</div>
      <div class="worn-stat">暴 ${(a.crit*100).toFixed(0)}%</div>
    `;
  },

  /* 单个装备槽 */
  _slotHtml(slot){
    const e = Game.worn[slot];
    const slotName = SLOT_NAME[slot];
    if(e){
      const q = QUALITY[e.quality];
      const base = equipBaseRange(e);
      const atk = base.atkMax + (e.refineAtk || 0);
      const def = base.defMax + (e.refineDef || 0);
      const sockets = _socketsTxt(e);
      return `<div class="worn-slot filled" onclick="Render.showEquipDetail('worn','${slot}')">
        <div class="worn-slot-label">${slotName}</div>
        <div class="worn-slot-name ${q.cls}">${e.name}</div>
        <div class="worn-slot-stat">攻${atk} 防${def}</div>
        <div class="worn-slot-sockets">${sockets}</div>
      </div>`;
    }else{
      return `<div class="worn-slot empty" onclick="Render.pickEquipForSlot('${slot}')">
        <div class="worn-slot-label">${slotName}</div>
        <div class="worn-slot-empty-icon">＋</div>
      </div>`;
    }
  }
};