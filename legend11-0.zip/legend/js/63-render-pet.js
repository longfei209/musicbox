/* ============================================================
 *  63-render-pet.js  —— 宠物页面
 *  改动：用 PET_QUALITY 代替 QUALITY，正确显示 5 层品质
 * ============================================================ */

const RenderPet = {
  petPage(){
    const limit = petSlotLimit();
    const activeCount = Game.activePets.length;
    let html = `<div class="dim" style="font-size:12px;padding:0 0 6px;">
      上阵 ${activeCount}/${limit} · 仓库 ${Game.pets.length}/${PET_WAREHOUSE_MAX}
    </div>`;

    if(Game.pets.length === 0){
      html += `<div class="card dim">暂无宠物，去商店买宠物蛋吧。</div>`;
    }else{
      Game.pets.forEach(p=>{
        const q = PET_QUALITY[p.quality] || PET_QUALITY.common;
        const st = petStatFor(p);
        const isActive = Game.activePets.includes(p.uid);
        const alive = petAlive(p);
        const maxHp = st.hp;
        const hpPct = clamp(p.hp/maxHp, 0, 1) * 100;
        const skills = p.skills && p.skills.length
          ? p.skills.map(k=>PET_SKILLS[k].name).join(' / ')
          : '无';
        const skillDesc = p.skills && p.skills.length
          ? p.skills.map(k=>{
              const sk = PET_SKILLS[k];
              const cdTxt = PET_SKILL_CD[k] ? `（CD ${PET_SKILL_CD[k]} 回合）` : '（被动）';
              const tierTag = sk.tier === 'legend' ? ' 🌟' : (sk.tier === 'adv' ? ' ✦' : '');
              return `<div class="dim" style="font-size:10px;">· ${sk.name}${tierTag}：${sk.desc}${cdTxt}</div>`;
            }).join('')
          : '';
        let statusTxt = '';
        if(p.deadInBattle){
          statusTxt = `<span style="color:#c88;font-size:10px;">[本场倒下]</span>`;
        }else if(!alive){
          const left = Math.ceil((p.downUntil - Date.now())/1000);
          statusTxt = `<span style="color:#c88;font-size:10px;">[复活中 ${left}s]</span>`;
        }else if(isActive){
          statusTxt = `<span style="color:#8f8;font-size:10px;">[已上阵]</span>`;
        }

        html += `<div class="card">
          <div class="card-title">${p.avatar} <span class="${q.cls}">${p.name}</span> <span class="dim">[${q.name}] Lv.${p.lv}</span> ${statusTxt}</div>
          <div class="card-meta">HP ${Math.floor(p.hp)}/${maxHp} · 攻${st.atk} 防${st.def} 速${st.spd} | 被动 攻+${st.pAtk} 防+${st.pDef} 速+${st.pSpd}</div>
          <div class="bar" style="height:8px;margin-bottom:4px;"><i style="width:${hpPct}%;background:#7a8a7a;"></i></div>
          <div class="card-meta">技能(${(p.skills||[]).length}): ${skills}</div>
          ${skillDesc}
          <div class="card-meta">经验 ${p.exp}/${p.lv*150}</div>
          <div class="card-actions">
            ${isActive
              ? `<button class="btn ghost" onclick="Pet.toggle('${p.uid}')">下阵</button>`
              : `<button class="btn" onclick="Pet.toggle('${p.uid}')" ${activeCount>=limit || !alive ?'disabled':''}>${!alive?'复活中':(activeCount>=limit?'已满':'上阵')}</button>`}
            <button class="btn danger" onclick="Pet.release('${p.uid}')">放生</button>
          </div>
        </div>`;
      });
    }
    $('petBody').innerHTML = html;
  }
};